package demo.objectrepository;

public interface OR_Logout {

    String logoutDd = "css=#notification-";
    String logoutBtn= "css=#notification-logout";
}
