package testCases;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class CDRConfig  extends MediatorClass{
	
	 @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
	    public void CDRConfig(String zUserName, String zPassword) throws Throwable {
	    
	    	//String customer_id=getTestData(this.getClass().getSimpleName().substring(0, 5),1);
         	String customer_id = "906502";
            logger = extent.startTest("CDRConfig").assignCategory("Home","Regression test");
	        logInfo("TestCase Description:In CDRConfig Page Verify On/Off Buttons And Add Link_Manage_SFTP_Credentials Account");
	        type(userNameTxt, zUserName, "User name");
		    type(passTxt, zPassword, "Password");
	        click(submitBtn, "Submit button");
	        logInfo("Logged into Zeus successfully");	
	        waitForElementPresent(searchTextBox, 300);
		    type(searchTextBox, customer_id, "Search Box");
			type(searchTextBox, "search box", Keys.ENTER);
			Thread.sleep(3000);
			if (verifyElementText(customerTableHeadline, "Customers")) {
				verifyTextInColumnClickOtherColumn(customerIdList, customerName, customer_id);
			}
			verifyText(customer_dashboard_name, "Customer:", "Customer Name"); 
			JSClick(homeBtnDd, "Home");
			JSClick(prortaluserLink, "Portal User");
		    waitForElementPresent(prortaluserLink_call_file, 80);
		    
		    String checked="btn-checked";
		    
		    if(getAttributeValue(prortaluserLink_call_file, "class").contains(checked)) {
		    	logPass("Call Detail Record (CDR) File Transfer Service is by default 'ON' and making it 'OFF'");
		    	actionsClick(prortaluserLink_call_file, "Call Detail Record (CDR) File Transfer Service- ON");
		    	Thread.sleep(1000);
		    	
		    }
		    else {
		    	logPass("Call Detail Record (CDR) File Transfer Service is by default 'OFF' and making it 'ON'");
		    	actionsClick(prortaluserLink_call_file, "Call Detail Record (CDR) File Transfer Service- ON");
		    	Thread.sleep(1000);
		    	
			}
		   
		  
		    if(!getAttributeValue(prortaluserLink_call_file, "class").contains(checked))	{	    	
				actionsClick(prortaluserLink_call_file, "Call Detail Record (CDR) File Transfer Service- ON");
				 
				Thread.sleep(1000);
				
		 }
		    
			actionsClick(prortaluserLink_call_account, "Call Detail Record (CDR) Accounting (billable)- OFF");
			JSClick(prortaluserLink_Manage_SFTP_Credentials, "Clicked on Link_Manage_SFTP_Credentials");
			Thread.sleep(1000);
			clearText(prortaluserLink_Manage_SFTP_Credentials_username);
	        type(prortaluserLink_Manage_SFTP_Credentials_username, "Priyanka", "User name");
	        clearText(prortaluserLink_Manage_SFTP_Credentials_hostname);
	        type(prortaluserLink_Manage_SFTP_Credentials_hostname, "Test", "Host name");
	        clearText(prortaluserLink_Manage_SFTP_Credentials_port);
	        type(prortaluserLink_Manage_SFTP_Credentials_port, "11", "Port");
	        clearText(prortaluserLink_Manage_SFTP_Credentials_folder);
	        type(prortaluserLink_Manage_SFTP_Credentials_folder, "TestFolder", "Folder");
	        JSClick(prortaluserLink_Manage_SFTP_Credentials_compress, "Compress on");
	        JSClick(prortaluserLink_Manage_SFTP_Credentials_md5file, "MD5 Files");
	        JSClick(prortaluserLink_Manage_SFTP_Credentials_passwordradiobutton, "Password Radiobutton");
	        type(prortaluserLink_Manage_SFTP_Credentials_password, "priyanka", "Pass Word");
	        JSClick(prortaluserLink_Manage_SFTP_Credentials_RSAradiobutton, "RSA radio button");
	        type(prortaluserLink_Manage_SFTP_Credentials_rsakey, "ssh-rsa\r\n1234567zaC1y","RSA Key");
	        scrollElementIntoView(prortaluserLink_Manage_SFTP_Credentials_save);
	        JSClick(prortaluserLink_Manage_SFTP_Credentials_save, "Saved sucessfully");
	        scrollElementIntoView(prortaluserLink_Manage_SFTP_Credentials_savedsucessfullymessage);
	        verifyText(prortaluserLink_Manage_SFTP_Credentials_savedsucessfullymessage, "SFTP credentials successfully updated", "Saved sucessfully massage verified");
	        waitForElementPresent(prortaluserLink_Manage_SFTP_Credentials_windowclose_X, 80);
	        JSClick(prortaluserLink_Manage_SFTP_Credentials_windowclose_X, "Window close");
	        logOut();
}
}
