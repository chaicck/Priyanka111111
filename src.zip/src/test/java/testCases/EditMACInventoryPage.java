package testCases;

import java.io.File;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import demo.businesslogic.CommonReusables;
import demo.objectrepository.OR_CustInfo;
import demo.objectrepository.OR_HomePage;
import demo.objectrepository.OR_NewMAC;
import demo.objectrepository.OR_ProjectManager;
import demo.objectrepository.OR_SearchPage;

public class EditMACInventoryPage extends CommonReusables implements OR_SearchPage, OR_HomePage, OR_CustInfo,OR_ProjectManager,OR_NewMAC {
 
	 String fs= File.separator;
	 String rtfFilePath=System.getProperty("user.dir")+fs+"TestData"+fs+"test.rtf";
	 @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")

    public void editMACInventoryPage(String zUserName, String zPassword) throws Throwable {

        logger = extent.startTest("Verify Edit MAC Inventory Page");
	logInfo("Currently Running on -- "+getCurrentUrl());
	logInfo("TestCAse Description:Verify Billing Invenroty Page");
        type(userNameTxt,zUserName,"User name");
        type(passTxt,zPassword,"Password");
        click(submitBtn,"Submit button");
        click(srchDd,"Search");
        type(srchTxt, "vienna","Search box");
        type(srchTxt,"Search box", Keys.ENTER);
       // selectBillingAndAccStatusActiveAndIventory(noOfRows);
        logOut();

    }
}
