package testCases;

import java.io.File;

import org.testng.Assert;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class ReportingDropDown extends MediatorClass{


	
	 @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
	public void reportingDropDown(String zUserName, String zPassword) throws Throwable {
		logger = extent.startTest("ReportingDropDown").assignCategory("Reports");
		       logInfo("Currently Running on -- "+getCurrentUrl());
		logInfo("TestCase Description:Verifying by clicking on Active Customer Contacts file should be downloaded and \r\n" + 
				"Verifying by clicking on Reconcilliation Daily Recon Exception Report & Recon Exception Aging graph");
		
		String reconExceptionReport="xpath=//a[@href='/recon/exceptionReport/']";
		String reconreport = "xpath=//h1[text()='Daily Recon Exception Report']";
		
		type(userNameTxt, zUserName, "User name");
		type(passTxt, zPassword, "Password");
		click(submitBtn, "Submit button");    

		//refreshBrowser();
		//Verify(reportsReconsilation,reports_reconciliation_exception_report ,reports_reconciliation_subMenu_headline, "Daily Recon Exception Report");

		//Verifying Active Customer Contacts
		
		
		
		VerifyClick(reports_customers,"Reprorts-Customer",reports_customers_activeCustomerContacts,"Active customer contacts");
		logInfo("Active Customer Contacts file has been downloaded");
		Thread.sleep(15000);
		setBrowserToSize(70);
/*		click(reports,"Reports");		
		click(reportsReconsilation,"reportsReconsilation");
		JSClick(reconExceptionReport, "Recon Exception Report");
		waitForElementPresent(reconreport, 300);
		verifyText(reconreport, "Daily Recon Exception Report", "Daily Recon Exception Report");
		*/
		Thread.sleep(3000);	
		waitForElementPresent(reconreport, 300);
		click(reports,"Reports");		
		click(reportsReconsilation,"reportsReconsilation");
		aJSClick(reconExceptionAgingOption,"reconExceptionAgingOption");
		String recongraph = "xpath=//h1[text()='Recon Exception Aging Graph']";
		waitForElementPresent(recongraph, 300);
		verifyText(recongraph, "Recon Exception Aging Graph", "Recon Exception Aging Graph");

logOut();

	}

	private void VerifyClick(String menu,String menuText,String submenu,String subMenuText) throws Throwable {
		aclick(reports,"Reports Link");
		aactionsClick(menu,menuText);
		aJSClick(submenu,subMenuText);
	}


}
