package demo.objectrepository;

public interface OR_ProjectManager {
	 String projManagerDd = "css=.chosen-single";
	    String allOpenProjLnk = "xpath=//li[text()='- All Open Projects -']";
	    String srchBtn = "xpath=//button[text()=' Search']";
	    String firstProjLnk = "xpath=//table[@id='project_table']/tbody/tr[1]/td[@class='left danger']/a";

}
