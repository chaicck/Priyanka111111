package testCases;
import static demo.objectrepository.OR_SearchPage.noOfRows;
import static demo.objectrepository.OR_SearchPage.srchTxt;

import java.io.File;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class TC_1_5_CustomerDashboard_Data_CDR_Config extends MediatorClass{
	  String fs= File.separator;
	  String rtfFilePath=System.getProperty("user.dir")+fs+"TestData"+fs+"test.rtf";
	 @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
	    public void tc_1_5_CustomerDashboard_Data_CDR_Config(String zUserName, String zPassword) throws Throwable {	 
		 
			    String customer_id="34925";
				
				logger = extent.startTest("1.5 Test ID : 17793 - Customer Dashboard_Data_CDR Config").assignCategory("Data");
			        logInfo("Currently Running on -- "+getCurrentUrl());
		                logInfo("TestCase Description:Go to CustomerDashBoard Select Data and CDR Config then Enable Toggels and Save then Download");
				type(userNameTxt, zUserName, "User name");
				type(passTxt, zPassword, "Password");
				click(submitBtn, "Submit button");
				logInfo("Logged into Zeus successfully");
				waitForElementPresent(searchTextBox, 300);
				type(searchTextBox, customer_id, "Search Box");
				type(searchTextBox,"search box",Keys.ENTER);
				Thread.sleep(2000);
				if(verifyElementText(customerTableHeadline, "Customers")) {
					verifyTextInColumnClickOtherColumn(customerIdList, customerName, customer_id); 
				}
				
				verifyText(customer_dashboard_name, "Customer:", "Customer Name"); 	
				
				waitForElementPresent(dashBoard_data, 300);
				JSClick(dashBoard_data,"Data");
				JSClick(dashBoard_data_cdr_config,"CDR config");
				Thread.sleep(8000);
				actionsClick(dashBoard_data_cdr_config_fieldsBtn,"Go to Fields");
				type(dashBoard_data_cdr_config_searchBox, "gets", " search for text 'gets' in searchBox fields");
				waitForElementPresent(dashBoard_data_cdr_config_table, 300);
				verifyText(dashBoard_data_cdr_config_table, "gets", "verified text in Description -This field is only present for GETS calls. If present, its value is Yes");
				logPass("verified text in Description -This field is only present for GETS calls. If present, its value is Yes");            
		                Thread.sleep(8000);
				clearText(dashBoard_data_cdr_config_searchBox);
				waitForElementPresent(dashBoard_data_cdr_config_searchBox, 300);
				type(dashBoard_data_cdr_config_searchBox, "Centrex", " search for text 'Centrex' in searchBox fields");
				waitForElementPresent(dashBoard_data_cdr_config_table, 300);
				verifyText(dashBoard_data_cdr_config_table, "Centrex", "verified text in Module- Centrex in searchBox fields");
		                logPass("verified text in Module- Centrex");
				Thread.sleep(1000);
				clearText(dashBoard_data_cdr_config_searchBox);
				waitForElementPresent(dashBoard_data_cdr_config_searchBox, 300);
				type(dashBoard_data_cdr_config_searchBox, "Redirection Reason for the", "search for text 'Redirection Reason for the' in searchBox field");
				waitForElementPresent(dashBoard_data_cdr_config_table, 300);
				verifyText(dashBoard_data_cdr_config_table, "Redirection Reason for the", "Verified text in Description-'Redirection Reason for the OriginalCalledNumber'");
				logPass("Verified text in Description-'Redirection Reason for the OriginalCalledNumber'");
				Thread.sleep(1000);
				waitForElementPresent(dashBoard_data_cdr_config_searchBox, 300);
				clearText(dashBoard_data_cdr_config_searchBox);
				type(dashBoard_data_cdr_config_searchBox, "deflection", "search for text 'deflection' in searchBox field");
				waitForElementPresent(dashBoard_data_cdr_config_table, 300);
				verifyText(dashBoard_data_cdr_config_table, "deflection", "Verified text in Description-'deflection'");
		                logPass("Verified text in Description-'deflection'");
				waitForElementPresent(dashBoard_data_cdr_config_checkBoxEnable1, 300);
				actionsClick(dashBoard_data_cdr_config_checkBoxEnable1,"Enable toggles-one");
				actionsClick(dashBoard_data_cdr_config_checkBoxEnable2,"Enable toggles-second");
				//checking in summary page
				actionsClick(dashBoard_data_cdr_config_summaryBtn,"Summary");
				Thread.sleep(1000);
				actionsClick(dashBoard_data_cdr_config_summaryBtn_downLoadPreview,"DownLoad Preview");
				Thread.sleep(4000);
				if(isAlertPresent()) acceptAlert();
				// not working, geting blank screen
				Thread.sleep(5000);
				
				
			logOut();	
				
				
    }
}
