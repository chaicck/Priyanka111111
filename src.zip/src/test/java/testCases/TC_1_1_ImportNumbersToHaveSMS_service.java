package testCases;

import java.io.File;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class TC_1_1_ImportNumbersToHaveSMS_service extends MediatorClass{
	
	String admin_nexmo_managePremier_importQA5="xpath=(//a[@href='/premierCentral/importNumbers'])[2]";
	String admin_nexmo_managePremier_import="xpath=//a[@href='/premierCentral/importNumbers']";
	String admin_nexmo_managePremier_import_numberList="xpath=//h4[@class='panel-title']";
	String admin_nexmo_managePremier_import_numberRange="xpath=(//h4[@class='panel-title'])[2]";
	
	String admin_nexmo_managePremier_import_numberList_numberEntry="id=tns_entry";
	String admin_nexmo_managePremier_import_numberList_saveBtn="xpath=(//button[@type='submit'])[2]";
	String admin_nexmo_managePremier_search="xpath=//input[@type='search']";
	String admin_nexmo_managePremier_table_numbers="xpath=//*[@id='numbers_table']/tbody/tr/td[2]";
	String admin_nexmo_managePremier_table_delete_parametarised="xpath=//*[@id=\"numbers_table\"]/tbody/tr[%s]/td[1]/a";
	String admin_nexmo_managePremier_successMsg="xpath=//*[@id='alert_placeholder']/div/span";
	
	String admin_nexmo_managePremier_import_numberRange_startNo="id=tn_start";
	String admin_nexmo_managePremier_import_numberRange_endNo="id=tn_end";
	String admin_nexmo_managePremier_export="id=export-link";
	
	 
	 @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
    public void tc_1_1_ImportNumbersToHaveSMS_service(String zUserName, String zPassword) throws Throwable {
    	
    	String phoneNumber1=randomNum(10);
    	String phoneNumber2=randomNum(10);
     	
    
        logger = extent.startTest("1.1_Test ID : 20337 - [Nexmo Central] Test if a user can import numbers to have the SMS service activated").assignCategory("Admin");
	logInfo("Currently Running on -- "+getCurrentUrl());    
        logInfo("TestCase Description: Admin>Nexmo>MangagePremierCentral Numbers>Import number Range and list>Verify imported number and delete>Click on Export");
        
        type(userNameTxt, zUserName, "User name");
		type(passTxt, zPassword, "Password");
        click(submitBtn, "Submit button");
        
        Verify(nexmo_gdm,nexmo_gdm_managePremierCentralNo ,engineering_subMenu_headLine, "Premier Central Numbers");
        if(getCurrentUrl().contains("qa6"))
            actionsClick(admin_nexmo_managePremier_import, "import button");
        if(getCurrentUrl().contains("qa5"))
            actionsClick(admin_nexmo_managePremier_importQA5, "import button");        
        waitForElementPresent(admin_nexmo_managePremier_import_numberList, 20);
        actionsClick(admin_nexmo_managePremier_import_numberList,"Number List");
        Thread.sleep(1000);
        type(admin_nexmo_managePremier_import_numberList_numberEntry, (phoneNumber1+","+phoneNumber2), "Phone Number");
        actionsClick(admin_nexmo_managePremier_import_numberList_saveBtn);
        waitForElementPresent(engineering_subMenu_headLine, 20);
        //data search funvtionality & delete functionality
        deleteNumber(phoneNumber1);  
        //deleting 2nd phone number
        refreshBrowser();
        deleteNumber(phoneNumber2); 
        logPass("Successfully deleted the numbers imported through NUMBER LIST with ',' functionality");
        
        //verifying Number Range import functionality..
        if(getCurrentUrl().contains("qa6"))
            actionsClick(admin_nexmo_managePremier_import, "import button");
        if(getCurrentUrl().contains("qa5"))
            actionsClick(admin_nexmo_managePremier_importQA5, "import button");        
        
        waitForElementPresent(admin_nexmo_managePremier_import_numberList, 20);
        actionsClick(admin_nexmo_managePremier_import_numberRange,"Number Range");
        Thread.sleep(1000);
        
        type(admin_nexmo_managePremier_import_numberRange_startNo, "2002000000", "Start Number");
        type(admin_nexmo_managePremier_import_numberRange_endNo, "2002000003", "End Number");
        logInfo("importing numbers from 2002000000 to 2002000003");
        actionsClick(admin_nexmo_managePremier_import_numberList_saveBtn);
        waitForElementPresent(engineering_subMenu_headLine, 20);
        logPass("Numbers added successfully from 2002000000 to 2002000003");
        
        logInfo("Deleting the added numbers...");
        deleteNumber("2002000000"); 
        refreshBrowser();
        deleteNumber("2002000001"); 
        refreshBrowser();
        deleteNumber("2002000002"); 
        refreshBrowser();
        deleteNumber("2002000003"); 
        
        logPass("Successfully deleted the numbers imported through NUMBER RANGE functionality");
        
        refreshBrowser();
        waitForElementPresent(admin_nexmo_managePremier_export, 2);
        if (actionsClick(admin_nexmo_managePremier_export, "Export"))
        logPass(".csv file has been downloaded");
        else 
        {
        	logFail(".csv file download has been failed");
        	
        }
        logOut();
    }

    private void deleteNumber(String phoneNumber1) throws Throwable {
		// TODO Auto-generated method stub
    	type(admin_nexmo_managePremier_search, phoneNumber1, "SearchBox");
        Thread.sleep(1000);
        verifyTextInColumnClickOtherColumn(admin_nexmo_managePremier_table_numbers, admin_nexmo_managePremier_table_delete_parametarised, phoneNumber1);
        acceptAlert();
        Thread.sleep(1000);
        verifyText(admin_nexmo_managePremier_successMsg, "successfully deleted", "Delete Message");
		
	}

	private void Verify(String menu,String submenu, String textElement, String text) throws Throwable {
		setBrowserTo80Size();
		JSClick(adminLInk);
		actionsClick(menu);
		JSClick(submenu);
		waitForElementPresent(textElement, 200);
		verifyText(textElement,  text, "Verifying HeadLine text");
	}
    
   
	
}
