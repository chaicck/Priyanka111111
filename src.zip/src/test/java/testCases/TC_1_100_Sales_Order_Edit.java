package testCases;

import java.io.File;

import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class TC_1_100_Sales_Order_Edit extends MediatorClass{
	
	
	
	 
	 @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
	public void tc_1_100_Sales_Order_Edit(String zUserName, String zPassword) throws Throwable {


		 String Customer_35834 = getTestData(this.getClass().getSimpleName().substring(0, 8), 1);
	    	String Customer_12345 = getTestData(this.getClass().getSimpleName().substring(0, 8), 2);
	    	String Customer_388835 = getTestData(this.getClass().getSimpleName().substring(0, 8), 3);
	    	String Customer_vic = getTestData(this.getClass().getSimpleName().substring(0, 8), 4);
	    	
	    	
	    	
	    	
	    	
		logger = extent.startTest("1.100 Test ID : 15050 - ZEUS-SALES-7 - Sales Order Edit").assignCategory("Admin");
		logInfo("Currently Running on -- "+getCurrentUrl());
		logInfo("TestCase Description: Admin>Sales Tools>Sales Order Edit>Search by Customer ID>record and then edit>The following fields will be present: CustomerID, Customer Name, Sales Order#,\r\n" + 
				"Market, Sales Month..>Verify fileds>Serch by another customer and verify display records accordingly");
		
		try {
			type(userNameTxt, zUserName, "User name");
			type(passTxt, zPassword, "Password");
			click(submitBtn, "Submit button");
			logInfo("Logged into Zeus successfully");
			// add admin click line
			setBrowserTo80Size();
			click(adminLInk, "Admin");
			waitForElementPresent(sales_tools, 300);
			Verify(sales_tools,sales_tools_salesOrderEdit ,engineering_subMenu_headLine, "Search");
			waitForElementPresent(admin_menu_salestool_salesorder_Edit_customerID, 300);
			type(admin_menu_salestool_salesorder_Edit_customerID, Customer_35834, "SearchBox");
			waitForElementPresent(admin_menu_salestool_salesorder_Edit_Search_button, 300);
			actionsClick(admin_menu_salestool_salesorder_Edit_Search_button);
			waitForElementPresent(admin_menu_salestool_salesorder_Edit_Customer_name_text, 300);
	        verifyText(admin_menu_salestool_salesorder_Edit_Customer_name_text, "Customer Name", "");
			verifyText(admin_menu_salestool_salesorder_Edit_Customer_ID_text, "CustomerID", "");
			verifyText(admin_menu_salestool_salesorder_Edit_Salesorder_text, "Sales Order#", "");
			verifyText(admin_menu_salestool_salesorder_Edit_Market_text, "Market", "");
			verifyText(admin_menu_salestool_salesorder_Edit_Sales_Month_text, "Sales Month", "");
			verifyText(admin_menu_salestool_salesorder_EditBilling_Status_text, "Billing Status", ""); 
			verifyText(admin_menu_salestool_salesorder_Edit_Sales_Order_Name_text, "Sales Order Name", "");
			verifyText(admin_menu_salestool_salesorder_Edit_MRC_text, "MRC", "");
			verifyText(admin_menu_salestool_salesorder_Edit_GMApproved_text, "GMApproved", "");
			verifyText(admin_menu_salestool_salesorder_Edit_Quote_Stage_text, "Quote Stage", "");
			verifyText(admin_menu_salestool_salesorder_Edit_Type_OfBusiness_text, "Type Of Business", "");
	        waitForElementPresent(admin_menu_salestool_salesorder_Edit_click, 300);
			JSClick(admin_menu_salestool_salesorder_Edit_click,"Salesorder_Edit_click");
			Thread.sleep(3000);
			selectDropDownByIndex(admin_menu_salestool_salesorder_Edit_click_salesdropdown_DD, 2);
			waitForElementPresent(admin_menu_salestool_salesorder_Edit_Save_click, 300);
			actionsClick(admin_menu_salestool_salesorder_Edit_Save_click,"salesorder_Edit_Save");
			waitForElementPresent(admin_menu_salestool_salesorder_Edit_orderno, 300);
			clearText(admin_menu_salestool_salesorder_Edit_orderno);
			Thread.sleep(3000);
			clearText(admin_menu_salestool_salesorder_Edit_customerID);
			Thread.sleep(3000);
			clearText(admin_menu_salestool_salesorder_Edit_customer_name); 
			waitForElementPresent(admin_menu_salestool_salesorder_Edit_customerID, 300);
			type(admin_menu_salestool_salesorder_Edit_customerID, Customer_12345, "Customer Id");
			waitForElementPresent(admin_menu_salestool_salesorder_Edit_Search_button, 300);
			actionsClick(admin_menu_salestool_salesorder_Edit_Search_button,"Search Button");
			waitForElementPresent(admin_menu_salestool_salesorder_Edit_Save_click_0order, 300);
			verifyText(admin_menu_salestool_salesorder_Edit_Save_click_0order, "0 order sorted by GMApproved date", "");
			Thread.sleep(3000);
			clearText(admin_menu_salestool_salesorder_Edit_orderno);
			Thread.sleep(3000);
			clearText(admin_menu_salestool_salesorder_Edit_customerID);
			Thread.sleep(3000);
			clearText(admin_menu_salestool_salesorder_Edit_customer_name);
			Thread.sleep(3000);
			type(admin_menu_salestool_salesorder_Edit_customerID, Customer_35834, "Customer Id");
			Thread.sleep(3000);
			type(admin_menu_salestool_salesorder_Edit_orderno, Customer_388835, "Order Number");
			Thread.sleep(3000);
			type(admin_menu_salestool_salesorder_Edit_customer_name, Customer_vic, "customer name searched");
			Thread.sleep(3000);
			waitForElementPresent(admin_menu_salestool_salesorder_Edit_Search_button, 300);
			actionsClick(admin_menu_salestool_salesorder_Edit_Search_button);
			waitForElementPresent(admin_menu_salestool_salesorder_Edit_Save_click_0order, 300);
			verifyText(admin_menu_salestool_salesorder_Edit_Save_click_0order, "0 order sorted by GMApproved date", "");
			Thread.sleep(3000);
	        clearText(admin_menu_salestool_salesorder_Edit_orderno);
	        Thread.sleep(3000);
			clearText(admin_menu_salestool_salesorder_Edit_customerID);
			Thread.sleep(3000);
			clearText(admin_menu_salestool_salesorder_Edit_customer_name);
			Thread.sleep(3000);
			type(admin_menu_salestool_salesorder_Edit_customer_name, Customer_vic, "customer_name");
			Thread.sleep(3000);
			waitForElementPresent(admin_menu_salestool_salesorder_Edit_Search_button, 300);
			actionsClick(admin_menu_salestool_salesorder_Edit_Search_button,"Search Button");
			waitForElementPresent(admin_menu_salestool_salesorder_Edit_Save_click_somenumberorder, 300);
			verifyText(admin_menu_salestool_salesorder_Edit_Save_click_somenumberorder, "orders sorted by GMApproved date", "");
			Thread.sleep(3000);
			clearText(admin_menu_salestool_salesorder_Edit_orderno);
			Thread.sleep(3000);
			clearText(admin_menu_salestool_salesorder_Edit_customerID);
			Thread.sleep(3000);
			clearText(admin_menu_salestool_salesorder_Edit_customer_name);
			Thread.sleep(3000);
			type(admin_menu_salestool_salesorder_Edit_orderno, Customer_388835, "orderno");
			Thread.sleep(3000);
			waitForElementPresent(admin_menu_salestool_salesorder_Edit_Search_button, 300);
			actionsClick(admin_menu_salestool_salesorder_Edit_Search_button,"Search_button");
			//verifyText(admin_menu_salestool_salesorder_Edit_Save_click_0order, "0 order sorted by GMApproved date", "");
			Thread.sleep(3000);
			logPass("Sales Order records for â€œ388835â€� displayed and the text, â€œ [#] order sorted by GMApproved dateâ€�.");
	       logOut(); 
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		

	}

		private void Verify(String menu,String submenu, String textElement, String text) throws Throwable {
			setBrowserTo80Size();
			JSClick(adminLInk);
			actionsClick(menu);
			JSClick(submenu);
			waitForElementPresent(textElement, 200);
			verifyText(textElement,  text, "Verifying HeadLine text");

}   
}



