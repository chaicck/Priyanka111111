package demo.objectrepository;

public interface OR_CustomerMenu_topRight {

    String menu_notification="id=notification-";
    String menu_notification_profile="xpath=//a[@href='/user/']";
    String menu_notification_zeus_news="id=notification-zeus-news";
    String menu_notification_history="id=notification-history";
    String menu_notification_share="id=notification-share";
    String menu_notification_about="id=notification-about";
    String menu_notification_status="id=notification-status";
    String menu_notification_downloads="id=notification-downloads";
    String menu_notification_loginAs="id=notification-log-in-as";
}
