package master_TestCases;

import static org.testng.Assert.assertEquals;

import java.util.Collections;
import java.util.List;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class TC_1_49_Queues_GMApproved extends MediatorClass{
	
	//Works on Master environment only - test data problem in qa5, qa6
	
	
    @Test
    public void tc_1_49_Queues_GMApproved() throws Throwable {
    	
    	String Queue_GMApproved="id=notification-gm-approved";
    	String GMApprovedQueue_TableCaption="xpath=//*[@id='queue']/caption";
    	String GMApprovedQueue_TableHeaders="xpath=//*[@id='queue']/thead/tr/th";
    	String queues_billing_searchBox="xpath=//input[@type='search']";
    	String GMApprovedQueue_TableCaption_resultCount="xpath=//*[@id='queue']/caption/span";
    	String GMApprovedQueue_exportBtn="xpath=//a[@href='/contract/gmApproved/csv:1']";
    	String GMApprovedQueue_Table_records="xpath=//*[@id='queue']/tbody/tr";
    	String GMApprovedQueue_Table_Approvals="xpath=//*[@id='queue']/tbody/tr/td[6]/span";
    	String GMApprovedQueue_Table_Type="xpath=//*[@id='queue']/tbody/tr/td[8]/span";
    	String GMApprovedQueue_Table_ContractName="xpath=//*[@id='queue']/tbody/tr/td[9]";
    	String GMApprovedQueue_Table_Reps="xpath=//*[@id='queue']/tbody/tr/td[11]";
    	String GMApprovedQueue_Table_NRC="xpath=//*[@id='queue']/tbody/tr/td[12]/span";
    	String GMApprovedQueue_Table_MRC="xpath=//*[@id='queue']/tbody/tr/td[13]/span";
    	//table with hyperlinks
    	String GMApprovedQueue_Table_status="xpath=//*[@id='queue']/tbody/tr/td[1]/a";
    	String GMApprovedQueue_Table_SOW="xpath=//*[@id='queue']/tbody/tr/td[2]/a";
    	String GMApprovedQueue_Table_Doc="xpath=//*[@id='queue']/tbody/tr/td[3]/a";
    	String GMApprovedQueue_Table_chk="xpath=//*[@id='queue']/tbody/tr/td[4]/a";
    	String GMApprovedQueue_Table_company="xpath=//*[@id='queue']/tbody/tr/td[5]/a";
    	String GMApprovedQueue_Table_contractId="xpath=//*[@id='queue']/tbody/tr/td[10]/a";
    	String GMApprovedQueue_Table_markAsReady_Xbuton="xpath=//button[@class='close']";
    	
    	
    	
    	logger = extent.startTest("1.49 Test ID : 15210 - Queues- 8 - GM Approved").assignCategory("Queues");
        type(userNameTxt, "zqa-admin", "User name");
        type(passTxt, "Q@eZL9Pw2D", "Password");
        click(submitBtn, "Submit button");
        waitForElementPresent(Queues_Menu, 150);
        logInfo("Logged into Zeus successfully"); 
        actionsClick(Queues_Menu, "Queues");
        JSClick(Queue_GMApproved,"Queue_GMApproved");
        waitForElementPresent(GMApprovedQueue_TableCaption, 300);
        Assert.assertTrue(getAttributeValue(queues_billing_searchBox, "placeholder").contains("Search"));
        verifyAllListValuesInOrder(GMApprovedQueue_TableHeaders, AddElementsIntoList("Status;SOW;Doc;Chk;Company;Approval;Instl;Type;Contract Name;Contract ID;Rep(s);NRC;MRC"));
        logPass("Following column titles are verified - Status, SOW, Doc, Chk, Company, Approval, Instl, Type, Contract Name, Contract ID, Rep(s), NRC, MRC");
        Assert.assertTrue(Integer.parseInt(getText(GMApprovedQueue_TableCaption_resultCount))>=0);
        logPass("GM Approved Queue label displayed with the result count "+getText(GMApprovedQueue_TableCaption_resultCount));
        JSClick(GMApprovedQueue_exportBtn,"Export Button");
        logPass("User successfully exported the result");
        //verifying 6th step
        int tableRecords=getAllElements(GMApprovedQueue_Table_records).size();
        Assert.assertEquals(getAllElements(GMApprovedQueue_Table_Approvals).size(), tableRecords);
        Assert.assertEquals(getAllElements(GMApprovedQueue_Table_Type).size(), tableRecords);
        Assert.assertEquals(getAllElements(GMApprovedQueue_Table_ContractName).size(), tableRecords);
        Assert.assertEquals(getAllElements(GMApprovedQueue_Table_Reps).size(), tableRecords);
        Assert.assertEquals(getAllElements(GMApprovedQueue_Table_NRC).size(), tableRecords);
        Assert.assertEquals(getAllElements(GMApprovedQueue_Table_MRC).size(), tableRecords);
        logPass("Information text provided under following column titles: Approval, Installation,Type, Contract Name, Rep(s), NRC, MRC is Read only.");
        
        Assert.assertEquals(getAllElements(GMApprovedQueue_Table_status).size(), tableRecords);
        Assert.assertEquals(getAllElements(GMApprovedQueue_Table_SOW).size(), tableRecords);
        Assert.assertEquals(getAllElements(GMApprovedQueue_Table_Doc).size(), tableRecords);
        Assert.assertEquals(getAllElements(GMApprovedQueue_Table_chk).size(), tableRecords);
        Assert.assertEquals(getAllElements(GMApprovedQueue_Table_company).size(), tableRecords);
        Assert.assertEquals(getAllElements(GMApprovedQueue_Table_contractId).size(), tableRecords);
        logPass("Information text provided under following column titles: Status, SOW, Doc, Chk, Company, Contract are activelinks & clickable.");
        
        JSClick(GMApprovedQueue_Table_status, "Mark as Ready");
        waitForElementPresent(GMApprovedQueue_Table_markAsReady_Xbuton, 20);
        logPass("A confirmative message box should be displayed along with the header title: Mark Contract as Ready For Service Delivery");
        actionsClick(GMApprovedQueue_Table_markAsReady_Xbuton, "X button on MarkAsReady prompt");
        logPass("Confirmative message box hidden when the user selects cross mark button");
        
        String contractId=verifyTextInColumnGetOtherColumnText(GMApprovedQueue_Table_status, GMApprovedQueue_Table_contractId, "Mark Ready").trim();
        
        String GMApprovedQueue_Table_markAsReady_markAsReadyBtn="xpath=//button[text()='Mark As Ready']";
        String GMApprovedQueue_Table_SOW_edit="xpath=//a[@class='btn btn-default pull-left toggleAbleBtn']";
        String GMApprovedQueue_Table_SOW_edit_text ="xpath=//body[@class='cke_editable cke_editable_themed cke_contents_ltr cke_show_borders']/ul/li";
        String GMApprovedQueue_Table_SOW_edit_saveChanges="xpath=//button[text()='Save changes']";
        String GMApprovedQueue_Table_SOW_edit_successMsg="xpath=//div[@class='alert alert-success alert-dismissable']";
        
        
        //SOW verification
      JSClick(GMApprovedQueue_Table_SOW, "SOW");
        waitForElementPresent(GMApprovedQueue_Table_SOW_edit, 20);
        logPass("Prompt Message has been displayed for "+contractId);
        /*  actionsClick(GMApprovedQueue_Table_SOW_edit, "Edit Button");
        waitForElementPresent(GMApprovedQueue_Table_SOW_edit_text, 20);
        type(GMApprovedQueue_Table_SOW_edit_text, "test", "SOW - Text box");
        scrollElementIntoView(GMApprovedQueue_Table_SOW_edit_saveChanges);
        JSClick(GMApprovedQueue_Table_SOW_edit_saveChanges);
        Thread.sleep(1000);
        scrollElementIntoView(GMApprovedQueue_Table_SOW_edit_successMsg); 
        verifyText(GMApprovedQueue_Table_SOW_edit_successMsg, "SOW Successfully Saved", ""); */
        JSClick(GMApprovedQueue_Table_markAsReady_Xbuton,"SOW -Edit X button");
        
        // Document upload & delete funtionality
        JSClick(GMApprovedQueue_Table_Doc, "Doc-Attachment");
        navigateToChild();
        actionsClick(attachments_uploadAdditionalDocumentsBtn);
	    actionsClick(attachments_uploadAdditionalDocuments_chooseFile);	      
	      String location= System.getProperty("user.dir")+"\\Drivers\\uploadFileDynamicPath.exe"; 
	    //  ‪String location="C:\\Users\\Anil\\Desktop\\uploadFileWithPath.exe";
	      String fileLocation= System.getProperty("user.dir")+"\\TestData\\Sales Order Test.pdf";
	      Runtime.getRuntime().exec(location+" "+fileLocation); 
	      Thread.sleep(10000);
	      actionsClick(attachments_uploadAdditionalDocuments_upload);
		  Thread.sleep(8000);
		   Assert.assertTrue(verifyTextPresentInList(attachments_documentName, "Sales Order Test.pdf"));
		  // verifyTextPresentInListAndDelete(attachments_documentName, attachment_delete, "Delete Attachement");		   
		   verifyTextInColumnClickOtherColumn(attachments_documentName,attachment_delete_full, "Sales Order Test.pdf");
		   Thread.sleep(2000);
		   navigateBackToParentWindow();
		   
		   		 
		   JSClick(GMApprovedQueue_Table_company, "Doc-Attachment");
		   verifyText(customer_dashboard_name, "Customer:", "Customer Name");
		   navigateBack();
		   Thread.sleep(1000);
		   
		   
		   String GMApprovedQueue_Table_contactId_Quote_Description="xpath=//a[@href='#quote-description']";
		   String GMApprovedQueue_Table_contactId_notes="id=description";
		   String GMApprovedQueue_Table_contactId_notes_saveBtn="xpath=//button[@class='btn btn-primary  btn-sm pull-right quote_description']";
		   String GMApprovedQueue_Table_contactId_notes_saveBtn_successOKBtn="xpath=//button[@class='btn btn-default center-block']";
		   String GMApprovedQueue_Table_contactId_header="xpath=//*[@id='queue']/thead/tr/th[10]";
				   
		   JSClick(GMApprovedQueue_Table_contractId, "Contract Id");
		   waitForElementPresent(GMApprovedQueue_Table_contactId_Quote_Description, 20);
	        logPass("Prompt Message has been displayed for "+contractId);
	        actionsClick(GMApprovedQueue_Table_contactId_Quote_Description, "Quote Description");
	        Thread.sleep(1000);
	        type(GMApprovedQueue_Table_contactId_notes, "test", "Notes- Text box");	        
	        JSClick(GMApprovedQueue_Table_contactId_notes_saveBtn);
	        Thread.sleep(1000);
	        waitForElementPresent(GMApprovedQueue_Table_contactId_notes_saveBtn_successOKBtn, 20);
	        JSClick(GMApprovedQueue_Table_contactId_notes_saveBtn_successOKBtn);
	       logPass("Contract Id notes changes saved successfully");	        
		   Thread.sleep(1000);
		   
		   //sort functionality
		  
	        actionsClick(GMApprovedQueue_Table_contactId_header);
	        Thread.sleep(1000);
	        List<String> customerIds=getAllTheText(GMApprovedQueue_Table_contractId);
	        List<String> customerIds_assendingOrder=getAllTheText(GMApprovedQueue_Table_contractId);
	        Collections.sort(customerIds);
	        System.out.println(customerIds);
	        System.out.println(customerIds_assendingOrder);
	        Assert.assertTrue(customerIds.equals(customerIds_assendingOrder));
	        Thread.sleep(1000);
	        actionsClick(GMApprovedQueue_Table_contactId_header);
	        List<String> customerIds_descendingOrder=getAllTheText(GMApprovedQueue_Table_contractId);
	        Thread.sleep(1000);
	       List<String> customerIds1=getAllTheText(GMApprovedQueue_Table_contractId);
	       Collections.sort(customerIds1); 
	       Collections.reverse(customerIds1);
	        Assert.assertTrue(customerIds1.equals(customerIds_descendingOrder));
		   
		  logPass("sort functionality working properly");
		  
		  
		  //-- mark as ready
	contractId=verifyTextInColumnGetOtherColumnText(GMApprovedQueue_Table_status, GMApprovedQueue_Table_contractId, "Mark Ready").trim();
	        
		  JSClick(GMApprovedQueue_Table_status, "Mark as Ready");
	        waitForElementPresent(GMApprovedQueue_Table_markAsReady_Xbuton, 20);
	        logPass("A confirmative message box should be displayed along with the header title: Mark Contract as Ready For Service Delivery for contract Id "+contractId);
	        actionsClick(GMApprovedQueue_Table_markAsReady_markAsReadyBtn, "MarkAsReady Button");
	        logPass("Confirmative message box hidden when the user selects cross mark button");
	        Thread.sleep(5000);
	        logInfo("Searching for "+contractId+" in GM Approved Queue");
	        type(queues_billing_searchBox, contractId, "SearchBox");
   
		   
		   //Check List Pending
       }
} 
