package testCases;

import java.io.File;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import demo.businesslogic.CommonReusables;
import demo.objectrepository.OR_HomePage;
import demo.objectrepository.OR_LoginPage;
import demo.objectrepository.OR_SearchPage;


public class Customer_DashBoard_information  extends CommonReusables {
 

	  @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
         public void verifyHomePage(String zUserName, String zPassword ) throws Throwable {
        logger=extent.startTest(" HomePage");
	logInfo("Currently Running on -- "+getCurrentUrl());
	 logInfo("TestCase Description:Verify Customer DashBoard Page");
          String homeBtnDd = "xpath=//span[text()='Home']";
         String customerInfoLnk ="id=notification-customer-information";
        type(OR_LoginPage.userNameTxt,zUserName,"User name");
        type(OR_LoginPage.passTxt,zPassword,"Password");
        click(OR_LoginPage.submitBtn,"Submit button");
        click(OR_HomePage.srchDd,"Search");
        type(OR_SearchPage.srchTxt, "35834","Search box");
        type(OR_SearchPage.srchTxt,"Search box",Keys.ENTER);
        click(homeBtnDd,"Home button");
        click(customerInfoLnk,"Customer Information");
        isElementDisplayedE(format("Customer ID"),"Customer ID");
        isElementDisplayedE(format("Account Status"),"Account Status");
        isElementDisplayedE(format("Bill Cycle"),"Bill Cycle");
        isElementDisplayedE(cusSince,"Customer Since");
        isElementDisplayedE(cusExpire,"Contract Expire");
        isElementDisplayedE(format("Customer Name"),"Customer Name");
        isElementDisplayedE(format("Customer Alias"),"Customer Alias");
        isElementDisplayedE(format("Customer Industry"),"Customer Industry");
        isElementDisplayedE(format("Enterprise"),"Enterprise");
        isElementDisplayedE(format("Group"),"Group");
        isElementDisplayedE(market,"Market");
        isElementDisplayedE(format("Sales Person"),"Sales Person");
        isElementDisplayedE(format("Access Hours"),"Access Hours");
        isElementDisplayedE(cusPin,"Customer PIN");
        isElementDisplayedE(format("VPN ID"),"VPN ID");
        isElementDisplayedE(format("Authorization Notes"),"Authorization Notes");
        isElementDisplayedE(cusVipType,"Customer VIP type");
        isElementDisplayedE(billingStatus,"billing Status type");
        isElementDisplayedE(cusMrr,"cusMrr type");
        isElementDisplayedE(siteMrr,"siteMrr ty");
        isElementDisplayedE(cusRank,"cusRank");
        isElementDisplayedE(siteRank,"siteRank");
        isElementDisplayedE(csa,"csa");
        isElementDisplayedE(broadcastCluster,"broadcastCluster");
        isElementDisplayedE(monitoringStatus,"monitoringStatus");
        isElementDisplayedE(downTime,"downTime");
        isElementDisplayedE(shipAddr,"shipAddr");
        isElementDisplayedE(billingAddr,"billingAddr");
        isElementDisplayedE(childCusTable,"childCusTable");
        isElementDisplayedE(exportChildCus,"exportChildCus");
        isElementDisplayedE(eicTable,"eicTable");
        isElementDisplayedE(contactTable,"contactTable");
        isElementDisplayedE(contractTimeLine,"contractTimeLine");
        isElementDisplayedE(projectTimeLine,"projectTimeLine");
        isElementDisplayedE(ticketTimeLine,"ticketTimeLine");
        isElementDisplayedE(notes,"notes");
        isElementDisplayedE(logEntries,"logEntries");
        isElementDisplayedE(mrrTimeline,"mrrTimeline");
        logOut();
       // Assert.assertTrue(baseUrl.equalsIgnoreCase("https://zeus.qa5.vonagenetworks.net/login/view/"));
    }

}
