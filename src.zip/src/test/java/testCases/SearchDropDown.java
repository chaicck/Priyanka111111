   package testCases;

import java.io.File;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class SearchDropDown extends MediatorClass{
	
	
	String pageHeader="className=clearfix";
	String search_number_portabilitySearch="xpath=//a[@href='/tn/portCheckMulti']";
	String search_number_inventorySearch="xpath=//a[@href='/tn/searchMulti']";
	String search_number_inventorySearch_searchTextBox="id=search";
	String search_number_inventorySearch_searchBtn="xpath=(//button[@type='submit'])[2]";
	String search_number_inventorySearch_tableNumbers="xpath=//*[@id='number_table']/tbody/tr/td[1]/a";
	String search_number_inventorySearch_customerParametarised="xpath=//*[@id='number_table']/tbody/tr[%s]/td[2]";
	
	String search_number_PortabilitySearch_table_NPA="xpath=//*[@id='number_table']/tbody/tr/td[1]";
	String search_number_PortabilitySearch_table_NPA_parametarised="xpath=//*[@id='number_table']/tbody/tr[%s]/td[1]";
	String search_number_PortabilitySearch_table_NXX_parametarised="xpath=//*[@id='number_table']/tbody/tr[%s]/td[2]";
	
	
	String inventory_number="(276) 622-3678";
	String inventory_number1="(330) 617-4014";
	String inventory_number2="(605) 956-4188";
	String inventory_number3="(276) 622-3680";
	String inventory_number4="(330) 617-4015";
	String inventory_number5="(605) 956-4195";
	/*String inventory_number6 ="(400) 100-5544";
	String inventory_number7="(586) 259-3300";
	String inventory_number8 = "(586) 259-8951";
	String inventory_number9 = "(760) 587-7393";
	String inventory_number10="(760) 587-7836";*/
	
	String portability_number="609-201";
	
	
	
	  String fs= File.separator;
	  String rtfFilePath=System.getProperty("user.dir")+fs+"TestData"+fs+"test.rtf";
	 @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
    public void searchDropDown(String zUserName, String zPassword) throws Throwable {
		  logger = extent.startTest("Search DropDown").assignCategory("Search","Regression test");
	           logInfo("Currently Running on -- "+getCurrentUrl());
			logInfo("TestCase Description: Verify all menu's under the Search Dropdown and perform search functinolity with respective data");
		type(userNameTxt, zUserName, "User name");
		type(passTxt, zPassword, "Password");
        click(submitBtn, "Submit button");
        waitForElementPresent(srchDd, 300);
        click(srchDd,"Search");
        click(customerLnk,"Customer");  
        waitForElementPresent(srchTxt, 300);
        type(srchTxt, "TNL Test Broadsoft V17","Search box");
        type(srchTxt,"Search for TNL Test Broadsoft V17",Keys.ENTER);        
        verifyText(customerNamefromTable,  "TNL Test Broadsoft V17", "Customer Name");              
        click(srchDd,"Search");  
        click(search_circuit,"circuit "); 
        waitForElementPresent(srchTxt, 300);
        type(srchTxt, "69.KXFS.000669..ACSO","Search box");
        type(srchTxt,"Search for 69.KXFS.000669..ACSO",Keys.ENTER);        		
        verifyText(circuit_tableName,"Circuits", "Verifying Circuits");        
        
        click(srchDd,"Search"); 
        click(search_contact,"Contact"); 
        waitForElementPresent(srchTxt, 300);
        type(srchTxt, "7323162848","Search box");
        type(srchTxt,"Search for 7323162848",Keys.ENTER);
        waitForElementPresent(numberSearch_active_code_info_table, 200);
        verifyText(numberSearch_active_code_info_table, "NPA/NXX Active Code (NNACL) Information", "numberSearch_active_code_info_table");
               
        click(srchDd,"Search");   
        click(search_contract,"Contract");
        waitForElementPresent(srchTxt, 300);
        type(srchTxt, "379582","Search box");
        type(srchTxt,"Search 379582",Keys.ENTER);
        waitForElementPresent(orderNumberValue, 150);
        verifyText(orderNumberValue, "379582", "orderNumber Value");
        verifyText(createdByValue, "Phani Chigurupati", "createdBy Value");
        verifyText(typeValue, "MACD - MINOR MOVES, ADDS, CHANGES, AND DELETES", "Order Type");   
        
        click(srchDd,"Search");
        click(search_device,"Device"); 
        waitForElementPresent(srchTxt, 300);
        type(srchTxt, "ar2.den1","Search box");
        type(srchTxt,"Search box",Keys.ENTER);   
        

        
        type(srchTxt, "gw1.adji.berkeley","Search box");
        type(srchTxt,"Search gw1.adji.berkeley",Keys.ENTER);
       // verifyText(deviceName, "aagw1jyoooo.orap.store100", "device name");
        verifyText(deviceTableName, "Devices", "device Table Name");
        
        click(srchDd,"Search");  
        click(search_dispatch,"Dispatch"); 
        waitForElementPresent(srchTxt, 300);
        type(srchTxt, "123","Search box");
        type(srchTxt,"Search 123",Keys.ENTER); 
        verifyText(dispatchTableName, "Dispatche", "Dispatche Table Name");
        
        click(srchDd,"Search");  
        click(search_ip,"IP"); 
        waitForElementPresent(srchTxt, 300);
        type(srchTxt, "10.23.240.111","Search box");
        type(srchTxt,"Search 10.23.240.111",Keys.ENTER);
        waitForElementPresent(idAddress, 150);
       // verifyText(verifyipadressheader, "IP Information", "IP Information");
        
        click(srchDd,"Search");   
        click(search_inventory,"Inventory"); 
        waitForElementPresent(search_inventorySearchbox, 300);
        type(search_inventorySearchbox, "0004F26A67C4","Search box");
        type(search_inventorySearchbox,"Search 0004F26A67C4",Keys.ENTER); 
        verifyText(inventoryTableName, "Inventory", "Inventory Table Name");
        
        click(srchDd,"Search"); 
        click(search_number,"Number");
        waitForElementPresent(srchTxt, 300);
        type(srchTxt, "7323162848","Search box");
        type(srchTxt,"Search 7323162848",Keys.ENTER);
        waitForElementPresent(numberSearch_active_code_info_table, 200);
        verifyText(numberSearch_active_code_info_table, "NPA/NXX Active Code (NNACL) Information", "numberSearch_active_code_info_table");
      //PortabilityMultisearch
      		actionsClick(search_number_portabilitySearch,"Portability Search");
      		verifyText(pageHeader, "Portability Multi-Search", "");
      		logInfo("User has landed onto 'Portability Multi-Search' page");
      		type(search_number_inventorySearch_searchTextBox, portability_number, "Number Search box");
      		actionsClick(search_number_inventorySearch_searchBtn, "Search button");
      		int tableRecords=getAllElements(search_number_PortabilitySearch_table_NPA).size();		
      		for (int i = 1; i <= tableRecords; i++) {
      			String no=getText(String.format(search_number_PortabilitySearch_table_NPA_parametarised, i))+"-"+getText(String.format(search_number_PortabilitySearch_table_NXX_parametarised, i));
      			if(no.equalsIgnoreCase(portability_number))
      			{
      			logPass("Portability Multisearch functionality has been verified with "+portability_number);
      			break;
      			}
      		}
      		//inventory Search
      		click(srchDd,"Search"); 
      		click(search_number,"Number");		
      		actionsClick(search_number_inventorySearch,"Inventory Multi-Search");
      		verifyText(pageHeader, "Inventory Multi-Search", "");
      		logInfo("User has landed onto 'Inventory Multi-Search' page");
      		
      		type(search_number_inventorySearch_searchTextBox, inventory_number1, "Number Search box");
      		type(search_number_inventorySearch_searchTextBox,"inventory_number1",Keys.ENTER);
      		type(search_number_inventorySearch_searchTextBox, inventory_number2, "Number Search box");
      		type(search_number_inventorySearch_searchTextBox,"inventory_number2",Keys.ENTER);
      		type(search_number_inventorySearch_searchTextBox, inventory_number3, "Number Search box");
      		type(search_number_inventorySearch_searchTextBox,"inventory_number3",Keys.ENTER);
      		type(search_number_inventorySearch_searchTextBox, inventory_number4, "Number Search box");
      		type(search_number_inventorySearch_searchTextBox,"inventory_number4",Keys.ENTER);
      		type(search_number_inventorySearch_searchTextBox, inventory_number5, "Number Search box");
      		type(search_number_inventorySearch_searchTextBox,"inventory_number5",Keys.ENTER);
      		type(search_number_inventorySearch_searchTextBox, inventory_number, "Number Search box");
      		type(search_number_inventorySearch_searchTextBox,"inventory_number",Keys.ENTER);
      		/*type(search_number_inventorySearch_searchTextBox, inventory_number7, "Number Search box");
      		type(search_number_inventorySearch_searchTextBox,"inventory_number7",Keys.ENTER);
      		type(search_number_inventorySearch_searchTextBox, inventory_number8, "Number Search box");
      		type(search_number_inventorySearch_searchTextBox,"inventory_number8",Keys.ENTER);
      		type(search_number_inventorySearch_searchTextBox, inventory_number9, "Number Search box");
      		type(search_number_inventorySearch_searchTextBox,"inventory_number9",Keys.ENTER);
      		type(search_number_inventorySearch_searchTextBox, inventory_number10, "Number Search box");
      		type(search_number_inventorySearch_searchTextBox,"inventory_number10",Keys.ENTER);
      		*/
      		actionsClick(search_number_inventorySearch_searchBtn, "Search button");
      		Assert.assertTrue(verifyTextPresentInList(search_number_inventorySearch_tableNumbers, inventory_number));
      		logPass("Portability Multisearch functionality has been verified with "+inventory_number +" the respective customer displayed on the table is "+verifyTextInColumnGetOtherColumnText(search_number_inventorySearch_tableNumbers, search_number_inventorySearch_customerParametarised, inventory_number));
        
        
        
        click(srchDd,"Search");  
        click(search_project,"Project"); 
        waitForElementPresent(srchTxt, 300);
        type(srchTxt, "15148","Search box");
        type(srchTxt,"Search 15148",Keys.ENTER);        
        verifyText(projectTableName, "Projects", "Project Table Name");
        
        click(srchDd,"Search");  
        click(search_ticket,"Ticket");   
        type(srchTxt, "ptest automation","Search box");
        type(srchTxt,"Search 288140",Keys.ENTER);
        waitForElementPresent(ticketTableName, 300);
        verifyText(ticketTableName, "Tickets", "Ticket Table Name");
      
        
        logOut();
    }
   
	  
	  
}

