package testCases;


import java.io.File;
import java.sql.Driver;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;

import demo.businesslogic.CommonReusables;
import demo.objectrepository.OR_CustInfo;
import demo.objectrepository.OR_FAXMail;
import demo.objectrepository.OR_HomePage;
import demo.objectrepository.OR_NewMAC;
import demo.objectrepository.OR_ProjectManager;
import demo.objectrepository.OR_SearchPage;

public class FAXAddDeleteModify extends CommonReusables implements OR_FAXMail,OR_SearchPage,OR_HomePage, OR_CustInfo,OR_ProjectManager,OR_NewMAC {

    String fs= File.separator;
    String rtfFilePath=System.getProperty("user.dir")+fs+"TestData"+fs+"test.rtf";
    @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
    public void addDns(String zUserName, String zPassword) throws Throwable {
    	String id=getTestData(this.getClass().getSimpleName().substring(0, 5),1);
        logger = extent.startTest("FaxMail");
        logInfo("Currently Running on -- "+getCurrentUrl());
        logInfo("TestCase Description:Add, modify, delete faxmail feature");
        String uploadCoverSheetBtn_close ="xpath=//button[@class='close']";
        userlogin(zUserName, zPassword);
        type(srchTxt, id,"Search box");
        type(srchTxt,"Search box", Keys.ENTER);
        click(voiceLnk,"Voice Link");
        click(faxMailLnk,"FaxMail Link");
        click(faxDeleteLnk,"Delete Icon");
        Assert.assertTrue(isAlertPresent());
        dismissAlert();
        click(viewOrEditLnk,"View Or Edit Icon");
        Assert.assertTrue(Driver.getCurrentUrl().toLowerCase().contains("fax"));
        Driver.navigate().back();
        click(addFaxUserBtn,"Add Fax User Button");
        selectDropDownByIndex(numberDd,2);
        String email="leha.kolli"+generateRandomString(5)+"@vonage.com";
        type(recipientsMailTxt,email,"Recipients Mail");
        type(sendersMailTxt,email,"Senders Mail");
        //click(addFaxMailUserBtn,"Add button");
        Driver.navigate().back();
        click(uploadCoverSheetBtn,"Upload Cover SheetB button");
        click(uploadCoverSheetBtn_close , "Upload Cover SheetB button close");
       /* type(chooseCoverSheetFile,rtfFilePath,"RTF file");
       click(uploadBtn,"Upload button");
        click(successOkBtn,"Ok button");*/
        logOut();

    }
}
