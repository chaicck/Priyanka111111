package demo.objectrepository;

public interface OR_Tools {
	 String menu_tools="id=dd-Tools";
     String tools_routerConfiqTool="id=notification-router-config-tool";
     String tools_routerConfiqTool_customerIdChoosen_DD="id=customer_id_chosen";
     String tools_routerConfiqTool_customerIdChoosen_DD_searchEntry="xpath=(//div[@class='chosen-search'])[1]/input";
     String tools_routerConfiqTool_loadBtn="xpath=(//button[@type='submit'])[2]";
     String tools_routerConfiqTool_loadBtn_checkAll="id=clearall";
     
     String tools_routerConfiqTool_loadBtn_save="id=setem";
}
