package qa6_TestCases;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class TC_1_35_AddNew_EditProjectDueDate extends MediatorClass{
	
	String dashboard_addProject="xpath=//a[starts-with(@href,'/project/create/customer_id')]";
	String dashboard_addProject_projectId="id=project_id";
	String dashboard_addProject_dueDate="id=due_date";
	String dashboard_addProject_projectManager_DD="id=project_manager";
	String dashboard_addProject_dueDate_dueDateReasonChange_DD="id=duedate_reason_code_id";
	String dashboard_addProject_dueDate_dueDateChangeNotes="id=duedate_change_note";
	String dashboard_addProject_dueDate_dueDateChangeNote_saveBtn="id=(//button[@type='submit'])[2]";
	String reports_projectBtPM_view_DD="id=view";
	String reports_projectBtPM_ProjectManager_AlvinWalker="xpath=(//ul[@class='chosen-results']/li)[15]";	
	String reports_projectBtPM_groupByCustomer="name=group";
	String reports_projectBtPM_PIDs="xpath=//*[@id='project_table']/tbody/tr/td[2]";
	String reports_projectBtPM_magnifier_parametarised="xpath=//*[@id='project_table']/tbody/tr[%s]/td[1]/a[1]/i";
	String reports_projectBtPM_project_dueDateChangeNote="id=note";
	
	String projectManager_search="xpath=//div[@class='chosen-search']/input";
	String projectManager_search1="xpath=(//div[@class='chosen-search']/input)[2]";
	
	String dashboard_addProject_projectManager="id=project_manager_chosen";

	@Test
	public void tC_1_35_AddNew_EditProjectDueDate() throws Throwable {

		String customer_id="31589";
		
		logger = extent.startTest("1.35 Test ID : 19944 - Premier Svc - 605_Add New and edit Project Due Date");
		type(userNameTxt, "zqa-admin", "User name");
		type(passTxt, "Q@eZL9Pw2D", "Password");
		click(submitBtn, "Submit button");
		type(searchTextBox, customer_id, "Search Box");
		type(searchTextBox,"search box",Keys.ENTER);
		if(verifyElementText(customerTableHeadline, "Customers")) {
			verifyTextInColumnClickOtherColumn(customerIdList, customerName, customer_id); 
		}
		verifyText(customer_dashboard_name, "Customer:", "Customer Name"); //Name To verify - eg.Customer: Novell & Jimenez-Corp (31589)
		scrollElementIntoView(dashboard_addProject);
		JSClick(dashboard_addProject,"Add Project");
		navigateToChild();
		waitForElementToBeClickable(queues_newProject_createAProjectOntoStep2Btn);
		
		actionsClick(dashboard_addProject_projectManager);
		type(projectManager_search1, "Alvin Walker", "Project Manager Search");
		type(projectManager_search1, "Alvin Walker", Keys.ENTER);
		
		JSClick(queues_newProject_createAProjectOntoStep2Btn,"'Create A Project & On to Step2'");
		scrollElementIntoView(queues_createAProjectOntoStep_DueDate);
		JSClick(queues_createAProjectOntoStep_DueDate, "'Due Date from calander'");
		waitForElementPresent(dashboard_addProject_projectId, 20);
		String projectId=getAttributeValue(dashboard_addProject_projectId, "value");
		actionsClick(queues_createAProjectOntoStep_buildProjectTask, "buildProjectTask");
		waitForElementPresent(queues_newProject_saveRecalculateBtn, 20);
		selectDropDownByVisibleText(queues_createAProjectOntoStep_projectStatus_DD, "Ready for FULL Billing");
		String toDaysDay=dateAftersomeDays(0, "dd");
		String toDaysmonth=dateAftersomeDays(0, "MM");
		String toDaysyear=dateAftersomeDays(0, "yyyy");
		enterDate(queues_createAProjectOntoStep_fullBillDate, toDaysDay, toDaysmonth, toDaysyear);		
		//type(queues_createAProjectOntoStep_fullBillDate, toDaysdate(), "full bill date");
		Thread.sleep(2000);
		//String alvin_walker="xpath=//*[@id='project_manager']/option[10]";
		//JSClick(dashboard_addProject_projectManager_DD);
		Thread.sleep(1000);
		//actionsClick(alvin_walker);
		selectDropDownByVisibleText(dashboard_addProject_projectManager_DD, "Alvin Walker");
				
		//String dueDate=dateAftersomeDays(5, "MMddyyy");
		String dayAfterDays=dateAftersomeDays(5, "dd");
		String monthAfterDays=dateAftersomeDays(5, "MM");
		String yearAfterDays=dateAftersomeDays(5, "yyyy");
		enterDate(dashboard_addProject_dueDate, dayAfterDays, monthAfterDays, yearAfterDays);		
		//type(dashboard_addProject_dueDate, dueDate, "Due Date");
		
		String dueDateWithFormat=dateAftersomeDays(5, "yyy-MM-dd");
		actionsClick(queues_newProject_saveRecalculateBtn, "saveRecalculateBtn");
		waitForElementPresent(dashboard_addProject_dueDate_dueDateReasonChange_DD, 20);
		selectDropDownByIndex(dashboard_addProject_dueDate_dueDateReasonChange_DD, 2);
		String dueDateReasonChange_DD_value=getDropdownSelectedValue(dashboard_addProject_dueDate_dueDateReasonChange_DD);
		type(dashboard_addProject_dueDate_dueDateChangeNotes, "test", "DueDateChangeNotes");
		Thread.sleep(3000);
		JSClick(dashboard_addProject_dueDate_dueDateChangeNote_saveBtn,"DueDateChangeNote_saveBtn");		
		actionsClick(queues_newProject_saveRecalculateBtn, "saveRecalculateBtn");
		waitForElementPresent(queues_projectBuildSuccessMsg, 20);
		actionsClick(queues_projectBuildSuccessMsg,"projectBuildSuccessMsg_Ok_Button");	
		logPass("Project successfully created with Project Id "+projectId);
		//---		
		click(projectMenu,"project Link");
		click(Reports_projectByPM,"projectByPM");
		waitForElementPresent(Reports_projectByPM_headline, 200);
		//11 the step in test cases - need clarification
		//verifyText(reports_projectBtPM_ProjectManager_DD, "", "");        
		actionsClick(reports_projectBtPM_ProjectManager_DD,"ProjectManager DropDown");
		
		type(projectManager_search, "Alvin Walker", "projectManager Search");
		type(projectManager_search, "Alvin Walker", Keys.ENTER);
		
		       
		String viewDD_value=getDropdownSelectedValue(reports_projectBtPM_view_DD);		
		
		Assert.assertEquals(viewDD_value, "O'Reilly");
		logPass("Default value under view Drop Down is 'O'Reilly'");       
		System.out.println("is group By Customer checked ? - " +isChecked(reports_projectBtPM_groupByCustomer)); 
		Assert.assertFalse(isChecked(reports_projectBtPM_groupByCustomer));
		logPass("Group By Customer unchecked.");
		JSClick(reports_projectBtPM_search,"Search");    
		verifyTextInColumnClickOtherColumnJS(reports_projectBtPM_PIDs, reports_projectBtPM_magnifier_parametarised, projectId);
		verifyText(reports_projectBtPM_projectViewEditPage_headLine, "Project Details:", "");
		String dueDateFromApplication=getAttributeValue(dashboard_addProject_dueDate, "value");
		//Assert.assertEquals(dueDateWithFormat, dueDateFromApplication);
		verifyText(reports_projectBtPM_project_dueDateChangeNote, "test", "");
		logPass("Project Details page displayed the Due Date we previously entered, the Note section displayed the text entered when we changed the due date");

	}

	private boolean isChecked(String locator) {
		// TODO Auto-generated method stub
		return getElement(locator).isSelected();
	}


}

/*

@Test(alwaysRun=true,enabled=true)
	public void tC_1_35_AddNew_EditProjectDueDate() throws Throwable {

	//	String customer_id="906257";
		String customer_id="31589";
		logger = extent.startTest("1.35 Test ID : 19944 - Premier Svc - 605_Add New and edit Project Due Date");
		type(userNameTxt, "zqa-admin", "User name");
		type(passTxt, "Q@eZL9Pw2D", "Password");
		click(submitBtn, "Submit button");
		type(searchTextBox, customer_id, "Search Box");
		type(searchTextBox,"search box",Keys.ENTER);
		if(verifyElementText(customerTableHeadline, "Customers")) {
			verifyTextInColumnClickOtherColumn(customerIdList, customerName, customer_id); 
		}
		verifyText(customer_dashboard_name, "Customer:", "Customer Name"); //Name To verify - eg.Customer: Novell & Jimenez-Corp (31589)
		scrollElementIntoView(dashboard_addProject);
		JSClick(dashboard_addProject,"Add Project");
		navigateToChild();
		waitForElementToBeClickable(queues_newProject_createAProjectOntoStep2Btn);
		
		actionsClick(dashboard_addProject_projectManager);
		type(projectManager_search1, "Abby Hastings", "Project Manager Search");
		type(projectManager_search1, "Alvin Walker", Keys.ENTER);
		
		JSClick(queues_newProject_createAProjectOntoStep2Btn,"'Create A Project & On to Step2'");
		scrollElementIntoView(queues_createAProjectOntoStep_DueDate);
		JSClick(queues_createAProjectOntoStep_DueDate, "'Due Date from calander'");
		waitForElementPresent(dashboard_addProject_projectId, 20);
		String projectId=getAttributeValue(dashboard_addProject_projectId, "value");
		actionsClick(queues_createAProjectOntoStep_buildProjectTask, "buildProjectTask");
		waitForElementPresent(queues_newProject_saveRecalculateBtn, 20);
		selectDropDownByVisibleText(queues_createAProjectOntoStep_projectStatus_DD, "Ready for FULL Billing");
		if(getCurrentUrl().contains("qa5")) {
		String toDaysDay=dateAftersomeDays(0, "dd");
		String toDaysmonth=dateAftersomeDays(0, "MM");
		String toDaysyear=dateAftersomeDays(0, "yyyy");
		enterDate(queues_createAProjectOntoStep_fullBillDate,toDaysmonth, toDaysDay, toDaysyear);	
		}
		if(getCurrentUrl().contains("qa6")) {
			type(queues_createAProjectOntoStep_fullBillDate, dateAftersomeDays(0, "MMddyyyy"), "full bill date");
		}
		
		Thread.sleep(2000);
		//String alvin_walker="xpath=//*[@id='project_manager']/option[10]";
		//JSClick(dashboard_addProject_projectManager_DD);
		Thread.sleep(1000);
		//actionsClick(alvin_walker);
//Qa6
		selectDropDownByVisibleText(dashboard_addProject_projectManager_DD, "Abby Hastings");	
	//	selectDropDownByVisibleText(dashboard_addProject_projectManager_DD, "Alvin Walker");
				
		
		if(getCurrentUrl().contains("qa5")) {
		String dayAfterDays=dateAftersomeDays(5, "dd");
		String monthAfterDays=dateAftersomeDays(5, "MM");
		String yearAfterDays=dateAftersomeDays(5, "yyyy");
		enterDate(dashboard_addProject_dueDate, monthAfterDays,dayAfterDays, yearAfterDays);	
		}
		if(getCurrentUrl().contains("qa6")) {
		String dueDate=dateAftersomeDays(5, "MMddyyyy");
		type(dashboard_addProject_dueDate, dueDate, "Due Date");
			
		}
		
		String dueDateWithFormat=dateAftersomeDays(5, "yyy-MM-dd");
		actionsClick(queues_newProject_saveRecalculateBtn, "saveRecalculateBtn");
		waitForElementPresent(dashboard_addProject_dueDate_dueDateReasonChange_DD, 20);
		String dueDateReasonChange_DD_value=getDropdownSelectedValue(dashboard_addProject_dueDate_dueDateReasonChange_DD);
		type(dashboard_addProject_dueDate_dueDateChangeNotes, "test", "DueDateChangeNotes");
		Thread.sleep(3000);
		JSClick(dashboard_addProject_dueDate_dueDateChangeNote_saveBtn,"DueDateChangeNote_saveBtn");		
		actionsClick(queues_newProject_saveRecalculateBtn, "saveRecalculateBtn");
		waitForElementPresent(queues_projectBuildSuccessMsg, 20);
		actionsClick(queues_projectBuildSuccessMsg,"projectBuildSuccessMsg_Ok_Button");	
		logPass("Project successfully created with Project Id "+projectId);
		//---		
		click(projectMenu,"project Link");
		click(Reports_projectByPM,"projectByPM");
		waitForElementPresent(Reports_projectByPM_headline, 200);
		//11 the step in test cases - need clarification
		//verifyText(reports_projectBtPM_ProjectManager_DD, "", "");        
		actionsClick(reports_projectBtPM_ProjectManager_DD,"ProjectManager DropDown");
		
		type(projectManager_search, "Abby Hastings", "projectManager Search");
		type(projectManager_search, "Alvin Walker", Keys.ENTER);
		
		       
		String viewDD_value=getDropdownSelectedValue(reports_projectBtPM_view_DD);		
		
		//qa5 condition
		Assert.assertEquals(viewDD_value, "O'Reilly");
		logPass("Default value under view Drop Down is 'O'Reilly'");       
		
		Assert.assertFalse(isChecked(reports_projectBtPM_groupByCustomer));
		logPass("Group By Customer unchecked.");
		JSClick(reports_projectBtPM_search,"Search");    
		verifyTextInColumnClickOtherColumnJS(reports_projectBtPM_PIDs, reports_projectBtPM_magnifier_parametarised, projectId);
		verifyText(reports_projectBtPM_projectViewEditPage_headLine, "Project Details:", "");
		String dueDateFromApplication=getAttributeValue(dashboard_addProject_dueDate, "value");
		//Assert.assertEquals(dueDateWithFormat, dueDateFromApplication);
		verifyText(reports_projectBtPM_project_dueDateChangeNote, "test", "");
		logPass("Project Details page displayed the Due Date we previously entered, the Note section displayed the text entered when we changed the due date");

	}

	private boolean isChecked(String locator) {
		// TODO Auto-generated method stub
		return getElement(locator).isSelected();
	}

*/

