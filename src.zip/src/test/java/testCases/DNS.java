package testCases;

import java.io.File;
import java.sql.Driver;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;

import demo.businesslogic.CommonReusables;
import demo.objectrepository.OR_AddDNS;
import demo.objectrepository.OR_CustInfo;
import demo.objectrepository.OR_DNSRecords;
import demo.objectrepository.OR_HomePage;
import demo.objectrepository.OR_NewMAC;
import demo.objectrepository.OR_ProjectManager;
import demo.objectrepository.OR_SearchPage;

public class DNS extends CommonReusables implements OR_AddDNS, OR_DNSRecords, OR_SearchPage, OR_HomePage, OR_CustInfo,OR_ProjectManager,OR_NewMAC {
     
	 String fs= File.separator;
	 String rtfFilePath=System.getProperty("user.dir")+fs+"TestData"+fs+"test.rtf";
	 @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
    public void data_Dns_Add_Edit_Delete(String zUserName, String zPassword) throws Throwable {
		 String id=getTestData(this.getClass().getSimpleName().substring(0, 3),1);
        logger = extent.startTest("Add DNS");
	    logInfo("Currently Running on -- "+getCurrentUrl());
        logInfo("TestCase Description::Add, Delete and modify DNS on an account");
        userlogin(zUserName, zPassword);
        type(srchTxt, id,"Search box");
        type(srchTxt,"Search box", Keys.ENTER);
        waitForElementPresent(dataLnk, 300);
        //Customer-Data-Dns
        click(dataLnk,"Data Link");
        click(dnsLnk,"DNS Link");
        waitForElementPresent(firstDeleteLnk, 300);
        //Delete
        click(firstDeleteLnk,"Delete Icon");
        Thread.sleep(8000);
        Assert.assertTrue(isAlertPresent());
        dismissAlert();
        waitForElementPresent(viewOrEdit, 300);
        click(viewOrEdit,"View Or Edit Icon");
        Thread.sleep(9000);
        Assert.assertTrue(Driver.getCurrentUrl().toLowerCase().contains("dns"));
        Driver.navigate().back();
        waitForElementPresent(addDnsEntryLnk, 300);
        click(addDnsEntryLnk,"Add DNS Entry Link");
        String name="*.proxy.adjik"+generateRandomString(5);
        waitForElementPresent(dnsNameTxt, 300);
        type(dnsNameTxt,name,"Name");
        type(hostTxt,"172."+randomNum(3)+".72."+randomNum(3),"Host");
        waitForElementPresent(addBtn, 300);
        click(addBtn,"Add button");
        Thread.sleep(9000);
        verifyDNSRecordIsAdded(name);
        logOut();
    }
}
