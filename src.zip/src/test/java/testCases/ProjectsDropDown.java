package testCases;

import java.io.File;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class ProjectsDropDown extends MediatorClass{
	String Reports_projectByVP_dropDownOption_search="xpath=//div[@class='chosen-search']/input";
	 
	  String fs= File.separator;
	  String rtfFilePath=System.getProperty("user.dir")+fs+"TestData"+fs+"test.rtf";
      @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
    public void projectsDropDown(String zUserName, String zPassword) throws Throwable {

        logger = extent.startTest("Verify Projects DropDowns").assignCategory("Projects");
	  logInfo("Currently Running on -- "+getCurrentUrl());
      	logInfo("TestCase Description:  verify Project By PM and calendar by VP Page should be displayed");
                                                                                 
        type(userNameTxt, zUserName, "User name");
        type(passTxt, zPassword, "Password");
        click(submitBtn, "Submit button");
        waitForElementPresent(projectMenu, 300);
        //Verifyng projects By PM        
        logPass("Project Menu-Project By PM");
        Verify(Reports_projectByPM, Reports_projectByPM_headline, "Projects");        
        Verify(Reports_projectByVP, Reports_projectByVP_headline, "Calendar By VP");        
        actionsClick(Reports_projectByVP_dropDown, "Project By VP DropDwon");
        Thread.sleep(1000);
        logPass("Able to select_projectByVP_dropDownOption_search");
        Thread.sleep(3000);        
       logOut();
    }

	private void Verify(String menu, String textElement, String text) throws Throwable {
		click(projectMenu,"project Link");
		click(menu,menu);
		Thread.sleep(5000);
        waitForElementPresent(textElement, 200);
        verifyText(textElement,  text, "Verifying HeadLine text");
	}
}
