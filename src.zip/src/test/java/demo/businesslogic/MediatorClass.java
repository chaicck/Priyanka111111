package demo.businesslogic;

import demo.objectrepository.OR_C3;
import demo.objectrepository.OR_CustomerSearch;
import demo.objectrepository.OR_FAXMail;
import demo.objectrepository.OR_InfroFromBroad;
import demo.objectrepository.OR_LoginPage;
import demo.objectrepository.OR_NumerSearch;

public class MediatorClass extends CommonReusables implements OR_C3,
		OR_CustomerSearch, demo.objectrepository.OR_DevicePageLoad, OR_FAXMail,
		OR_NumerSearch, OR_InfroFromBroad, OR_LoginPage {
	{

	}
}