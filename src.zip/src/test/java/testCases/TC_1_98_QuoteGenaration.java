package testCases;

import java.io.File;

import org.testng.Assert;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class TC_1_98_QuoteGenaration extends MediatorClass {
	  String fs= File.separator;
	  String rtfFilePath=System.getProperty("user.dir")+fs+"TestData"+fs+"test.rtf";
	@Test(alwaysRun = true, enabled = true, dataProvider = "Authentication")
	public void tc_1_98_QuoteGenaration(String zUserName, String zPassword) throws Throwable {

		String customer_id=getTestData(this.getClass().getSimpleName().substring(0, 5),1);

		logger = extent.startTest("1.98 Test ID : 15045 - ZEUS-SALES-2 - Circuit Quote by Customer")
				.assignCategory("Admin");
		logInfo("Currently Running on -- "+getCurrentUrl());
	    logInfo("TestCase Description:Admin Sales Tools Circuit Quote by Customer,Verify the Quotes with  differetn customerID");
	
		type(userNameTxt, zUserName, "User name");
		type(passTxt, zPassword, "Password");
		click(submitBtn, "Submit button");
		
		Verify(sales_tools, sales_tools_circuitQuoteByCustomers, engineering_subMenu_headLine, "Circuit Quote");

		waitForElementPresent(admin_salesTools_cicuit_quote_customerId, 200);
	
		clearText(admin_salesTools_cicuit_quote_customerId);
		type(admin_salesTools_cicuit_quote_customerId, "46941", "");
		actionsClick(admin_salesTools_cicuit_quote_OutSideClick);
		Thread.sleep(1000);
		selectDropDownByVisibleText(admin_salesTools_cicuit_quote_term, "1");
		actionsClick(admin_salesTools_cicuit_quote_submit);

		waitForElementPresent(admin_salesTools_cicuit_quote_submit_success_status, 20);
		verifyText(admin_salesTools_cicuit_quote_submit_success_status, "Success! See details below.", "");
		checkAll(admin_salesTools_cicuit_quote_checkBoxes);
		scrollElementIntoView(admin_salesTools_cicuit_quote_addBtn);

		String selectedQuote = selectedOptionDroDown(admin_salesTools_cicuit_quote_selectedQuoteId_DD);

		waitForElementPresent(admin_salesTools_cicuit_quote_addBtn, 300);
		JSClick(admin_salesTools_cicuit_quote_addBtn);
		waitForElementPresent(sugar_username, 300);
		if(getCurrentUrl().contains("qa5")) {
		type(sugar_username, zUserName, "view In sugar Username");
		type(sugar_password, zPassword, "view In sugar Password");
		}
		else if (getCurrentUrl().contains("qa6")) {  //change qa6 url & credentials
			type(sugar_username, "ppundru", "view In sugar Username");
			type(sugar_password, "Luckylasya1@", "view In sugar Password");
		}
		else  {  //change preDev credentials
			type(sugar_username,"ppundru", "view In sugar Username");
			type(sugar_password, "Luckylasya1@", "view In sugar Password");
		}
		
		click(sugar_loginBtn, "login Button");
		waitForElementPresent(sugar_comapniesMenu, 200);

		// write logic to compare
		System.out.println("selected quote order1 " + selectedQuote);
		waitForElementPresent(sugar_salesOrder, 300);
		System.out.println("sugar salesOrder1 " + getText(sugar_salesOrder));

		
		
		String url=null;
		if(getCurrentUrl().contains("qa5")) {
		url="https://zeus.qa5.vonagenetworks.net/login/view/";		
		}
		else if (getCurrentUrl().contains("qa6")) {
			url="https://zeus.qa6.vonagenetworks.net/login/view/";			
		}
		else {
			url="https://master-hades.hydra.dev.vonagenetworks.net/login/view/";				
		}
		navigateTo(url);
		
		waitForElementPresent(sales_tools_circuitQuoteByCustomers, 300);
		Verify(sales_tools, sales_tools_circuitQuoteByCustomers, engineering_subMenu_headLine, "Circuit Quote");
		waitForElementPresent(admin_salesTools_cicuit_quote_customerId, 20);
		// writing 46941
		clearText(admin_salesTools_cicuit_quote_customerId);
		type(admin_salesTools_cicuit_quote_customerId, "46941", "Circuit quote customerID textfield");
		waitForElementPresent(admin_salesTools_cicuit_quote_OutSideClick, 300);
		actionsClick(admin_salesTools_cicuit_quote_OutSideClick);
		Thread.sleep(1000);
		// selectDropDownByVisibleText(admin_salesTools_cicuit_quote_term, "1");
		waitForElementPresent(admin_salesTools_cicuit_quote_submit, 300);
		JSClick(admin_salesTools_cicuit_quote_submit);
		waitForElementPresent(admin_salesTools_cicuit_quote_submit_success_status, 200);
		verifyText(admin_salesTools_cicuit_quote_submit_success_status, "Success! See details below.", "");
		waitForElementPresent(admin_salesTools_cicuit_quote_checkBoxes, 300);
		actionsClick(admin_salesTools_cicuit_quote_checkBoxes);
		// checkAll(admin_salesTools_cicuit_quote_checkBoxes);
		scrollElementIntoView(admin_salesTools_cicuit_quote_addBtn);

		selectDropDownByVisibleText(admin_salesTools_cicuit_quote_selectedQuoteId_DD, "Create New Quote");
		String selectedQuote2 = selectedOptionDroDown(admin_salesTools_cicuit_quote_selectedQuoteId_DD);
		waitForElementPresent(admin_salesTools_cicuit_quote_addBtn, 300);
		JSClick(admin_salesTools_cicuit_quote_addBtn);

		
		waitForElementPresent(sugar_comapniesMenu, 20);

		// write logic to compare
		System.out.println("selected quote order2 " + selectedQuote2);
		String sugar_salesOrder2 = getText(sugar_salesOrder);
		System.out.println("sugar salesOrder2 " + sugar_salesOrder2);

		
		 
	}

	private void Verify(String menu, String submenu, String textElement, String text) throws Throwable {
		aclick(adminLInk, "Admin LInk");
		aJSClick(menu, menu);
		aJSClick(submenu, submenu);
		waitForElementPresent(textElement, 200);
		verifyText(textElement, text, "Verifying HeadLine text");
	}
}
