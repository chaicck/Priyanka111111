//com.zeus.api.TestIDCreationUiVerification

package qa5_TestCases;

import static com.jayway.restassured.RestAssured.given;
import static master_TestCases.PISignature.calculateSignature;
import static master_TestCases.PISignature.getCurrentDateGmt;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;

import demo.businesslogic.CommonReusables;
import demo.objectrepository.OR_Admin;
import demo.objectrepository.OR_CustInfo;
import demo.objectrepository.OR_HomePage;
import demo.objectrepository.OR_Inventory;
import demo.objectrepository.OR_NewMAC;

import demo.objectrepository.OR_Projects;
import demo.objectrepository.OR_ReconsiliationPage;
import demo.objectrepository.OR_Reports;
import demo.objectrepository.OR_SearchPage;
import utils.WriteToExcel;


public class TestIDCreationUiVerification extends CommonReusables implements OR_Projects, OR_Reports,OR_Admin, OR_SearchPage, OR_HomePage, OR_CustInfo,OR_NewMAC,OR_Inventory, OR_ReconsiliationPage {

	
	    String url="https://hermes.qa5.vonagenetworks.net/zeus/v1/order";
		String key = "QA5_VBSIL";
		String base64Secret = "QA5_kN1pxYJsfeCv5QS2M4m_Y1TSLnhvTpVdjtreud6TS7LXR6bGfsVHE4zxHScMnvom";
		String schema = "PI";
	
	
	String fs=File.separator;
	private String inputFilePath=System.getProperty("user.dir")+fs+"src"+fs+"test"+fs+"resources"+fs+"CreateOrder.json";
	String parentid;
	String childid;

	@Test(priority=0)
	public void apiAccountCreation() throws IOException, EncryptedDocumentException, InvalidFormatException {

		UUID.randomUUID().toString();
		String emailAddress=randomString(6)+"@vonage.com";
		String externalContactID=randomNumString();
		String externalContactID_child=randomNumString();
		String firstName="Automation "+randomString(5);
		String lastName="Last "+randomString(5);
		String locationName="Automation "+randomString(5)+" - Automation Location";
		String locationName_child="Automation "+randomString(5)+" -child Location";
		String name="Automation "+randomString(5);
		String name_child="Automation "+randomString(5)+" child";
		String externalLocationID=randomNumString();
		String description="Description "+randomString(5);
		String gmApprovedDate="2018-04-04T19:00:29."+randomNum(3)+"Z";

		String body=readFileAsString(inputFilePath);
		body=body.replace("$emailAddress",emailAddress);
		body= body.replace("$externalContactID",externalContactID);
		body= body.replace("$firstName",firstName);
		body= body.replace("$lastName",lastName);
		body=body.replace("$locationName",locationName);
		body=body.replace("$name",name);
		body.replace("$parentCustomerID","00000");
		//created by me 00554000000kYU3AAM
		body=body.replace("$externalID", "00554000000kYU3AAM");
		body= body.replace("$externalLocationID",externalLocationID);
		//created by me
		body= body.replace("$externalQuoteID","a39540000000iWeAAI");
		body= body.replace("$description",description);
		body=body.replace("$gmApprovedDate",gmApprovedDate);
		body=body.replace("$externalID1", "00554000000kYU3AAM");

		//String key = "ENTERPRISE_IL";
		//String base64Secret = "Oe5LNk4VFtDC3Clk3JkqqPcDkDDb06uVmDn0rf2Trq22wLBPwAdKaqDjHVBQ1JKH";
		//String schema = "PI";
		String dte=getCurrentDateGmt().toLowerCase();
		byte[] bodyByte=body.getBytes();
		String stringToSign=calculateSignature("post","/zeus/v1/order",dte,bodyByte,base64Secret,true);
		String fin=schema+" "+key+":"+stringToSign;
		System.out.println("====>"+fin);
		Response response=  given().
				header("Content-Type","application/json").
				header("xdebug_session","PHPSTORM").
				header("authorization",fin).
				header("x-von-date",dte)
				.with().
				contentType(ContentType.JSON).
				body(body).
				when().
				post(url);
		// response.prettyPeek();
		Assert.assertEquals(response.getStatusCode(), 200 );

		String res=response.asString();
		/* System.out.println("As a string"+response.asString());
		System.out.println("As a prettypeak"+response.prettyPeek());
        System.out.println("As a print"+response.print());
        System.out.println("As a print"+response.getStatusCode());
        System.out.println("to a string" + response.toString());
        System.out.println("body : "+body); */
		//System.out.println("body : "+body);
		parentid=res.substring(15, 21);

		String location=System.getProperty("user.dir")+"\\TestData\\qa5_pqtc_Accounts.xlsx";
		WriteToExcel.intialiseExcel(location);  

		WriteToExcel.writeExcel("Parent Account creation; Data");
		//contacts
		WriteToExcel.writeExcel("Contacts;****");
		WriteToExcel.writeExcel("emailAddress;"+emailAddress);
		WriteToExcel.writeExcel("externalContactID;"+externalContactID);
		WriteToExcel.writeExcel("firstName;"+firstName);
		WriteToExcel.writeExcel("lastName;"+lastName);
		WriteToExcel.writeExcel("types;billing, afterHours, primary, technical, onsite, authorized");
		//customer
		WriteToExcel.writeExcel("customer;****");
		WriteToExcel.writeExcel("billingAddress;\"city\" : \"Holmdel\", \"country\" : \"US\", \"line1\" : \"22 W Main Street\", \"line2\" : \"\", \"stateOrProvince\" : \"NJ\", \"zipOrPostalCode\" : \"07733\"");
		WriteToExcel.writeExcel("installAddress;\"city\" : \"HOLMDEL\", \"country\" : \"US\", \"line1\" : \"45 W MAIN ST\", \"line2\" : \"\", \"stateOrProvince\" : \"NJ\", \"zipOrPostalCode\" : \"07733\"");

		WriteToExcel.writeExcel("locationName;"+locationName);
		WriteToExcel.writeExcel("name;"+name);
		WriteToExcel.writeExcel("parentCustomerID;00000");

		WriteToExcel.writeExcel("paymentAccountID;_");
		WriteToExcel.writeExcel("salesMarket;_");
		WriteToExcel.writeExcel("salesPerson;\"emailAddress\" : \"sfdcvon@gmail.com\", \"externalID\" : \"00554000000kYU3AAM\", \"firstName\" : \"Premier\", \"lastName\" : \"Sales Closer\"");
		WriteToExcel.writeExcel("salesTeam;_");
		WriteToExcel.writeExcel("taxExemptStatus;None");

		WriteToExcel.writeExcel("externalLocationID;"+externalLocationID);
		WriteToExcel.writeExcel("externalQuoteID;a39540000000iWeAAI");

		WriteToExcel.writeExcel("Order - description;"+description);
		WriteToExcel.writeExcel("gmApprovedDate;"+gmApprovedDate);
		WriteToExcel.writeExcel("Sales Person - externalID;00554000000kYU3AAM");
		WriteToExcel.writeExcel("uuID;05057");

		WriteToExcel.writeExcel("Parent Id Genarated;"+parentid);		

		System.out.println("Parent Id **********  " +parentid +" ********************");


		//Child - creation
		//String body=readFileAsString(inputFilePath);

		body= body.replace(externalContactID,externalContactID_child);
		body=body.replace(locationName,locationName_child);
		body=body.replace(name,name_child);
		body.replace("00000",parentid);
		//43
		body=body.replace("$externalID", "00554000000kYU"+parentid.substring(1));
		// 43 last 43,  50,51,76(full parent Id) 
		body= body.replace(externalLocationID,externalLocationID.substring(0, externalLocationID.length()-5)+parentid);
		body=body.replace("$externalQuoteID", "a39540000000i"+parentid);
		body=body.replace("$externalID1", "00554000000kY"+parentid);

		String dte_child=getCurrentDateGmt().toLowerCase();
		byte[] bodyByte_child=body.getBytes();
		String stringToSign_child=calculateSignature("post","/zeus/v1/order",dte_child,bodyByte_child,base64Secret,true);
		String fin_child=schema+" "+key+":"+stringToSign_child;
		System.out.println("====>"+fin_child);
		Response response_child=  given().
				header("Content-Type","application/json").
				header("xdebug_session","PHPSTORM").
				header("authorization",fin_child).
				header("x-von-date",dte_child)
				.with().
				contentType(ContentType.JSON).
				body(body).
				when().
				post(url);

		// response_child.prettyPeek();
		Assert.assertEquals(response_child.getStatusCode(), 200 );

		String chil_res=response_child.asString();
		//System.out.println("body"+body);
		childid=chil_res.substring(15, 21);

		WriteToExcel.writeExcel("Child Account creation; Data");
		//contacts
		WriteToExcel.writeExcel("Data Changed apart from Parent Data;****");
		WriteToExcel.writeExcel("externalContactID_child;"+externalContactID_child);
		WriteToExcel.writeExcel("locationName_child;"+locationName_child);
		WriteToExcel.writeExcel("name_child;"+name_child);
		WriteToExcel.writeExcel("parentid;"+parentid);
		WriteToExcel.writeExcel("externalID;00554000000kYU"+parentid.substring(1));
		WriteToExcel.writeExcel("externalLocationID;"+externalLocationID.substring(0, externalLocationID.length()-5)+parentid);
		WriteToExcel.writeExcel("externalQuoteID;a39540000000i"+parentid);
		WriteToExcel.writeExcel("Sales Person-externalID;00554000000kY"+parentid);
		WriteToExcel.writeExcel("Child Account created;"+childid);


		WriteToExcel.closeExcelConnection();		

		System.out.println("child Id **********  " +childid +" ********************");

	}

	@Test(priority=1, dependsOnMethods="apiAccountCreation")
	public void parentUserAccountVerification() throws Throwable {

		String customer_id=parentid;
		String contract_id;
		logger = extent.startTest("Verifying customer Home");
		type(userNameTxt, "ppundru", "User name");
		type(passTxt, "Ramareddy1@", "Password");
		click(submitBtn, "Submit button");
		type(searchTextBox, customer_id, "Search Box");
		type(searchTextBox,"search box",Keys.ENTER);

		if(verifyElementText(customerTableHeadline, "Customers")) {

			verifyTextInColumnClickOtherColumn(customerIdList, customerName, customer_id); 

		}


		verifyText(customer_dashboard_name, "Customer:", "Customer Name"); //Name To verify - eg.Customer: Novell & Jimenez-Corp (31589)
		scrollElementIntoView(customer_dashboard_contacts);
		actionsClick(customer_dashboard_contacts);
		verifyTextPresentInList(customer_dashBoard_contacts_nameList, ""); // customer Name
		verifyTextPresentInList(customer_dashBoard_contacts_nameEmail, ""); // customer email
        Thread.sleep(8000);
		click(customerHome_billing,"customerHome billing");
		actionsClick(customerHome_billing_contracts);
		actionsClick(customerHome_billing_contracts_list);
		Thread.sleep(60000);

		
		if (!verifyElementText(billing_contracts_contractIdList,"")) {
			waitForTextPresentByBrowerRefresh(billing_contracts_contractIdList,2,20);
		}
				
		contract_id=getText(billing_contracts_contractIdList);
		Assert.assertTrue(contract_id!=null);
		actionsClick(billing_contracts_magnifierList);


		// logging into view In menu - engage
		click(customerHome_viewInMenu, "customerHome_viewInMenu");
		click(customerHome_viewInMenu_engage, "customerHome viewIn Menu engage");
		navigateToChild();
		Thread.sleep(5000);

		type(engageIp_username, " ZeusQA", "Engage Ip Username");
		type(engageIp_password, " t3$tp@sS0rd", "Engage Ip Password");
		click(engageIp_loginBtn, "login Button");
		waitForElementToBeClickable(engageIp_contactsTab);
		click(engageIp_contactsTab, "Enagage IP -Contacts Tab");
		verifyText(engageIp_contactsPageTitle, "CONTACTS", "Contacts");

		click(engageIp_overViewTab, "Enagage IP OverviewTab");
		System.out.println(getText(engageIp_overView_packagesTitle));
		verifyText(engageIp_overView_packagesTitle, "PACKAGES", "Packages");

		navigateBackToParentWindow();

		click(customerHome_Queues, "Queues Menu");
		actionsClick(queues_newProjects);
		type(queues_search, contract_id, "");
		Thread.sleep(1000);
		actionsClick(queues_success_greenBtn);
		waitForElementToBeClickable(queues_newProject_createAProjectOntoStep2Btn);
		actionsClick(queues_newProject_createAProjectOntoStep2Btn);
		scrollElementIntoView(queues_createAProjectOntoStep_DueDate);
		JSClick(queues_createAProjectOntoStep_DueDate);
		actionsClick(queues_createAProjectOntoStep_buildProjectTask);

		waitForElementPresent(queues_newProject_saveRecalculateBtn, 20);

		selectDropDownByVisibleText(queues_createAProjectOntoStep_projectStatus_DD, "Ready for FULL Billing");
		type(queues_createAProjectOntoStep_fullBillDate, toDaysdate(), "full bill date");
		actionsClick(queues_newProject_saveRecalculateBtn);
		 waitForElementPresent(queues_projectBuildSuccessMsg, 20);
		actionsClick(queues_projectBuildSuccessMsg);
		click(customerHome_Queues, "Queues Menu");
		actionsClick(queue_billing);
		type(queue_billing_search, customer_id, "");
		actionsClick(queue_billing_processLnkList);

		navigateToChild();
		actionsClick(queue_billing_pushToBilling2);
		Thread.sleep(5000);

		actionsClick(queue_billing_pushToBilling_addView);
		Thread.sleep(5000);

		actionsClick(queue_billing_pushToBilling_viewInEngage);
		Thread.sleep(15000);
		
		navigateToChild();
		
		 String engageCurrentUser="id=CurrentUsername";
	        if(!getText(engageCurrentUser).contains(customer_id)) {
	        	System.out.println("Customer Id is not correct in Engage");
	        	currentWindowClose();
	        	navigateBackToParentWindow();
	        	Thread.sleep(1000);
	        	click(customerHome_viewInMenu, "customerHome_viewInMenu");
		        click(customerHome_viewInMenu_engage, "customerHome viewIn Menu engage");
		        navigateToChild();
		        Thread.sleep(5000);
	        }
	        System.out.println(getText(engageCurrentUser));
	        Assert.assertTrue(getText(engageCurrentUser).contains(customer_id));  

		//move back to parent tab
		navigateBackToParentWindow();

		click(adminLInk,"Admin LInk");
		click(automation, "Automation");
		JSClick(automation_automation_viewAutomation);
		type(queue_billing_search, "ENGAGE", "");
		//16th point - 1 stpe (clicking on Run)
		Thread.sleep(1000);
		actionsClick(queue_billing_run);
		Thread.sleep(2000);
		waitForElementToBeClickable(queue_billing_run_run);
		actionsClick(queue_billing_run_run);

		Thread.sleep(15000);
		waitForElementPresent(queue_billing_run_successText, 30);
		verifyText(queue_billing_run_successText, "Successful", "Successful Msg");

		click(srchDd,"Search");	         
		click(customerLnk,"Customer link");        
		type(srchTxt, customer_id,"Search box"); //search text
		type(srchTxt,"Search box",Keys.ENTER);        
		verifyText(customerNamefromTable,  "", "customer name");    //customer name that needds to verify    

	}

	@Test(priority=2, dependsOnMethods="apiAccountCreation")
	public void childUserAccountVerification() throws Throwable {

		String customer_id=childid;
		String contract_id;
		logger = extent.startTest("Verifying customer Home");
		type(userNameTxt, "ppundru", "User name");
		type(passTxt, "Ramareddy1@", "Password");
		click(submitBtn, "Submit button");

		type(searchTextBox, customer_id, "Search Box");
		type(searchTextBox,"search box",Keys.ENTER);

		if(verifyElementText(customerTableHeadline, "Customers")) {

			verifyTextInColumnClickOtherColumn(customerIdList, customerName, customer_id); 

		}


		verifyText(customer_dashboard_name, "Customer:", "Customer Name"); //Name To verify - eg.Customer: Novell & Jimenez-Corp (31589)
		scrollElementIntoView(customer_dashboard_contacts);
		actionsClick(customer_dashboard_contacts);
		verifyTextPresentInList(customer_dashBoard_contacts_nameList, ""); // customer Name
		verifyTextPresentInList(customer_dashBoard_contacts_nameEmail, ""); // customer email

		click(customerHome_billing,"customerHome billing");
		actionsClick(customerHome_billing_contracts);
		actionsClick(customerHome_billing_contracts_list);
		Thread.sleep(3000);
		

		
		if (!verifyElementText(billing_contracts_contractIdList,"")) {
			waitForTextPresentByBrowerRefresh(billing_contracts_contractIdList,2,20);
		}
				
		

		contract_id=getText(billing_contracts_contractIdList);
		actionsClick(billing_contracts_magnifierList);


		// logging into view In menu - engage
		click(customerHome_viewInMenu, "customerHome_viewInMenu");
		click(customerHome_viewInMenu_engage, "customerHome viewIn Menu engage");
		navigateToChild();
		Thread.sleep(5000);

		//	        type(engageIp_username, "Admin", "Engage Ip Username");
		//	        type(engageIp_password, "1QR2NsOAmM4", "Engage Ip Password");



		type(engageIp_username, " ZeusQA", "Engage Ip Username");
		type(engageIp_password, " t3$tp@sS0rd", "Engage Ip Password");

		click(engageIp_loginBtn, "login Button");
		waitForElementToBeClickable(engageIp_contactsTab);
		click(engageIp_contactsTab, "Enagage IP -Contacts Tab");
		verifyText(engageIp_contactsPageTitle, "CONTACTS", "Contacts");

		click(engageIp_overViewTab, "Enagage IP OverviewTab");
		System.out.println(getText(engageIp_overView_packagesTitle));
		verifyText(engageIp_overView_packagesTitle, "PACKAGES", "Packages");

		navigateBackToParentWindow();

		click(customerHome_Queues, "Queues Menu");
		actionsClick(queues_newProjects);
		type(queues_search, contract_id, "");
		Thread.sleep(1000);
		actionsClick(queues_success_greenBtn);
		waitForElementToBeClickable(queues_newProject_createAProjectOntoStep2Btn);
		actionsClick(queues_newProject_createAProjectOntoStep2Btn);
		scrollElementIntoView(queues_createAProjectOntoStep_DueDate);
		JSClick(queues_createAProjectOntoStep_DueDate);
		//actionsClick(queues_createAProjectOntoStep_DueDate);
		actionsClick(queues_createAProjectOntoStep_buildProjectTask);

		waitForElementPresent(queues_newProject_saveRecalculateBtn, 20);

		selectDropDownByVisibleText(queues_createAProjectOntoStep_projectStatus_DD, "Ready for FULL Billing");
		type(queues_createAProjectOntoStep_fullBillDate, toDaysdate(), "full bill date");
		actionsClick(queues_newProject_saveRecalculateBtn);
		 waitForElementPresent(queues_projectBuildSuccessMsg, 20);
		actionsClick(queues_projectBuildSuccessMsg);
		click(customerHome_Queues, "Queues Menu");
		actionsClick(queue_billing);
		type(queue_billing_search, customer_id, "");
		actionsClick(queue_billing_processLnkList);

		navigateToChild();
		actionsClick(queue_billing_pushToBilling2);
		Thread.sleep(5000);

		actionsClick(queue_billing_pushToBilling_addView);
		Thread.sleep(5000);

		actionsClick(queue_billing_pushToBilling_viewInEngage);
		Thread.sleep(15000);
		
		navigateToChild();
		
		 String engageCurrentUser="id=CurrentUsername";
	        if(!getText(engageCurrentUser).contains(customer_id)) {
	        	System.out.println("Customer Id is not correct in Engage");
	        	currentWindowClose();
	        	navigateBackToParentWindow();
	        	Thread.sleep(1000);
	        	click(customerHome_viewInMenu, "customerHome_viewInMenu");
		        click(customerHome_viewInMenu_engage, "customerHome viewIn Menu engage");
		        navigateToChild();
		        Thread.sleep(5000);
	        }
	        System.out.println(getText(engageCurrentUser));
	        Assert.assertTrue(getText(engageCurrentUser).contains(customer_id));  


		//move back to parent tab
		navigateBackToParentWindow();
		
		         click(adminLInk,"Admin LInk");
		         click(automation, "Automation");
		         JSClick(automation_automation_viewAutomation);
		         type(queue_billing_search, "ENGAGE", "");
		         //16th point - 1 stpe (clicking on Run)
		         Thread.sleep(1000);
		         actionsClick(queue_billing_run);
		         Thread.sleep(2000);
		         waitForElementToBeClickable(queue_billing_run_run);
		         actionsClick(queue_billing_run_run);

		         Thread.sleep(15000);
		         waitForElementPresent(queue_billing_run_successText, 30);
		         verifyText(queue_billing_run_successText, "Successful", "Successful Msg");
		 
		click(srchDd,"Search");	         
		click(customerLnk,"Customer link");        
		type(srchTxt, customer_id,"Search box"); //search text
		type(srchTxt,"Search box",Keys.ENTER);        
		// verifyText(customerNamefromTable,  "", "customer name");    //customer name that needds to verify    




	}

}
