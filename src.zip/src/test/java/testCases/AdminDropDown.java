package testCases;

import java.io.File;

import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;
import demo.objectrepository.OR_Admin;

public class AdminDropDown extends MediatorClass{
	 
	
	 String fs= File.separator;
	    String rtfFilePath=System.getProperty("user.dir")+fs+"TestData"+fs+"test.rtf";
	 @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
	public void adminDropDown(String zUserName, String zPassword) throws Throwable {

		logger = extent.startTest("Admin DropDown options verification").assignCategory("Admin","Regression test");
		logInfo("Currently Running on -- "+getCurrentUrl());
		logInfo("TestCase Description:Verify all menu's and submenu's under the Admin dropdown");
		type(userNameTxt, zUserName, "User name");
		type(passTxt, zPassword, "Password");
		JSClick(submitBtn);
		//Verify(agent_portal,"Agent Portal Admin",agent_portal_agent ,"Agent Portal - Agents",agent_portal_headline, "Agent Portal Admin - Agents");
		//Verify(agent_portal,"agent_portal",agent_portal_agent,"agent_portal_agent" ,agent_portal_headline, "Agent Portal Admin - Agents");
		
		
		Verify(agent_portal,"Agent Portal Admin",agent_portal_faq,"Agent Portal - FAQs" ,agent_portal_headline, "Agent Portal Admin - FAQ");
		// wrong Heading - Verify once
		Verify(agent_portal,"Agent Portal Admin",agent_portal_files,"Agent Portal - Files",agent_portal_headline, "Agent Portal Admin - Demos");
		Verify(agent_portal,"Agent Portal Admin",agent_portal_messages,"Agent Portal - Messages" ,agent_portal_headline, "Agent Portal Admin - Messages");
		Verify(agent_portal,"Agent Portal Admin",agent_portal_news,"Agent Portal - News" ,agent_portal_headline, "Agent Portal Admin - News");
		//not present in qa6
		//Verify(agent_portal,agent_portal_products ,agent_portal_headline, "Agent Portal Admin - Products");
		Verify(agent_portal,"Agent Portal Admin",agent_portal_promos,"Agent Portal - Files",agent_portal_headline, "Agent Portal Admin - Promos");
		Verify(agent_portal,"Agent Portal Admin",agent_portal_training_sessions,"Agent Portal - Training Sessions" ,agent_portal_headline, "Agent Portal Admin - Training Sessions");
		Verify(agent_portal,"Agent Portal Admin",agent_portal_users,"Agent Portal - Users" ,agent_portal_headline, "Agent Portal Admin - Users");
		//not present in qa6 only in QA5
	   // Verify(agent_portal,agent_portal_videos,"Agent Portal Admin" ,agent_portal_headline,"Agent Portal - Vedios", "Agent Portal Admin - Webinars");


		Verify(automation,"Automation",automation_automation_log,"Automation-Log",automation_headline, "Automation Log Runs");
		Verify(automation,"Automation",automation_automation_report,"Automation-Report",automation_headline, "Automation Report");
		Verify(automation,"Automation",automation_automation_viewAutomation,"Automation-ViewAutomation",automation_headline, "Automations");

		Verify(c3_admin,"C3 Admin",c3_domain_broadworks_service_packs,"BW Service Packs" ,c3_domain_headline, "Broadworks Service Packs");
		Verify(c3_admin,"C3 Admin",c3_domain_bulk_update_service_packs,"Bulk Service Packs" ,c3_domain_headline, "Bulk Update Service Packs");
		Verify(c3_admin,"C3 Admin",c3_domain_equipment,"C3 Equipment" ,c3_domain_headline, "C3 Equipment");
		Verify(c3_admin,"C3 Admin",c3_domain_phone_types," Phone Types" ,c3_domain_headline, "C3 Phone Types");
		Verify(c3_admin,"C3 Admin",c3_domain_service_packs ,"Service_Packs",c3_domain_headline, "Service Packs");        
		Verify(c3_admin,"C3 Admin",c3_domain_services ,"Services",c3_domain_headline, "Services");


		VerifyClick(dev,"Dev",dev_audit_log,"Audit Log" );
		VerifyClick(dev,"Dev",dev_reset_broadWorks," Reset Broadworks Password Rules");
		VerifyClick(dev,"Dev",dev_sync_customer,"Sync Customer to Zeus");
		VerifyClick(dev,"Dev",dev__icons," Icons");
		VerifyClick(dev,"Dev",dev_salesForceBrowser,"Salesforce Browser" );

		Verify(devices,"Devices",device_bulk_change_notes,"Bulk Change Notes" ,device_subMenu_headline, "Change Device Notes");
		Verify(devices,"Devices",device_snmp,"SNMP",device_subMenu_headline, "Device SNMP Types");
		Verify(devices,"Devices",device_bulk_circuit_migration,"Bulk_Circuit_Migration",device_subMenu_headline, "Select a Device Name that is tied to a Circuit that you want to export:");
		Verify(devices,"Devices",device_templates ,"Templates",device_subMenu_headline, "Device Templates");
		Verify(devices,"Devices",device_types, "Types",device_subMenu_headline, "Device Types");


		Verify(engineering,"Engineering",engineering_bulk_dns_update,"DNS" ,engineering_subMenu_headLine, "DNS");
		Verify(engineering,"Engineering",engineering_carriers,"Carriers" ,engineering_subMenu_headLine, "Carriers");
		Verify(engineering,"Engineering",engineering_manage_eicb_default_watchers,"Manage_EICB_Default_Watchers" ,engineering_subMenu_headLine, "Default EICB Watchers");
		Verify(engineering,"Engineering",engineering_manage_eicb_categories,"Manage_EICB_Categories" ,engineering_subMenu_headLine, "EICB Categories");
		Verify(engineering,"Engineering",engineering_pops,"POPS" ,engineering_subMenu_headLine, "POPs");
		Thread.sleep(1000);


		Verify(email_notification_tool_logs,"Customer Email_Notification_Tool",email_notification_tool_logs_CustomerEmailNotificationTool,"Customer Notify" ,engineering_subMenu_headLine, "Customer Notification Tool");
		Verify(email_notification_tool_logs,"Email_Notification_Tool_logs",email_notification_tool_email_notificationLog ,"email_notification_tool_email_notificationLog",engineering_subMenu_headLine, "Search Notification Logs");
		Verify(customer_portal,"Customer Portal",customer_portal_msg_of_the_day,"Message of the day" ,customer_portal_headline, "Message of the day messages");
		
		Verify(hermes,"Hermes",hermes_admin_hmac_control,"Admin Hmac Control" ,engineering_subMenu_headLine, "User Parent");
		Verify(hermes,"Hermes",hermes_refreshMenthodsForPermissions,"Refresh Methods for Permissions",engineering_subMenu_headLine, " ");
		Verify(hermes,"Hermes",hermes_manageCustomerAgreements ,"Manage Customer Agreements",engineering_subMenu_headLine, "Agreements");



		//Not working
		Verifyy(OR_Admin.inventory,"Inventory",inventory_netcMapping ,"NetX Mapping",engineering_subMenu_headLine, "NetX Mapping");
		Verifyy(OR_Admin.inventory,"Inventory",inventory_partsListMappings," Parts List Mapping" ,engineering_subMenu_headLine, "Parts List Mapping");
		Verifyy(OR_Admin.inventory,"Inventory",inventory_uploadNextReport," Import Netx Report" ,engineering_subMenu_headLine, "Upload NetX Report");
		

		//not present in qa6
		//Verify(nexmo_gdm,"NEXAMO &GDM",nexmo_gdm_importPremierCentralNo ,"Manage Numbers",engineering_subMenu_headLine, "Premier Central Numbers Import");
		Verify(nexmo_gdm,"NEXAMO &GDM",nexmo_gdm_managePremierCentralNo,"Manage Numbers" ,engineering_subMenu_headLine, "Premier Central Numbers");
		Verify(nexmo_gdm,"NEXAMO &GDM",nexmo_gdm_configuration,"Nexmo Feature Control" ,engineering_subMenu_headLine, "Nexmo & GDM Controls");

		Verify(noc,"NOC",noc_messageBoard,"Message Board Management" ,engineering_subMenu_headLine, "Message Board Messages");
		Verify(noc,"NOC",noc_rePushCdrFile," Re-push CDR file" ,engineering_subMenu_headLine, "CDR Repush Request Queue");

		Verify(notifications,"Notification",notifications_addNotification ,"Add Notification Type",engineering_subMenu_headLine, "Notification Type");
		Verify(notifications,"Notification",notifications_editNotification ," Edit Notification Type",engineering_subMenu_headLine, "Notification Types");

		Verify(ip_management,"IP Management",ip_management_ipNetworkTreeView,"IP Network Treeview" ,engineering_subMenu_headLine, "IP Network Tree View");
		Verify(ip_management,"IP Management",ip_management_typeManagementNetwork," Type Management - Network" ,engineering_subMenu_headLine, "List of Network Block Types");
		Verify(ip_management,"IP Management",ip_management_typeManagementCustomerType," Type Management -CustomerType" ,engineering_subMenu_headLine, "List of Customer IP Types");
		Verify(ip_management,"IP Management",ip_management_cidrBlockManagement," CIDR Block Management" ,engineering_subMenu_headLine, "List of IP CIDR Blocks");
		Verify(ip_management,"IP Management",ip_management_networkBlockManagement ,"NetWork Block Managment",engineering_subMenu_headLine, "List of IP Network Blocks");

		Verify(numbers,"Numbers",numbers_inventoryImport ,"Inventory Import",engineering_subMenu_headLine, "TN Import");
		VerifyClick(numbers,"Numbers",numbers_nnacl,"NNACL" );
		Verify(numbers,"Numbers",numbers_pseudo,"Pseudo NPA/NXXs" ,engineering_subMenu_headLine, "Pseudo Entries");

		// not present in qa6
		/* Verify(order_portal,order_portal_productFields ,engineering_subMenu_headLine, "Product Fields");
        Verify(order_portal,order_portal_priceBook ,engineering_subMenu_headLine, "Customer Pricebooks");*/


		String admin_permissions="id=notification-permissions";
		String admin_permissions_subMenu_headLine="xpath=//div[@class='clearfix']";

		String admin_permissions_manageGroups="id=notification-manage-groups";
		String admin_permissions_manageUserGroups="id=notification-manage-user-groups";
		String admin_permissions_manageUserByGroup="id=notification-users-by-group";
		String admin_permissions_manageUserManageMethods="id=notification-manage-methods";
		String admin_permissions_manageMethodGroups="id=notification-manage-method-groups";
		String admin_permissions_refreshMethodsFromCode="id=notification-refresh-methods-from-code";
		String admin_permissions_manageCustomerProfiles="id=notification-manage-customer-profiles";
		String admin_permissions_manageCustomerAccess="id=notification-manage-customer-access";

		Verify(admin_permissions," Permissions",admin_permissions_manageGroups,"Manage Groups" ,admin_permissions_subMenu_headLine, "Manage Groups");
		Verify(admin_permissions," Permissions",admin_permissions_manageUserGroups,"Manage User Groups",admin_permissions_subMenu_headLine, "User Group Assignment");
		Verify(admin_permissions," Permissions",admin_permissions_manageUserByGroup,"Manage User By Group" ,admin_permissions_subMenu_headLine, "Users By Permissions Group");
		Verify(admin_permissions," Permissions",admin_permissions_manageUserManageMethods ,"Manage Methods",admin_permissions_subMenu_headLine, "Manage Methods");        
		Verify(admin_permissions," Permissions",admin_permissions_manageMethodGroups,"Manage Method Groups" ,admin_permissions_subMenu_headLine, "Method Groups");
		Verify(admin_permissions," Permissions",admin_permissions_refreshMethodsFromCode,"Refresh Methods From Code" ,admin_permissions_subMenu_headLine, "Refresh Methods for Permissions");
		Verify(admin_permissions," Permissions",admin_permissions_manageCustomerProfiles,"Manage Customer Profiles" ,admin_permissions_subMenu_headLine, "Manage Customer Profile");
		Verify(admin_permissions," Permissions",admin_permissions_manageCustomerAccess,"Manage Customer Access" ,admin_permissions_subMenu_headLine, "Customer Access");

		Verify(sales_tools,"Sales_Tools",sales_tools_circuitQuoteByCustomers,"Circuit Quote By Customer" ,engineering_subMenu_headLine, "Circuit Quote");
		VerifyClick(sales_tools,"Sales_Tools",sales_tools_circuitQuoteByAddress,"Circuit Quote By Address");
		Verify(sales_tools,"Sales_Tools",sales_tools_CreateExternalEicb,"Create External EICB" ,engineering_subMenu_headLine, "External Engineering ICB");
		Verify(sales_tools,"Sales_Tools",sales_tools_pcat,"PACT" ,engineering_subMenu_headLine, "Product Catalog (PCAT)");
		Verify(sales_tools,"Sales_Tools",sales_tools_quota ,"Quota",engineering_subMenu_headLine, "Search Team Quota");
		//Hidden Menu        
		Verify(sales_tools,"Sales_Tools",sales_tools_quotaStage,"Quota Stage" ,engineering_subMenu_headLine, "Quote Stage");
		Verify(sales_tools,"Sales_Tools",sales_tools_salesOrderEdit,"Sales Order Edit" ,engineering_subMenu_headLine, "Search");


		Verify(reconciliation,"Reconciliation",reconciliation_reconMacProductMapping," Reconciliation MAC Product Mapping" ,engineering_subMenu_headLine, "MAC Product Mapping");


		//Service Delivery
		String admin_serviceDelivery="id=notification-service-delivery";
		String admin_serviceDelivery_dispatch="xpath=//a[@href='/dispatch/dispatchAdmin/']";
		String admin_serviceDelivery_editProjectCancelReason="id=notification-edit-project-cancel-reasons";
		String admin_serviceDelivery_editProjectJeopReasons="id=notification-edit-project-jeop-reasons";
		String admin_serviceDelivery_editProjectTemplates="id=notification-edit-project-templates";
		String admin_serviceDelivery_editSowTemplate="id=notification-edit-sow-template";
		String admin_serviceDelivery_editSystemTasks="id=notification-edit-system-tasks";
		String admin_serviceDelivery_ManageProjectTypes="id=notification-manage-project-types";
		String admin_serviceDelivery_manageC3Calanders="id=notification-manage-c3-calendars";
		String admin_serviceDelivery_manageC3CalandersTypes="id=notification-manage-c3-calendar-types";
		String admin_serviceDelivery_manageWorkQueues="id=notification-manage-work-queues";

		Verify(admin_serviceDelivery,"Service Delivery Menu",admin_serviceDelivery_dispatch ,"Dispatch",admin_permissions_subMenu_headLine, "Dispatch Admin");
		Verify(admin_serviceDelivery,"Service Delivery Menu",admin_serviceDelivery_editProjectCancelReason,"Edit Project Cancel Reason" ,admin_permissions_subMenu_headLine, " Project Cancel Reasons");
		Verify(admin_serviceDelivery,"Service Delivery Menu",admin_serviceDelivery_editProjectJeopReasons ,"Edit Project Jeop Reasons",admin_permissions_subMenu_headLine, "Edit Project Jeop Reasons");
		Verify(admin_serviceDelivery,"Service Delivery Menu",admin_serviceDelivery_editProjectTemplates,"Edit Project Templates" ,admin_permissions_subMenu_headLine, "Project Templates");
		Verify(admin_serviceDelivery,"Service Delivery Menu",admin_serviceDelivery_editSowTemplate,"Edit Sow Template" ,admin_permissions_subMenu_headLine, "Edit Scope of Work Template");
		Verify(admin_serviceDelivery,"Service Delivery Menu",admin_serviceDelivery_editSystemTasks,"Edit System Tasks" ,admin_permissions_subMenu_headLine, "System Tasks");
		Verify(admin_serviceDelivery,"Service Delivery Menu",admin_serviceDelivery_ManageProjectTypes,"Manage Project Types" ,admin_permissions_subMenu_headLine, "Project Types");
		Verify(admin_serviceDelivery,"Service Delivery Menu",admin_serviceDelivery_manageC3Calanders,"Manage C3 Calanders" ,admin_permissions_subMenu_headLine, "C3 Calendar");
		Verify(admin_serviceDelivery,"Service Delivery Menu",admin_serviceDelivery_manageC3CalandersTypes,"Manage C3 Calanders Types" ,admin_permissions_subMenu_headLine, "Manage Calendar Types");
		Verify(admin_serviceDelivery,"Service Delivery Menu",admin_serviceDelivery_manageWorkQueues,"Manage Work Queues" ,admin_permissions_subMenu_headLine, "Manage Work Queues");




		Verify(user,"Users",user_addNewUser ,"Add Users",engineering_subMenu_headLine, "Add User");
		Verify(user,"Users",user_manageUsers,"Manager Users" ,engineering_subMenu_headLine, "Zeus Users");
		//Hidden Menu        
		Verify(user,"Users",user_manageUserLocations,"Manage User Lopcations" ,engineering_subMenu_headLine, "User Locations"); 



		Verify(zeus_admin,"zeus_admin",zeus_admin_CircuitQuoteProviders,"Circuit Quote Providers" ,engineering_subMenu_headLine, "Circuit Quote Providers");
		// Hidden Menu      
		Verify(zeus_admin,"zeus_admin",zeus_admin_faxBack,"Fax Back" ,engineering_subMenu_headLine, "Faxback Configuration");
		Verify(zeus_admin,"zeus_admin",zeus_admin_hostedPayment,"Hosted Payment" ,engineering_subMenu_headLine, "HPP Page Configuration");
		Verify(zeus_admin,"zeus_admin",zeus_admin_platformConfiguration,"Platform Configuration" ,engineering_subMenu_headLine, "Platform Configuration");
		Verify(zeus_admin,"zeus_admin",zeus_admin_menuManagement,"Menu Management " ,engineering_subMenu_headLine, "Menu Management");

        Thread.sleep(5000);
		logOut(); 
	}

	 private void VerifyClick(String menu,String menuText,String submenu, String subMenuText) throws Throwable {
			aJSClick(adminLInk,"Admin Menu");
			mouseHoverMove(menu,menuText, submenu,menuText);
			
		}

		private void Verify(String menu, String menuText,String submenu, String subMenuText, String textElement, String text) throws Throwable {
			setBrowserTo80Size();
			Thread.sleep(1000);
			aJSClick(adminLInk,"Admin Menu");
			aJSClick(menu,menuText);
			aJSClick(submenu,subMenuText);
			waitForElementPresent(textElement, 200);
			verifyText(textElement,  text, "Verifying HeadLine text");
		}

		@SuppressWarnings("unused")
		private void Verifyy(String menu,String menuText,String submenu, String subMenuText, String textElement, String text) throws Throwable {
			aJSClick(adminLInk,"Admin Menu");
			aJSClick(menu,menuText);
			aJSClick(submenu,subMenuText);
			waitForElementPresent(textElement, 200);
			verifyText(textElement,  text, "Verifying HeadLine text");
		}

}

