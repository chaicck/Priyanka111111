package demo.objectrepository;

public interface OR_CustomerSearch {
	
	String customerLnk="id=notification-customer";
    String Customer_Dashboardverify = "xpath=//li[text()='TNL Test BroadsoftRAY V17']";
   
}
