package qa6_TestCases;

import demo.businesslogic.MediatorClass;


import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;



public class Circuit_QA6 extends MediatorClass{
	
	 
	    @Test(alwaysRun=true,enabled=true)
	    public void verifyCircuitModifcation() throws Throwable {

	        logger = extent.startTest("Circuit");
	        type(userNameTxt, "zqa-admin", "User name");
	        type(passTxt, "Q@eZL9Pw2D", "Password");
	        click(submitBtn, "Submit button");
		    click(srchDd,"Search");  
		    click(search_circuit,"circuit button"); 
		    verifyText(circuit_tableName,"Circuits", "Verifying Circuits");   
		    
		    type(srchTxt, "1234","Search box");
	        type(srchTxt,"Search box",Keys.ENTER);
	        
	        actionsClick(search_circuit_ViewEditLinksTable);
	        clearText(search_circuit_form_circuitId);
	        String circuitId="1234"+generateRandomString(2);
	       
	        type(search_circuit_form_circuitId, circuitId, "circuit id");
	        actionsClick(search_circuit_form_saveBtn);
	        waitForElementPresent(search_circuit_form_successOkPopUp, 10);
	        actionsClick(search_circuit_form_successOkPopUp);
	        
	        //verifyText(search_circuit_form_circuitId, circuitId, "Circuit Id");
	        
	        scrollElementIntoView(search_circuit_form_addDesignEntryBtn);
	        actionsClick(search_circuit_form_addDesignEntryBtn);
	        type(search_circuit_form_addDesignEntryBtn_circuitId_Qa6, "1234", "Circuit Id");
	        
	        JSClick(search_circuit_form_addDesignEntryBtn_addConnectedCircuitBtn);
	        
	       verifyTextPresentInListAndDelete(search_circuit_form_CiircuitDesignEntries, search_circuit_form_CiircuitDesignEntries_delete,"1234");
	       acceptAlert();
	       
	        
	}  

}
