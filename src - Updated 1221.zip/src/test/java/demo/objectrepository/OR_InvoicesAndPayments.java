package demo.objectrepository;

public interface OR_InvoicesAndPayments {
    String exportBtn = "xpath=//a[@class='btn btn-success btn-sm pull-right']";
    String invoiceBtn = "xpath=//table[@id='invoice_table']/tbody/tr[1]/td[3]";
    String invoiceCloseBtn = "xpath=//*[@id='basic_modal']/div/div/div[1]/button";


}