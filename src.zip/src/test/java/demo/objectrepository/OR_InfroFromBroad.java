package demo.objectrepository;

public interface OR_InfroFromBroad {

    String voice="id=dd-Voice";
    String voice_broadWorks="id=notification-broadworks";
    String voice_broadWorks_details="xpath=//a[starts-with(@href,'/broadworks/groupDetail/customer')]";
    String voice_broadWorks_details_header="id=header_crumbs";
    String voice_broadWorks_details_page ="className=panel-title";
    
    String url_teles = "https://zeus.telesphere.com/broadworks/groupDetail/customer_id:";
}
