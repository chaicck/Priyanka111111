package testCases;
import java.io.File;

import org.apache.log4j.lf5.util.LogFileParser;
import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import demo.businesslogic.CommonReusables;
import demo.objectrepository.OR_CustInfo;
import demo.objectrepository.OR_HomePage;
import demo.objectrepository.OR_Inventory;
import demo.objectrepository.OR_NewMAC;
import demo.objectrepository.OR_ProjectManager;
import demo.objectrepository.OR_ReconsiliationPage;
import demo.objectrepository.OR_SearchPage;

public class Reconciliation1971 extends CommonReusables implements OR_HomePage, OR_CustInfo,OR_ProjectManager,OR_NewMAC,OR_Inventory, OR_ReconsiliationPage {
	 
	  @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
    public void reconciliation1971(String zUserName, String zPassword) throws Throwable {
        logger = extent.startTest("Reconcile Email Check and notes").assignCategory("Customer_DashBoard");;
        logInfo("Currently Running on -- "+getCurrentUrl());
	logInfo("TestCase Description: Reconcile of Email check");
        type(userNameTxt, zUserName, "User name");
        type(passTxt, zPassword, "Password");
        click(submitBtn, "Submit button");
        click(srchDd, "Search");
        type(OR_SearchPage.srchTxt, "vienna", "Search box");
        type(OR_SearchPage.srchTxt, "Search box", Keys.ENTER);

        click(OR_SearchPage.Symbol1stCustomer,"Symbol1stCustomer");
        click(OR_SearchPage.reconsilation1stCustomer,"reconsilation Option of 1stCustomer");

        type(ReconsiliationNotes,"test","Reconsilation Notes");

        click(emacCheckBox,"emacCheckBox");
        click(reconsileSubmitButton,"reconsileSubmitButton");
        logPass("Sucessfully clicked on Reconcile");
        Thread.sleep(5000);



        logOut();
    }
}
