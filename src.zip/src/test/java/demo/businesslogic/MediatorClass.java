package demo.businesslogic;

import demo.objectrepository.OR_Admin;
import demo.objectrepository.OR_Billing;
import demo.objectrepository.OR_CustInfo;
import demo.objectrepository.OR_CustomerMenu_topRight;
import demo.objectrepository.OR_Data;
import demo.objectrepository.OR_HomePage;
import demo.objectrepository.OR_Inventory;
import demo.objectrepository.OR_NewMAC;
import demo.objectrepository.OR_NumRange;
import demo.objectrepository.OR_Projects;
import demo.objectrepository.OR_Queues;
import demo.objectrepository.OR_ReconsiliationPage;
import demo.objectrepository.OR_Reports;
import demo.objectrepository.OR_SearchPage;
import demo.objectrepository.OR_SugarSite;
import demo.objectrepository.OR_Tickets;
import demo.objectrepository.OR_Tools;
import demo.objectrepository.OR_Voice;

public class MediatorClass extends CommonReusables implements OR_Billing,OR_NumRange,OR_Tools, OR_CustomerMenu_topRight, OR_Voice, OR_Queues, OR_Tickets, OR_Data, OR_SugarSite,  OR_Projects, OR_Reports,OR_Admin, OR_SearchPage, OR_HomePage, OR_CustInfo,OR_NewMAC,OR_Inventory, OR_ReconsiliationPage {
{

}
}