package qa5_TestCases;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;

import demo.businesslogic.CommonReusables;
import demo.objectrepository.OR_Admin;
import demo.objectrepository.OR_CustInfo;
import demo.objectrepository.OR_HomePage;
import demo.objectrepository.OR_Inventory;
import demo.objectrepository.OR_NewMAC;

import demo.objectrepository.OR_Projects;
import demo.objectrepository.OR_ReconsiliationPage;
import demo.objectrepository.OR_Reports;
import demo.objectrepository.OR_SearchPage;

public class ChildUIVerification extends CommonReusables implements OR_Projects, OR_Reports,OR_Admin, OR_SearchPage, OR_HomePage, OR_CustInfo,OR_NewMAC,OR_Inventory, OR_ReconsiliationPage {


	@Test(priority=2, dependsOnMethods="apiAccountCreation")
	public void childUserAccountVerification() throws Throwable {

		String customer_id="";
		String contract_id;
		logger = extent.startTest("Verifying customer Home");
	      type(userNameTxt, "zqa-admin", "User name");
	        type(passTxt, "Q@eZL9Pw2D", "Password");
		click(submitBtn, "Submit button");

		type(searchTextBox, customer_id, "Search Box");
		type(searchTextBox,"search box",Keys.ENTER);

		if(verifyElementText(customerTableHeadline, "Customers")) {

			verifyTextInColumnClickOtherColumn(customerIdList, customerName, customer_id); 

		}


		verifyText(customer_dashboard_name, "Customer:", "Customer Name"); //Name To verify - eg.Customer: Novell & Jimenez-Corp (31589)
		scrollElementIntoView(customer_dashboard_contacts);
		actionsClick(customer_dashboard_contacts);
		verifyTextPresentInList(customer_dashBoard_contacts_nameList, ""); // customer Name
		verifyTextPresentInList(customer_dashBoard_contacts_nameEmail, ""); // customer email

		click(customerHome_billing,"customerHome billing");
		actionsClick(customerHome_billing_contracts);
		actionsClick(customerHome_billing_contracts_list);
		Thread.sleep(3000);
		

		
		if (!verifyElementText(billing_contracts_contractIdList,"")) {
			waitForTextPresentByBrowerRefresh(billing_contracts_contractIdList,2,20);
		}
				
		

		contract_id=getText(billing_contracts_contractIdList);
		actionsClick(billing_contracts_magnifierList);


		// logging into view In menu - engage
		click(customerHome_viewInMenu, "customerHome_viewInMenu");
		click(customerHome_viewInMenu_engage, "customerHome viewIn Menu engage");
		navigateToChild();
		Thread.sleep(5000);

		//	        type(engageIp_username, "Admin", "Engage Ip Username");
		//	        type(engageIp_password, "1QR2NsOAmM4", "Engage Ip Password");



		type(engageIp_username, " ZeusQA", "Engage Ip Username");
		type(engageIp_password, " t3$tp@sS0rd", "Engage Ip Password");

		click(engageIp_loginBtn, "login Button");
		waitForElementToBeClickable(engageIp_contactsTab);
		click(engageIp_contactsTab, "Enagage IP -Contacts Tab");
		verifyText(engageIp_contactsPageTitle, "CONTACTS", "Contacts");

		click(engageIp_overViewTab, "Enagage IP OverviewTab");
		System.out.println(getText(engageIp_overView_packagesTitle));
		verifyText(engageIp_overView_packagesTitle, "PACKAGES", "Packages");

		navigateBackToParentWindow();

		click(customerHome_Queues, "Queues Menu");
		actionsClick(queues_newProjects);
		type(queues_search, contract_id, "");
		Thread.sleep(1000);
		actionsClick(queues_success_greenBtn);
		waitForElementToBeClickable(queues_newProject_createAProjectOntoStep2Btn);
		actionsClick(queues_newProject_createAProjectOntoStep2Btn);
		scrollElementIntoView(queues_createAProjectOntoStep_DueDate);
		JSClick(queues_createAProjectOntoStep_DueDate);
		//actionsClick(queues_createAProjectOntoStep_DueDate);
		actionsClick(queues_createAProjectOntoStep_buildProjectTask);

		waitForElementPresent(queues_newProject_saveRecalculateBtn, 20);

		selectDropDownByVisibleText(queues_createAProjectOntoStep_projectStatus_DD, "Ready for FULL Billing");
		type(queues_createAProjectOntoStep_fullBillDate, toDaysdate(), "full bill date");
		actionsClick(queues_newProject_saveRecalculateBtn);
		 waitForElementPresent(queues_projectBuildSuccessMsg, 20);
		actionsClick(queues_projectBuildSuccessMsg);
		click(customerHome_Queues, "Queues Menu");
		actionsClick(queue_billing);
		type(queue_billing_search, customer_id, "");
		actionsClick(queue_billing_processLnkList);

		navigateToChild();
		actionsClick(queue_billing_pushToBilling2);
		Thread.sleep(5000);

		actionsClick(queue_billing_pushToBilling_addView);
		Thread.sleep(5000);

		actionsClick(queue_billing_pushToBilling_viewInEngage);
		Thread.sleep(15000);
		
		navigateToChild();
		
		 String engageCurrentUser="id=CurrentUsername";
	        if(!getText(engageCurrentUser).contains(customer_id)) {
	        	System.out.println("Customer Id is not correct in Engage");
	        	currentWindowClose();
	        	navigateBackToParentWindow();
	        	Thread.sleep(1000);
	        	click(customerHome_viewInMenu, "customerHome_viewInMenu");
		        click(customerHome_viewInMenu_engage, "customerHome viewIn Menu engage");
		        navigateToChild();
		        Thread.sleep(5000);
	        }
	        System.out.println(getText(engageCurrentUser));
	        Assert.assertTrue(getText(engageCurrentUser).contains(customer_id));  


		//move back to parent tab
		navigateBackToParentWindow();
		
		         click(adminLInk,"Admin LInk");
		         click(automation, "Automation");
		         JSClick(automation_automation_viewAutomation);
		         type(queue_billing_search, "ENGAGE", "");
		         //16th point - 1 stpe (clicking on Run)
		         Thread.sleep(1000);
		         actionsClick(queue_billing_run);
		         Thread.sleep(2000);
		         waitForElementToBeClickable(queue_billing_run_run);
		         actionsClick(queue_billing_run_run);

		         Thread.sleep(15000);
		         waitForElementPresent(queue_billing_run_successText, 30);
		         verifyText(queue_billing_run_successText, "Successful", "Successful Msg");
		 
		click(srchDd,"Search");	         
		click(customerLnk,"Customer link");        
		type(srchTxt, customer_id,"Search box"); //search text
		type(srchTxt,"Search box",Keys.ENTER);        
		// verifyText(customerNamefromTable,  "", "customer name");    //customer name that needds to verify    


	}
}
