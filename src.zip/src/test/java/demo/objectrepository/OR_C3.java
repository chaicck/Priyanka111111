package demo.objectrepository;

public interface OR_C3 {
	
	String Home = "xpath=//span[@id='notification-home']";
	String c3_configuration = "id=notification-client-configuration-call";
	String C3_Dashboard = "id=notification-dashboard";
	String Dashboard_verify = "xpath=//h1[text()='Checklist Builder']";
	String Global_parameter_verify = "xpath=//div[@class='container-fluid']";
	String Global_Parametrers = "id=notification-global-parameters";
	String C3_configure_users = "id=notification-configure-users";
	String Verify_C3_configure_users = "xpath=//div[@class='container-fluid']";
	String Build_enterprisegroup = "id=notification-build-enterprise/group";
	String Verify_Build_enterprisegroup = "xpath=//h4[text()='Global Parameters']";
	String Build_Iads = "id=notification-build-iads";
	String Verify_Build_Iads = "xpath=//th[text()='ID']";
	String E911 = "id=notification-e911-address-assignment";
	String E911_verify = "id=import-link";
	String Build_usersDevice = "id=notification-build-users-&-devices";
	String Verify_Build_usersDevice = "id=buildUsersAndDevices";
	String Build_ucc = "id=notification-build-ucc";
	String Verify_Build_ucc = "id=buildUCCServices";
	String Build_SCA = "id=notification-build-sca";
	String Verify_Build_SCA = "xpath=//div[@class='container']";
	String Colabirative_bridge = "id=notification-build-collaborative-bridge";
	String colabarativebridge_verify = "xpath=//div[@class='container-fluid']";
	String Speak2dail = "id=notification-build-speak2dial";
	String team_one = "id=notification-team-one";
	String verify_teamone = "xpath=//span[text()='Users to build in TeamOne']";
	String Customer_tag = "id=notification-custom-tags-management";
	String Verify_customertag = "id=DataTables_Table_0";
    String verifycustomer_header = "id=customer_id";
	String Assign_number_Inventory = "xpath=//*[@id=\"number_table\"]/caption/a[2]";
	String State = "id=state";
	String Npa = "id=npanxx";
	String State_Search = "xpath=(//button[@type='submit'])[2]'";
	String header = "xpath=//*[@id='header_crumbs']";
	String a = "xpath=//h1[@class='panel-title']";
}
