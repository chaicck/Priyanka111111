package demo.objectrepository;

public interface OR_Projects {
	
	
	    
	    String projectEdit_duration="xpath=//input[@type='number']";
	    String projectEdit_saveTaskBtn="xpath=//button[@name='submit']";
	    String projectEdit_closeBtn="xpath=//button[@class='close']";
	    
	   
	    String Project_Menu ="xpath=//span[text()='Projects']";
		 String Project_Menu_Oreilly_rapidlist = "id=notification-o'reilly-rapid-builder-list";
		
		
		 String Project_Menu_Oreilly_rapidlist_Selectproject_dropdown = "id=url";
		 String Project_Menu_Oreilly_rapidlist_Selectproject_dropdown_GotoBuilder ="id=next";
		 String Project_Menu_Oreilly_rapidlist_Selectproject_dropdown_GotoBuilder_Reviewbuild ="id=OReillyForm";
		 String Project_Menu_Oreilly_rapidlist_Selectproject_dropdown_GotoBuilder_Build ="id=Build";
		 String Project_Menu_Oreilly_rapidlist_Selectproject_dropdown_GotoBuilder_Buildsucess ="id=bStatus";
		 
		 String projects_tasksMyTasks="id=notification-tasks---my-tasks";
	     String projects_tasksMyTasks_accessManagement_DD="id=queue_name";
	     String projects_tasksMyTasks_owner_DD="id=owner_id_chosen";
	     String projects_tasksMyTasks_owner_DD_searchEntry="xpath=(//div[@class='chosen-search'])[1]/input";
	     String projects_tasksMyTasks_projectManager_DD="id=project_manager_chosen";
	     String projects_tasksMyTasks_projectManager_DD_searchEntry="xpath=(//div[@class='chosen-search'])[2]/input";
	     String projects_tasksMyTasks_taskName_DD="id=task_name_chosen";
	     String projects_tasksMyTasks_taskName_DD_searchEntry="xpath=(//div[@class='chosen-search'])[3]/input";
	         
	     String projects_tasksMyTasks_status_DD="id=task_status";
	     String projects_tasksMyTasks_searchBtn="xpath=(//button[@type='submit'])[2]";
	     String projects_tasksMyTasks_exportBtn="xpath=//button[@class='btn btn-success btn-sm dropdown-toggle']";
	     String projects_tasksMyTasks_exportBtn_dropDownValue1="xpath=(//ul[@class='dropdown-menu dropdown-menu-right']/li/a)[1]";
	     String projects_tasksMyTasks_exportBtn_dropDownValue2="xpath=(//ul[@class='dropdown-menu dropdown-menu-right']/li/a)[2]";
	     String projects_tasksMyTasks_exportBtn_dropDownValue3="xpath=(//ul[@class='dropdown-menu dropdown-menu-right']/li/a)[3]";
	    

	      
	     
	       
}
