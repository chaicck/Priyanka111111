package master_TestCases;

import java.security.SignatureException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.codec.CharEncoding;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Generate signature required for pi-contacts using HMAC-SHA1
 * This utility does not require third party packages such apache.common
 *
 *	In order to authenticate to the PI Contacts API,  the provided API Key and Secret must be used
 *	All API requests require HMAC-based authentication except for the Domain APIs which are restricted in access. 
 *	In order to authenticate an API request, follow the steps below:
 *
 *	1. Add header: X-Von-Date: YYYY-MM-DD HH24:MM:SS GMT
 *	2. Calculate signature as follows:
 *		StringToSign = 	LowerCase ( HTTP-Verb ) + "\n" + 
 *						LowerCase ( HTTP-Request-URI ) + "\n" + 
 *						LowerCase ( X-Von-Date ) + "\n" + 
 *						LowerCase ( HTTP-Content-MD5 )  + "\n";
 *		Signature = Base64 ( HMAC-SHA1 ( YourAPISecret, UTF-8-Encoding-Of ( StringToSign ) ) );
 *	3.	Authorization: PI <YourAPIKey>:<Signature>
 *
 *   
 * 
 * @author wguo
 *
 */
public class PISignature {
	
	private static final Logger log = LoggerFactory.getLogger(PISignature.class);
	
	private static final String HMAC_SHA1_ALGORITHM = "HmacSHA1";
	private static final String EOL	= "\n";

	/**
	 * get the current date in GMT 
	 * 
	 * @return
	 */
	public static String getCurrentDateGmt(){
		return getCurrentDate("GMT");
	}
	
	public static String getCurrentDate(String timeZone){
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z");
		dateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
		return dateFormat.format(new Date()).toString();		
	}
	
	/**
	 * calculate the signature 
	 * 
	 * @param httpVerb		GET, PUT, POST, DELETE
	 * @param requestUri	Request URI including query parameters	 
	 * @param vonDate		X-Von-Date header
	 * @param requestBody	Http request body (append "\n" for empty request body)
	 * @param apiSecret		Api Secret assigned to the domain
	 * @return
	 */
	public static String calculateSignature(String httpVerb, String requestUri, String vonDate, byte[] requestBody, String apiSecret, boolean contentMD5ForBlank){
		
		String md5OfBody = StringUtils.EMPTY;
		if(ArrayUtils.isEmpty(requestBody)) {
			if(contentMD5ForBlank) {
				md5OfBody = DigestUtils.md5Hex(md5OfBody);
			}
		} else {
			md5OfBody = DigestUtils.md5Hex(requestBody);
		}
		
		log.debug("Creating signature from verb {}, requestUri {}, date {}", httpVerb, requestUri, vonDate);
		log.trace("Creating signature from body {}", requestBody == null ? null : new String(requestBody));
		log.trace("Creating signature from secret {}", apiSecret);

		StringBuilder sb = new StringBuilder();
		// HTTP Request Verb
		if (StringUtils.isNotBlank(httpVerb)){
			sb.append(httpVerb);
		}
		sb.append(EOL);

		// request uri
		if (StringUtils.isNotBlank(requestUri)){
			sb.append(requestUri);
		}
		sb.append(EOL);

		// X-Von-Date header
		if (StringUtils.isNotBlank(vonDate)){
			sb.append(vonDate);
		}
		sb.append(EOL);

		// contentMD5 of request body
		if(contentMD5ForBlank || StringUtils.isNotBlank(md5OfBody)) {
			sb.append(md5OfBody);
		}
		sb.append(EOL);
		return signWithHmacSha1(apiSecret, sb.toString().toLowerCase());
	}
	
	/**
	 * generate the HMAC-SHA1 string  
	 * 
	 * @param key
	 * @param data
	 * @return 
	 * @throws SignatureException 
	 */
	public static String signWithHmacSha1(String key, String data) {
		
		String sig = null;
		
		try {
			log.debug("Sign with HmacSha1: secret {} and data {}", key, data);
			
			// create key spec
			SecretKeySpec signingKey = new SecretKeySpec(key.getBytes(), HMAC_SHA1_ALGORITHM);
			
			// get an hmac_sha1 Mac instance and initialize with the signing key
			Mac mac = Mac.getInstance(HMAC_SHA1_ALGORITHM);
			mac.init(signingKey);

			// compute the hmac on input data bytes with UTF-8 
			byte[] raw = mac.doFinal(data.getBytes(CharEncoding.UTF_8));

			// base64-encode the hmac for java < 8
			sig = DatatypeConverter.printBase64Binary(raw);
			
			// Java 8 offers an Base64 class
			//sig = Base64.encodeBase64String(rawHmac);

		} catch (Exception e) {
			return null;
		}
		
		return sig;
	}

	public static void main(String[] args) {
		String s="{ \"contacts\" : [ { \"active\" : \"true\", \"emailAddress\" : \"EE1LKtest.customer@gmail.com\", \"externalContactID\" : \"003540012EE3227654T371\", \"firstName\" : \"EE2 LK\", \"lastName\" : \"LK EE2\", \"types\" : [ \"billing\", \"afterHours\", \"primary\", \"technical\", \"onsite\", \"authorized\" ] } ], \"customer\" : { \"billingAddress\" : { \"city\" : \"Holmdel\", \"country\" : \"US\", \"line1\" : \"22 W Main Street\", \"line2\" : \"\", \"stateOrProvince\" : \"NJ\", \"zipOrPostalCode\" : \"07733\" }, \"installAddress\" : { \"city\" : \"HOLMDEL\", \"country\" : \"US\", \"line1\" : \"45 W MAIN ST\", \"line2\" : \"\", \"stateOrProvince\" : \"NJ\", \"zipOrPostalCode\" : \"07733\" }, \"locationName\" : \"LK EE2 - EE2 Location\", \"name\" : \"LK EE2\", \"parentCustomerID\" : \"00000\", \"paymentAccountID\" : \"\", \"salesMarket\" : \"\", \"salesPerson\" : { \"emailAddress\" : \"sfdcvon@gmail.com\", \"externalID\" : \"00554000000k2U3AAM\", \"firstName\" : \"Premier\", \"lastName\" : \"Sales Closer }, \"salesTeam\" : \"\", \"taxExemptStatus\" : \"None\" }, \"externalLocationID\" : \"00154000887BYLK225632677892\", \"externalQuoteID\" : \"a39540000000iWeAAI\", \"order\" : { \"description\" : \"Order For LK EE2\", \"externalQuoteNumber\" : \"Q204776\", \"gmApprovedDate\" : \"2018-9-09T19:00:29.000Z\", \"products\" : [ { \"circuitQuoteID\" : \"\", \"discountmrr\" : 0, \"discountnrr\" : 17, \"icbType\" : \"\", \"listmrr\" : 0, \"listnrr\" : 17, \"mrc\" : 0, \"name\" : \"Activation Fee\", \"nrc\" : 17, \"quantity\" : 1, \"sku\" : \"V-3756.a\", \"subscriptionType\" : \"Service\" } ], \"requestedInstallDate\" : null, \"salesMarket\" : \"\", \"salesPerson\" : { \"emailAddress\" : \"sfdcvon@gmail.com\", \"externalID\" : \"00554000000kYU3AAM\", \"firstName\" : \"Premier\", \"lastName\" : \"Sales Closer\" }, \"signedDate\" : null, \"stage\" : \"Ready for Service Delivery\" \"subject\" : \"Order For location 20\", \"team\" : \"null - null\", \"term\" : 36 }, \"uuID\" : \"05057\" }";
		byte[] body=s.getBytes();
		String stringToSign=calculateSignature("post","/zeus/v1/order",getCurrentDateGmt().toLowerCase(),body,"Oe5LNk4VFtDC3Clk3JkqqPcDkDDb06uVmDn0rf2Trq22wLBPwAdKaqDjHVBQ1JKH",true);
		String fi=signWithHmacSha1("Oe5LNk4VFtDC3Clk3JkqqPcDkDDb06uVmDn0rf2Trq22wLBPwAdKaqDjHVBQ1JKH",stringToSign);
		System.out.println("PI ENTERPRISE_IL:"+fi);
	}

}
