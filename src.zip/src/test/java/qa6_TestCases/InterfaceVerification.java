package qa6_TestCases;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class InterfaceVerification extends MediatorClass{
	
	
    @Test
    public void interfaceVerification() throws Throwable {
    	
    	String customer_id="903797";
        logger = extent.startTest("InterfaceVerification");
        type(userNameTxt, "zqa-admin", "User name");
        type(passTxt, "Q@eZL9Pw2D", "Password");
        click(submitBtn, "Submit button");
        
        type(searchTextBox, customer_id, "Search Box");
		type(searchTextBox,"search box",Keys.ENTER);
		if(verifyElementText(customerTableHeadline, "Customers")) {
			verifyTextInColumnClickOtherColumn(customerIdList, customerName, customer_id); 
		}
		verifyText(customer_dashboard_name, "Customer:", "Customer Name");
		
		Thread.sleep(3000);
		String dashboard_data="id=dd-Data";
		String data_devices="xpath=//a[starts-with(@href,'/device/listByCustomer/customer_id')]";
		String data_devices_devicesNameTable="xpath=//*[@id='device_table']/tbody/tr/td[2]";
		String data_devices_magnifierNameTable="xpath=//*[@id='device_table']/tbody/tr[%s]/td[1]/a[1]";
		String data_devices_magnifierNameTable_deviceMonitorType_DD="id=monitor_type";
		String data_devices_magnifierNameTable_solarWindStatus="id=solar_winds_status";		
		
		JSClick(dashboard_data);
		actionsClick(data_devices);		
		verifyTextInColumnClickOtherColumn(data_devices_devicesNameTable,data_devices_magnifierNameTable,"15707" );
		waitForElementPresent(data_devices_magnifierNameTable_deviceMonitorType_DD, 20);
		selectDropDownByVisibleText(data_devices_magnifierNameTable_deviceMonitorType_DD, "SW");

		JSClick(data_devices_magnifierNameTable_solarWindStatus);
		
		
		
	
    }	

}
