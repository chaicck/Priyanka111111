package portal_user;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class TC_1_73_Fax_detail_records extends MediatorClass{
	
	
    @Test
    public void tc_1_73_Fax_detail_records() throws Throwable {
    	
    	String customer_name="Nextcare - AZ - Florence";

        logger = extent.startTest("1.73 Test ID : 17120 - Verify if user is able to view and search fax detail records");
        type(userNameTxt, "zqa-admin", "User name");
        type(passTxt, "Q@eZL9Pw2D", "Password");
        click(submitBtn, "Submit button");
        waitForElementPresent(searchTextBox, 300);
        type(searchTextBox, customer_name, "Search Box");
		type(searchTextBox,"search box",Keys.ENTER);
		if(verifyElementText(customerTableHeadline, "Customers")) {
			//verifyTextInColumnClickOtherColumn(customerNameList, customerName, customer_name); 
			Thread.sleep(1000);
			actionsClick(customerNameList);
		}
		verifyText(customer_dashboard_name, "Customer:", "Customer Name");
	     waitForElementPresent(customerDashboard_customerLink, 300);	
		actionsClick(customerDashboard_customerLink);
		waitForElementPresent(Home, 300);	
		 click(Home, "Home Menu");
	     click(Home_portalUers, "Portal User");
		waitForElementPresent(Home_portalUser_login, 300);	
	     actionsClick(Home_portalUser_login,"Home_portalUser_login");
	      
	      Thread.sleep(10000);
	      navigateToChild();
	      
	      logInfo("Navigated to Vonage Home");
	      waitForElementPresent(vonage_userName, 300);	
	      type(vonage_userName, "zqa-admin", "User name");
	      type(vonage_password, "Q@eZL9Pw2D", "Password");
	      actionsClick(vonage_loginBtn,"vonage_loginBtn");
	      /*
	      waitForElementPresent(vonage_table1, 20);
	      actionsClick(vonage_table1);*/
	      waitForElementPresent(vonage_selectASiteFromListHeadLine, 300);	

	      if(verifyElementText(vonage_selectASiteFromListHeadLine, "Select a site from the list below")) {
	    	  type(voonage_search, "Nextcare - AZ - Florence", "");
	    	  Thread.sleep(2000);
	    	  JSClick(vonage_selectASiteFromList);
	      }
	      	      
	      verifyText(vonage_dashboardHeadline, "Dashboard", "vonage_dashboardHeadline");
	      waitForElementPresent(voonage_callAnalytics, 300);	
	      JSClick(voonage_callAnalytics,"voonage_callAnalytics");
	      waitForElementPresent(voonage_faxMail, 200);
	      scrollElementIntoView(voonage_faxMail);
	      JSClick(voonage_faxMail,"voonage_faxMail");
	      
	      waitForElementPresent(voonage_startdate, 300);	
	      enterDate(voonage_startdate, "02", "2", "2016");
	      logInfo("Start date enterd as 02-02-2016");
	      enterDate(voonage_endDate, "06", "8", "2018");
	      logInfo("Start date enterd as 06-08-2018");
	      waitForElementPresent(voonage_searchBtn, 300);	

	      scrollElementIntoView(voonage_searchBtn);
	      JSClick(voonage_searchBtn,"voonage_searchBtn");
	      
	      String faxMailTableRecords="xpath=//*[@id='callDetailReport']/tbody/tr";
	      
	      String faxMailTable_shoeRecords_DD="name=callDetailReport_length";
	      String faxMailTable_searchRecords_export="xpath=//a[@class='btn btn-success btn-sm pull-right']";
	      waitForElementPresent(faxMailTable_shoeRecords_DD, 300);
	      selectDropDownByVisibleText(faxMailTable_shoeRecords_DD, "100");
	      Thread.sleep(2000);
	      int totalReords=getAllElements(faxMailTableRecords).size();
	      
	     
	        if (totalReords >=50) {
	        	selectDropDownByVisibleText(faxMailTable_shoeRecords_DD, "50");
	        	 Thread.sleep(3000);
	            int totalReords4=getAllElements(faxMailTableRecords).size();
	            Assert.assertEquals(totalReords4, 50);            
	        }
	        
	        if (totalReords >=25) {
	        	selectDropDownByVisibleText(faxMailTable_shoeRecords_DD, "25");
	        	 Thread.sleep(3000);
	            int totalReords4=getAllElements(faxMailTableRecords).size();
	            Assert.assertEquals(totalReords4, 25);            
	        }
	        if (totalReords>=10) {
	        	selectDropDownByVisibleText(faxMailTable_shoeRecords_DD, "10");
	        	 Thread.sleep(3000);
	            int totalReords5=getAllElements(faxMailTableRecords).size();
	            Assert.assertEquals(totalReords5, 10);            
	        }
	        logPass("Show Records feature working Properly");
	        waitForElementPresent(faxMailTable_shoeRecords_DD, 300);
	        selectDropDownByVisibleText(faxMailTable_shoeRecords_DD, "100");
	        Thread.sleep(3000);
	        System.out.println("Total no of records in the table : "+totalReords);
	        waitForElementPresent(faxMailTable_searchRecords_export, 300);
	        actionsClick(faxMailTable_searchRecords_export, "Export");
	        logPass("export results working properly without any issues");
	        

	        
	      
		
		
    }

	

	
}

