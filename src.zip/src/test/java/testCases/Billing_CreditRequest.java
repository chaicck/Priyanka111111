package testCases;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class Billing_CreditRequest extends MediatorClass {
       	//Billing credit req
	String Queues_Menu = "id=notification-queues";
	String Queues_Menu_Creditreq = "id=notification-credit-requests";
	String Queues_Menu_Creditreq_cretdate = "id=query[CreatedDate]";
	String Queues_Menu_Creditreq_unproceddsearch = "xpath=//input[@type='search']";
	String Queues_Menu_Creditreq_Showprocedd = "xpath=//a[@class='small']";
	String Queues_Menu_Creditreq_Showprocedd_search = "xpath=//input[@type='search']";
	String Queues_Menu_Creditreq_Showprocedd_creditclick = "xpath=//td[@class='small text-center sorting_1']/a";
	String Credit_Save = "xpath=(//button[@form='credit-request-save'])[2]";
	String Credit_Invoice = "xpath=//*[@id=\"credit-request-table\"]/tbody/tr[1]/td[5]/a";
	String Credit_Invoice_Close = "xpath=//button[@class='close pull-right']";
	String Credit_Invoice_Requster = "id=Requestor";
	String ViewInEngage_Transaction = "id=Transactions_tab";
	String billing_credit_request_ticketFromTable = "xpath=//*[@id='credit-request-table']/tbody/tr/td[4]";
	String billing_credit_request_creditIDFromTable_parametarised = "xpath=//*[@id='credit-request-table']/tbody/tr[%s]/td[1]/a";
	String queues_creditRequest_showProcessed = "xpath=//*[@id='credit-request-table']/caption/a[1]";
	String queues_creditRequest_approvedAmount = "xpath=//*[@id='credit-request-table']/tbody/tr/td[12]/span";
	@Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
	public void billing_CreditRequest(String zUserName, String zPassword) throws Throwable {
		// test Data
	int noOfTickets = 3;
	String id=getTestData(this.getClass().getSimpleName().substring(0, 5),1);
	String requestor = "Priya" + getRandomString(2);
	String requestor1 = "Priya Automation" + getRandomString(2);
	logger = extent.startTest("Billing_CreditRequest").assignCategory("Billing","Regression test");
	logInfo("Currently Running on -- "+getCurrentUrl());
	logInfo("TestCase Description::Add credit request and approve amount");
	type(userNameTxt, zUserName, "User name");
	type(passTxt, zPassword, "Password");
	click(submitBtn, "Submit button");
	String url=getCurrentUrl();
	type(searchTextBox, id, "Search Box");
	type(searchTextBox, "search box", Keys.ENTER);
	if (verifyElementText(customerTableHeadline, "Customers")) {
	verifyTextInColumnClickOtherColumn(customerIdList, customerName, id);
	}
	verifyText(customer_dashboard_name, "Customer:", "Customer Name");
	logInfo("Customer Dashboard has been displayed");
	actionsClick(customerHome_billing, "Billing");
	JSClick(billing_creditRequest, "Credit Request");
	JSClick(billing_crediRequest_addNew);
	type(billing_addCustomerCredit_form_requestedBy, requestor, "Requestor Name");
	type(billing_addCustomerCredit_form_phoneNo, "7654565", "Requestor Phone Number");
	type(billing_addCustomerCredit_form_email, "priya@yahoo.com", "Requestor email id");
	selectDropDownByVisibleText(billing_addCustomerCredit_form_creditType_DD, "Contract Adjustment");
	String TicketNumber = getRandomInt(5);
        type(billing_addCustomerCredit_form_ticketNumber, TicketNumber, "Ticket Number");
	Thread.sleep(5000);
	System.out.println("Ticket Number " + TicketNumber);
	selectDropDownByVisibleText(billing_addCustomerCredit_form_CreditReason_DD, "Backdated Customer Disconnect Credit");
	selectDropDownByVisibleText(billing_addCustomerCredit_form_CreditTaxable_DD, "Yes");
	type(billing_addCustomerCredit_form_CreditNotes, "test", "Notes");
	type(billing_addCustomerCredit_form_CreditAmount, "22", "Requested Amount");
	actionsClick(billing_addCustomerCredit_form_save_Btn);
	logPass("Requested Amount is " + "22");
	verifyText(billing_addCustomerCredit_successMsg, "The Credit Request was successfully submitted for","Success Message");
	actionsClick(rightTopMenu);
	actionsClick(rightTopMenu_loginAs,"login AS");
	selectDropDownByVisibleText(loginAs_User_DD, "Kevin Knoll");
	Thread.sleep(3000);
	logPass("Logged in as 'Kevin Knoll' successfully");
        type(searchTextBox, id, "Search Box");
	type(searchTextBox, "search box", Keys.ENTER);
	JSClick(CustomersTableCustomerName);
	Thread.sleep(2000);
	Thread.sleep(1000);
	JSClick(billing_creditRequest);
	Thread.sleep(2000);
	type(Queues_Menu_Creditreq_Showprocedd_search, TicketNumber, "Search for credit with ticket number");
	Thread.sleep(3000);
	verifyTextInColumnClickOtherColumn(billing_credit_request_ticketFromTable,
	billing_credit_request_creditIdFromTable, TicketNumber);
	actionsClick(Credit_Invoice_Close);
	clearText(Queues_Menu_Creditreq_Showprocedd_search);
        Thread.sleep(3000);
	actionsClick(Queues_Menu_Creditreq_Showprocedd_creditclick, "Credit Id");
	waitForElementPresent(billing_credit_request_amountFromTable, 20);
	Thread.sleep(2000);
	scrollElementIntoView(billing_addCustomerCredit_editForm_save_confirm);
	type(billing_addCustomerCredit_form_approvedAmount, "21", "Approved Amount");
	actionsClick(billing_addCustomerCredit_editForm_save_confirm);
	logPass("Approved Amount is " + "21");
	waitForElementPresent(billing_addCustomerCredit_successMsg, 30);
	verifyText(billing_addCustomerCredit_successMsg, "was successfully", "Success Message");
		       
		
		
		
		
			 
		
		
		
		
		
		
		
	}

}
