package testCases;

import demo.businesslogic.CommonReusables;
import demo.objectrepository.*;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

import static demo.objectrepository.OR_SearchPage.noOfRows;
import static demo.objectrepository.OR_SearchPage.srchTxt;

public class VerifyAccountsIfActive extends CommonReusables implements OR_HomePage, OR_CustInfo,OR_ProjectManager,OR_NewMAC,OR_Inventory {

   @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
    public void verifyAccountsIfActive(String zUserName, String zPassword) throws Throwable {

        logger=extent.startTest("Verify Account links when Active");
	    logInfo("Currently Running on -- "+getCurrentUrl());
	logInfo("TestCase Description:Verify Billing Invoice page and should able to click on Export");
        type(userNameTxt, zUserName, "User name");
	type(passTxt, zPassword, "Password");
        click(submitBtn,"Submit button");
        click(srchDd,"Search");
        type(srchTxt, "vienna","Search box");
        type(srchTxt,"Search box",Keys.ENTER);
        VerifyAccountBillingStatus(noOfRows,"NoOfRows");
        logOut();
    }
}

