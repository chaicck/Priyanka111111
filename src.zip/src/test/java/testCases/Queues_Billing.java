package testCases;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openxmlformats.schemas.presentationml.x2006.main.SldDocument;
import org.testng.Assert;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class Queues_Billing extends MediatorClass{
      
	String fs= File.separator;
	  String rtfFilePath=System.getProperty("user.dir")+fs+"TestData"+fs+"test.rtf";
	 @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
	public void tc_1_48_Queues_Billing(String zUserName, String zPassword) throws Throwable {
		
		String TicketNumber =getRandomInt(6);
		
		String Queues_Billing="id=notification-billing";
		
		String billing_credit_request_creditIDFromTable_parametarised="xpath=//*[@id='credit-request-table']/tbody/tr[%s]/td[1]/a";

		String Queues_Billing_BillingDayLegend="xpath=//table[@class='table table-condensed table-nonfluid table-striped']/thead";

		String Queues_Billing_HasBillCycle_symbol="xpath=(//table[@class='table table-condensed table-nonfluid table-striped']/tbody/tr)[1]/td";
		String Queues_Billing_HasBillCycle="xpath=((//table[@class='table table-condensed table-nonfluid table-striped']/tbody/tr)[1]/td)[2]";

		String Queues_Billing_Parent_HasBillCycle_symbol="xpath=(//table[@class='table table-condensed table-nonfluid table-striped']/tbody/tr)[2]/td";
		String Queues_Billing_Parent_HasBillCycle="xpath=((//table[@class='table table-condensed table-nonfluid table-striped']/tbody/tr)[2]/td)[2]";

		String Queues_Billing_RecomendedBillCycle_symbol="xpath=(//table[@class='table table-condensed table-nonfluid table-striped']/tbody/tr)[3]/td";
		String Queues_Billing_RecomendedBillCycle="xpath=((//table[@class='table table-condensed table-nonfluid table-striped']/tbody/tr)[3]/td)[2]";

		String Queues_Billing_PQ2C_Customers_symbol="xpath=(//table[@class='table table-condensed table-nonfluid table-striped']/tbody/tr)[4]/td";
		String Queues_Billing_PQ2C_Customers="xpath=((//table[@class='table table-condensed table-nonfluid table-striped']/tbody/tr)[4]/td)[2]";

		String Queues_Billing_NonBilling="xpath=//td[text()='Non Billing']";
		String queues_billing_showRecords_DD="name=DataTables_Table_0_length";
		String queues_billing_tableRecords="xpath=//*[@id='DataTables_Table_0']/tbody/tr";

		String queues_billing_searchBox="xpath=//input[@type='search']";
		String queues_billing_billQueueTableHeaders="xpath=//*[@id='DataTables_Table_0']/thead/tr/th";
		String queues_billing_billQueueTableCaption="xpath=//*[@id='DataTables_Table_0']/caption";
		String queues_billing_billQueueTable_customerID_Header="xpath=//*[@id='DataTables_Table_0']/thead/tr/th[2]";
		String queues_billing_billQueueTable_customerIDs="xpath=//*[@id='DataTables_Table_0']/tbody/tr/td[2]";
		String queues_billing_billQueueTable_processLinks="xpath=//*[@id='DataTables_Table_0']/tbody/tr/td[1]";
		String queues_billing_billQueueTable_customerIDs_parameter="xpath=(//*[@id='DataTables_Table_0']/tbody/tr/td[2])[%s]";


		logger = extent.startTest(" Queues-  - Billing").assignCategory("Queues");
		 logInfo("Currently Running on -- "+getCurrentUrl());
		logInfo("TestCase Description:Verify if user is able to view the Billing Day Legend\r\n" + 
				"information shown on the top of the page." );
		type(userNameTxt, zUserName, "User name");
		type(passTxt, zPassword, "Password");
		click(submitBtn, "Submit button");
		waitForElementPresent(Queues_Menu, 15);
		logInfo("Logged into Zeus successfully"); 
		actionsClick(Queues_Menu, "Queues");
		JSClick(Queues_Billing,"Queues_Billing");
		waitForElementPresent(Queues_Billing_BillingDayLegend, 300);
		verifyText(Queues_Billing_BillingDayLegend, "Billing Day Legend", "");
		logPass("User is able to view Billing Day Legend information");

		verifySymbolColourText(Queues_Billing_HasBillCycle_symbol,Queues_Billing_HasBillCycle, "Has Bill Cycle","black");
		logPass("'Has Bill Cycle' information displayed with a black #");

		verifySymbolColourText(Queues_Billing_Parent_HasBillCycle_symbol,Queues_Billing_Parent_HasBillCycle, "Parent Has Bill Cycle","blue");
		logPass("'Parent Has Bill Cycle' information displayed with a blue #");

		verifySymbolColourText(Queues_Billing_RecomendedBillCycle_symbol,Queues_Billing_RecomendedBillCycle, "Recomended Bill Cycle","green");
		logPass("'Recommended Bill Cycle' information displayed with a green #");

		verifySymbolColourText(Queues_Billing_PQ2C_Customers_symbol,Queues_Billing_PQ2C_Customers, "PQ2C Customers","purple");
		logPass("'PQ2C Customers' information displayed with a purple #");

		verifyText(Queues_Billing_NonBilling, "Non Billing", "");       
		logPass("'Non Billing' information displayed as part of the Billing Day Legend section");
		//step 7 verification
		String noOfrecords=getDropdownSelectedValue(queues_billing_showRecords_DD);
		Assert.assertEquals("25", noOfrecords);
		logPass("By default, 25 records are displayed on the page");

		verifyDropDownOptionsRespectiveRecordsDisplayed(queues_billing_showRecords_DD, queues_billing_tableRecords, AddElementsIntoList("100;50;25;10"));
		logPass("user is able to switch to 10, 25, 50, 100 number of records & respective number of records displayed per page");
		//Step 8 verification
		Assert.assertTrue(getAttributeValue(queues_billing_searchBox, "placeholder").contains("Search"));
		clearText(queues_billing_searchBox);
		
		String emptyTable="className=dataTables_empty";
		if(verifyElementText(emptyTable, "No data available in table")) {			
			Thread.sleep(1000);
			logPass("No records are present under Bill Ques Table");
			
		}
		else {
		type(queues_billing_searchBox, "11", "SearchBox");
		verifyTheDataDisplayedInRecords(queues_billing_tableRecords, "11");
		logPass("Search functionality verified by searching with '11'");
		clearText(queues_billing_searchBox);
		type(queues_billing_searchBox, "auto", "SearchBox");
		verifyTheDataDisplayedInRecords(queues_billing_tableRecords, "auto");
		logPass("Search functionality verified by searching with 'auto'");

		//9th step
		verifyAllListValuesInOrder(queues_billing_billQueueTableHeaders, AddElementsIntoList(";CustomerID;Name;Billing Platform;BillDay"));
		logPass("Customer ID, Name, Billing Platform, Bill Day are displayed as column titles as part of the Bill Queue results grid");
		//10th step
		verifyText(queues_billing_billQueueTableCaption, "Bill Queue", "");
		logPass("Bill Queue label displayed with the result count");

		//Verifying sort functionality..customer Ids
		clearText(queues_billing_searchBox);
		type(queues_billing_searchBox, "11", "SearchBox");
		verifyTheDataDisplayedInRecords(queues_billing_tableRecords, "11");
		Thread.sleep(1000);
		// List<String> customerIds=getAllTheText(queues_billing_billQueueTable_customerIDs);
		actionsClick(queues_billing_billQueueTable_customerID_Header);
		Thread.sleep(1000);
		List<String> customerIds=getAllTheText(queues_billing_billQueueTable_customerIDs);
		List<String> customerIds_assendingOrder=getAllTheText(queues_billing_billQueueTable_customerIDs);
		Collections.sort(customerIds);
		Assert.assertTrue(customerIds.equals(customerIds_assendingOrder));
		Thread.sleep(1000);
		actionsClick(queues_billing_billQueueTable_customerID_Header);
		Thread.sleep(1000);
		List<String> customerIds_descendingOrder=getAllTheText(queues_billing_billQueueTable_customerIDs);
		customerIds=getAllTheText(queues_billing_billQueueTable_customerIDs);
		Collections.sort(customerIds);
		Collections.reverse(customerIds);
		Assert.assertTrue(customerIds.equals(customerIds_descendingOrder));

		//12,13,14 steps
		String customerId=verifyTextInColumnGetOtherColumnText(queues_billing_billQueueTable_processLinks, queues_billing_billQueueTable_customerIDs_parameter, "Process");
		actionsClick(queues_billing_billQueueTable_processLinks);
		navigateToChild();

		String Queues_Billing_customerId="xpath=//input[@name='customerid']";
		String Queues_Billing_MarkCompleted="xpath=(//input[@value='Mark Completed'])[1]";
		getAttributeValue(Queues_Billing_customerId, "value");
		Assert.assertEquals(customerId, getAttributeValue(Queues_Billing_customerId,"value"));

		Assert.assertEquals(getAttributeValue(queue_billing_pushToBilling1, "Value"),"Push To Billing");
		Assert.assertEquals(getAttributeValue(Queues_Billing_MarkCompleted, "Value"),"Mark Completed");
		logPass("'Push To Billing' & 'Mark Completed' options are present on the webpage");
		Thread.sleep(30000);
		if(verifyElementText(queue_billing_pushToBilling_addToEngage, "")) {
			logPass("'Add TO Engage' option is present on the webpage");
			JSClick(queue_billing_pushToBilling_addToEngage,"Add to Engage");
		}
		if (verifyElementText(queue_billing_pushToBilling_viewInEngage, "")){
			logPass("'View In Engage' option is present on the webpage");
			JSClick(queue_billing_pushToBilling_viewInEngage,"View in Engage");
		}

		// last 4 steps Pending
	/*	String id="35560";
		String requestor="Priya"+getRandomString(2);
		String RequestedAmount=getRandomInt(2);

		Thread.sleep(80000);
		click(srchDd,"Search");        
		click(customerLnk,"Customer");
		type(searchTextBox, id, "Search Box");
		type(searchTextBox,"search box",Keys.ENTER);

		actionsClick(CustomersTableCustomerName);
		actionsClick(customerHome_billing);
		JSClick(billing_creditRequest);
		JSClick(billing_crediRequest_addNew);
		Thread.sleep(10000);
		
		type(billing_addCustomerCredit_form_requestedBy, requestor, "Requestor Name");
		type(billing_addCustomerCredit_form_phoneNo, "7654565", "Requestor Phone Number");
		type(billing_addCustomerCredit_form_email, "priya@yahoo.com", "Requestor email id");
		//Optional - may not be present for all the customers
		// selectDropDownByIndex(billing_addCustomerCredit_form_invoice_DD, 2); 

		selectDropDownByIndex(billing_addCustomerCredit_form_creditType_DD, 2);
		type(billing_addCustomerCredit_form_ticketNumber, TicketNumber, "Ticket Number");
		Thread.sleep(3000);
		System.out.println("Ticket Number "+TicketNumber);
		selectDropDownByIndex(billing_addCustomerCredit_form_CreditReason_DD, 2);
		selectDropDownByIndex(billing_addCustomerCredit_form_CreditTaxable_DD, 2);

		type(billing_addCustomerCredit_form_CreditNotes, "test", "Notes");
		type(billing_addCustomerCredit_form_CreditAmount, RequestedAmount, "Requested Amount");

		actionsClick(billing_addCustomerCredit_form_save_Btn);

		verifyText(billing_addCustomerCredit_successMsg, "The Credit Request was successfully submitted for", "Success Message");

		actionsClick(rightTopMenu);
		actionsClick(rightTopMenu_loginAs);
		selectDropDownByVisibleText(loginAs_User_DD, "Kevin Knoll");

		click(srchDd,"Search");

		click(customerLnk,"Customer");  
		type(searchTextBox, id, "Search Box");
		type(searchTextBox,"search box",Keys.ENTER);

		actionsClick(CustomersTableCustomerName);

		actionsClick(customerHome_billing);
		JSClick(billing_creditRequest);
		
		Thread.sleep(2000);
		String searchBox ="xpath=//input[@type='search']";
		Thread.sleep(5000);
		type(searchBox, TicketNumber, "SearchBox");
		Thread.sleep(2000);
		String creditId=verifyTextInColumnGetOtherColumnText(billing_credit_request_ticketFromTable, billing_credit_request_creditIDFromTable_parametarised, TicketNumber).trim();
		System.out.println("Credit Id "+creditId);	
		Thread.sleep(3000);
		verifyTextInColumnClickOtherColumn(billing_credit_request_ticketFromTable, billing_credit_request_creditIdFromTable, TicketNumber);
		int no=Integer.parseInt(RequestedAmount);
		scrollElementIntoView(billing_addCustomerCredit_editForm_save_confirm);
		scrollElementIntoView(billing_addCustomerCredit_editForm_save_confirm);

		if(no>2) {
			type(billing_addCustomerCredit_form_approvedAmount, Integer.toString(no-1), "Approved Amount");
		}
		if(no==1)
			type(billing_addCustomerCredit_form_approvedAmount, Integer.toString(no), "Approved Amount");

		actionsClick(billing_addCustomerCredit_editForm_save_confirm);

		waitForElementPresent(billing_addCustomerCredit_successMsg, 30);
		verifyText(billing_addCustomerCredit_successMsg, "was successfully", "Success Message");*/

	}
	logOut();
	}

	private boolean verifyTheDataDisplayedInRecords(String locator, String data) throws Throwable {
		List<String> l=getAllTheText(locator);
		for (String string : l) {			
			if(!string.contains(data))
				return false;
		}
		logInfo("seach result by searching with "+data+" is/are "+l);
		return true;		
	}

	private void verifyDropDownOptionsRespectiveRecordsDisplayed(String queues_billing_showRecords_DD,String queues_billing_tableRecords, List<String> list) throws Throwable {
		// TODO Auto-generated method stub
		selectDropDownByVisibleText(queues_billing_showRecords_DD, list.get(0));
		Thread.sleep(2000);
		int totalReords=getAllElements(queues_billing_tableRecords).size();	  
		for (int i = 0; i < (list.size()-1); i++) {

			if (totalReords >=Integer.parseInt(list.get((i+1)))) {
				selectDropDownByVisibleText(queues_billing_showRecords_DD, list.get((i+1)));
				Thread.sleep(3000);
				int totalReords4=getAllElements(queues_billing_tableRecords).size();
				Assert.assertEquals(Integer.toString(totalReords4), list.get((i+1)));            
			}

		}

	}

	private void verifySymbolColourText(String symbolLocator,String textLocator, String Text, String symbolColour) {
		verifyText(symbolLocator, "#", "");
		verifyText(textLocator, Text, "");
		Assert.assertTrue(getAttributeValue(symbolLocator, "style").contains(symbolColour));

	}
} 
