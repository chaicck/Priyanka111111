package testCases;

import java.io.File;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class InterfaceVerification extends MediatorClass{
	
	 String fs= File.separator;
	 String rtfFilePath=System.getProperty("user.dir")+fs+"TestData"+fs+"test.rtf";
	 @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
    public void interfaceVerification(String zUserName, String zPassword) throws Throwable {
    	/*Qa6
    	String customer_id="903797";*/
    	String customer_id=getTestData(this.getClass().getSimpleName().substring(0, 5),1);
         logger=extent.startTest("Payment and InvoiceVerification and Export");
	    logInfo("Currently Running on -- "+getCurrentUrl());
        logInfo("TestCase Description:Invoice & Payments, Should be able to export and verify page load");
    	
    	type(userNameTxt, zUserName, "User name");
		type(passTxt, zPassword, "Password");
        click(submitBtn, "Submit button");
        
        type(searchTextBox, customer_id, "Search Box");
		type(searchTextBox,"search box",Keys.ENTER);
		if(verifyElementText(customerTableHeadline, "Customers")) {
			verifyTextInColumnClickOtherColumn(customerIdList, customerName, customer_id); 
		}
		verifyText(customer_dashboard_name, "Customer:", "Customer Name");
		
		Thread.sleep(3000);
		String dashboard_data="id=dd-Data";
		String data_devices="xpath=//a[starts-with(@href,'/device/listByCustomer/customer_id')]";
		String data_devices_devicesNameTable="xpath=//*[@id='device_table']/tbody/tr/td[2]";
		String data_devices_magnifierNameTable="xpath=//*[@id='device_table']/tbody/tr[%s]/td[1]/a[1]";
		String data_devices_magnifierNameTable_deviceMonitorType_DD="id=monitor_type";
		String data_devices_magnifierNameTable_solarWindStatus="id=solar_winds_status";	
		String data_devices_1StMagnifier="xpath=//*[@id='device_table']/tbody/tr[1]/td[1]/a[1]";
		String data_devices_1StDeviceId="xpath=//*[@id='device_table']/tbody/tr[1]/td[2]";
		
		JSClick(dashboard_data);
		actionsClick(data_devices);		
		
		Thread.sleep(5000);
		if(verifyElementText(data_devices_1StMagnifier, "")) {
			String deviceId=getText(data_devices_1StDeviceId);
			actionsClick(data_devices_1StMagnifier);
			logPass("Clicking on Device Id i.e., -" +deviceId);
		}
		else {
			logFail("No devices are present under data -> Devices -> Device Table");
		}
		
		waitForElementPresent(data_devices_magnifierNameTable_deviceMonitorType_DD, 20);
		selectDropDownByVisibleText(data_devices_magnifierNameTable_deviceMonitorType_DD, "SW");
		//JSClick(data_devices_magnifierNameTable_solarWindStatus);		
	logOut();
    }	

}
