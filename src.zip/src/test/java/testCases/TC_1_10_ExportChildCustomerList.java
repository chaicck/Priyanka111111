package testCases;

import java.io.File;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class TC_1_10_ExportChildCustomerList extends MediatorClass{
	
	  String fs= File.separator;
	  String rtfFilePath=System.getProperty("user.dir")+fs+"TestData"+fs+"test.rtf";
	 @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
    public void tc_1_10_ExportChildCustomerList(String zUserName, String zPassword) throws Throwable {
    	
    	String customer_id="37869";
    	 
        logger = extent.startTest("1.10 Test ID : 16338 - Export Child Customer List").assignCategory("Customer DashBoard");
	    logInfo("Currently Running on -- "+getCurrentUrl());
        logInfo("TestCase Description:verify that child customer pane must display a new button 'Export Child Customers'\r\n" + 
        		"'Export Child Customers' button should be present within Child Customers pane\r\n" + 
        		"Test by clicking on Export button .CSV file must be downloaded automatically");
        type(userNameTxt, zUserName, "User name");
		type(passTxt, zPassword, "Password");
        click(submitBtn, "Submit button");
        type(searchTextBox, customer_id, "Search Box");
		type(searchTextBox,"search box",Keys.ENTER);
		Thread.sleep(3000);
		if(verifyElementText(customerTableHeadline, "Customers")) {
			verifyTextInColumnClickOtherColumn(customerIdList, customerName, customer_id); 
		}
		Thread.sleep(3000);
		verifyText(customer_dashboard_name, "Customer:", "Customer Name");
		logInfo("Usernavigated to Customer Dashboard");
				
		actionsClick(customerDashboard_customerLink,"customerDashboard_customerLink");
		//url may differ based on environment & user id - qa5, qa6, master
		Assert.assertTrue(getCurrentUrl().contains("customer/view/customer_id:37869"));
		scrollElementIntoView(childCustomerTableName);
		JSClick(childCustomerTableName,"childCustomerTableName");
		JSClick(customerDashboard_customerLink_exportChildCustomers,"exportChildCustomers");
		logPass(".CSV output file downloaded after clicking on the Export button");
		logOut();
    }

	
}
