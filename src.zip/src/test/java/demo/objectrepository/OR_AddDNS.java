package demo.objectrepository;

public interface OR_AddDNS {
	   String dnsNameTxt ="id=name";
	    String hostTxt ="id=host";
	    String addBtn="xpath=//i[@class='glyphicon  glyphicon-plus ']";

}
