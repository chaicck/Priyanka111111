package testCases;

import java.io.File;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import demo.businesslogic.CommonReusables;
import demo.objectrepository.OR_CustInfo;
import demo.objectrepository.OR_HomePage;
import demo.objectrepository.OR_Inventory;
import demo.objectrepository.OR_InvoicesAndPayments;
import demo.objectrepository.OR_LoginPage;
import demo.objectrepository.OR_NewMAC;
import demo.objectrepository.OR_ProjectManager;
import demo.objectrepository.OR_SearchPage;

public class PaymentsInvoiceVerification extends CommonReusables implements OR_InvoicesAndPayments, OR_HomePage, OR_CustInfo,OR_ProjectManager,OR_NewMAC,OR_Inventory {

	 String fs= File.separator;
	 String rtfFilePath=System.getProperty("user.dir")+fs+"TestData"+fs+"test.rtf";
	 @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
        public void paymentsInvoiceVerification(String zUserName, String zPassword) throws Throwable {
        logger=extent.startTest("Payment and InvoiceVerification and Export").assignCategory("Billing");;
	logInfo("Currently Running on -- "+getCurrentUrl());
        type(userNameTxt, zUserName, "User name");
	type(passTxt, zPassword, "Password");
        click(OR_LoginPage.submitBtn,"Submit button");
        click(srchDd,"Search");
        type(OR_SearchPage.srchTxt, "vienna","Search box");
        type(OR_SearchPage.srchTxt,"Search box",Keys.ENTER);
        selectBillingAndAccStatusActive(OR_SearchPage.noOfRows);
        click(OR_InvoicesAndPayments.exportBtn,"Export button");
        JSClick(OR_InvoicesAndPayments.invoiceBtn,"Invoice button");
        logOut();
    }
}

