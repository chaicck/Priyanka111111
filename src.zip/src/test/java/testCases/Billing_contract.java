package testCases;

import demo.businesslogic.MediatorClass;


import static org.testng.Assert.assertEquals;

import java.io.File;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openxmlformats.schemas.presentationml.x2006.main.SldDocument;
import org.testng.Assert;
import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;


public class Billing_contract extends MediatorClass{


	 @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
	public void billing_contract(String zUserName, String zPassword) throws Throwable {
	// String id=getTestData(this.getClass().getSimpleName().substring(0, 5),1);
	String Billing = "xpath=//span[text()='Billing']";
	String Billing_contract =  "id=notification-contracts";
	String Billing_contract_list ="id=notification-list";
	String Billing_contract_summary ="id=notification-summary";
	String Billing_contract_timeline = "id=notification-timeline";
	String Billing_contract_inventory = "id=notification-inventory";
	String Billing_contract_bulkedit = "id=bulk_edit_button";
	String Billing_contract_export = "xpath=//a[@class='btn btn-success btn-sm pull-right']";
	
	String customer_id="37869";
	 
    logger = extent.startTest("Billing Contract").assignCategory("Billing");
  logInfo("Currently Running on -- "+getCurrentUrl());
    logInfo("TestCase Description:Verify Billing Contract DropDown");
    type(userNameTxt, zUserName, "User name");
	type(passTxt, zPassword, "Password");
    click(submitBtn, "Submit button");
    type(searchTextBox, customer_id, "Search Box");
	type(searchTextBox,"search box",Keys.ENTER);
	Thread.sleep(3000);
	if(verifyElementText(customerTableHeadline, "Customers")) {
		verifyTextInColumnClickOtherColumn(customerIdList, customerName, customer_id); 
	}
	Thread.sleep(3000);
	verifyText(customer_dashboard_name, "Customer:", "Customer Name");
	logInfo("Usernavigated to Customer Dashboard");
			
	actionsClick(customerDashboard_customerLink,"customerDashboard_customerLink");
	
	JSClick(Billing, "Billing");
	aJSClick(Billing_contract, "Billing_contract");
	aJSClick(Billing_contract_list, "Billing_contract_list");
	
	JSClick(Billing, "Billing");
	aJSClick(Billing_contract, "Billing_contract");
	aJSClick(Billing_contract_summary, "Billing_contract_summary");
	
	JSClick(Billing, "Billing");
	aJSClick(Billing_contract, "Billing_contract");
	aJSClick(Billing_contract_timeline, "Billing_contract_timeline");
	

	
	
	

	
}
}
