package qa6_TestCases;

import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;
import demo.objectrepository.OR_Admin;

public class AdminDropDown extends MediatorClass{
	
	@Test(alwaysRun=true,enabled=true)
	public void adminDropDown() throws Throwable {

		logger = extent.startTest("Admin DropDown options verification").assignCategory("Admin");
		type(userNameTxt, "zqa-admin", "User name");
		type(passTxt, "Q@eZL9Pw2D", "Password");
		JSClick(submitBtn);
		
		//Not working
				Verify(OR_Admin.inventory,inventory_netcMapping ,engineering_subMenu_headLine, "NetX Mapping");
				Verify(OR_Admin.inventory,inventory_partsListMappings ,engineering_subMenu_headLine, "Parts List Mapping");
				Verify(OR_Admin.inventory,inventory_uploadNextReport ,engineering_subMenu_headLine, "Upload NetX Report");

		Verify(agent_portal,agent_portal_agent ,agent_portal_headline, "Agent Portal Admin - Agents");
		Verify(agent_portal,agent_portal_faq ,agent_portal_headline, "Agent Portal Admin - FAQ");
		// wrong Heading - Verify once
		Verify(agent_portal,agent_portal_files ,agent_portal_headline, "Agent Portal Admin - Demos");
		Verify(agent_portal,agent_portal_messages ,agent_portal_headline, "Agent Portal Admin - Messages");
		Verify(agent_portal,agent_portal_news ,agent_portal_headline, "Agent Portal Admin - News");
		//not present in qa6
		//Verify(agent_portal,agent_portal_products ,agent_portal_headline, "Agent Portal Admin - Products");
		Verify(agent_portal,agent_portal_promos ,agent_portal_headline, "Agent Portal Admin - Promos");
		Verify(agent_portal,agent_portal_training_sessions ,agent_portal_headline, "Agent Portal Admin - Training Sessions");
		Verify(agent_portal,agent_portal_users ,agent_portal_headline, "Agent Portal Admin - Users");
		//not present in qa6
		//Verify(agent_portal,agent_portal_videos ,agent_portal_headline, "Agent Portal Admin - Webinars");


		Verify(automation,automation_automation_log ,automation_headline, "Automation Log Runs");
		Verify(automation,automation_automation_report ,automation_headline, "Automation Report");
		Verify(automation,automation_automation_viewAutomation ,automation_headline, "Automations");

		Verify(c3_admin,c3_domain_broadworks_service_packs ,c3_domain_headline, "Broadworks Service Packs");
		Verify(c3_admin,c3_domain_bulk_update_service_packs ,c3_domain_headline, "Bulk Update Service Packs");
		Verify(c3_admin,c3_domain_equipment ,c3_domain_headline, "C3 Equipment");
		Verify(c3_admin,c3_domain_phone_types ,c3_domain_headline, "C3 Phone Types");
		Verify(c3_admin,c3_domain_service_packs ,c3_domain_headline, "Service Packs");        
		Verify(c3_admin,c3_domain_services ,c3_domain_headline, "Services");


		VerifyClick(dev,dev_audit_log );
		VerifyClick(dev,dev_reset_broadWorks);
		VerifyClick(dev,dev_sync_customer);
		VerifyClick(dev,dev__icons);
		VerifyClick(dev,dev_salesForceBrowser );

		Verify(devices,device_bulk_change_notes ,device_subMenu_headline, "Change Device Notes");
		Verify(devices,device_snmp ,device_subMenu_headline, "Device SNMP Types");
		Verify(devices,device_bulk_circuit_migration ,device_subMenu_headline, "Select a Device Name that is tied to a Circuit that you want to export:");
		Verify(devices,device_templates ,device_subMenu_headline, "Device Templates");
		Verify(devices,device_types ,device_subMenu_headline, "Device Types");


		Verify(engineering,engineering_bulk_dns_update ,engineering_subMenu_headLine, "DNS");
		Verify(engineering,engineering_carriers ,engineering_subMenu_headLine, "Carriers");
		Verify(engineering,engineering_manage_eicb_default_watchers ,engineering_subMenu_headLine, "Default EICB Watchers");
		Verify(engineering,engineering_manage_eicb_categories ,engineering_subMenu_headLine, "EICB Categories");
		Verify(engineering,engineering_pops ,engineering_subMenu_headLine, "POPs");
		Thread.sleep(1000);


		Verify(email_notification_tool_logs,email_notification_tool_logs_CustomerEmailNotificationTool ,engineering_subMenu_headLine, "Customer Notification Tool");
		Verify(email_notification_tool_logs,email_notification_tool_email_notificationLog ,engineering_subMenu_headLine, "Search Notification Logs");
		Verify(customer_portal,customer_portal_msg_of_the_day ,customer_portal_headline, "Message of the day messages");
		//need to verify in QA5      
		Verify(email_notification_tool_logs,email_notification_tool_VisualEmailQue ,engineering_subMenu_headLine, "Email Queue");


		Verify(hermes,hermes_admin_hmac_control ,engineering_subMenu_headLine, "User Parent");
		Verify(hermes,hermes_refreshMenthodsForPermissions ,engineering_subMenu_headLine, " ");
		Verify(hermes,hermes_manageCustomerAgreements ,engineering_subMenu_headLine, "Agreements");

		//not present in qa6
		//Verify(nexmo_gdm,nexmo_gdm_importPremierCentralNo ,engineering_subMenu_headLine, "Premier Central Numbers Import");
		Verify(nexmo_gdm,nexmo_gdm_managePremierCentralNo ,engineering_subMenu_headLine, "Premier Central Numbers");
		Verify(nexmo_gdm,nexmo_gdm_configuration ,engineering_subMenu_headLine, "Nexmo & GDM Controls");

		Verify(noc,noc_messageBoard ,engineering_subMenu_headLine, "Message Board Messages");
		Verify(noc,noc_rePushCdrFile ,engineering_subMenu_headLine, "CDR Repush Request Queue");

		Verify(notifications,notifications_addNotification ,engineering_subMenu_headLine, "Notification Type");
		Verify(notifications,notifications_editNotification ,engineering_subMenu_headLine, "Notification Types");

		Verify(ip_management,ip_management_ipNetworkTreeView ,engineering_subMenu_headLine, "IP Network Tree View");
		Verify(ip_management,ip_management_typeManagementNetwork ,engineering_subMenu_headLine, "List of Network Block Types");
		Verify(ip_management,ip_management_typeManagementCustomerType ,engineering_subMenu_headLine, "List of Customer IP Types");
		Verify(ip_management,ip_management_cidrBlockManagement ,engineering_subMenu_headLine, "List of IP CIDR Blocks");
		Verify(ip_management,ip_management_networkBlockManagement ,engineering_subMenu_headLine, "List of IP Network Blocks");

		Verify(numbers,numbers_inventoryImport ,engineering_subMenu_headLine, "TN Import");
		VerifyClick(numbers,numbers_nnacl );
		Verify(numbers,numbers_pseudo ,engineering_subMenu_headLine, "Pseudo Entries");

		// not present in qa6
		/* Verify(order_portal,order_portal_productFields ,engineering_subMenu_headLine, "Product Fields");
        Verify(order_portal,order_portal_priceBook ,engineering_subMenu_headLine, "Customer Pricebooks");*/


		String admin_permissions="id=notification-permissions";
		String admin_permissions_subMenu_headLine="xpath=//div[@class='clearfix']";

		String admin_permissions_manageGroups="id=notification-manage-groups";
		String admin_permissions_manageUserGroups="id=notification-manage-user-groups";
		String admin_permissions_manageUserByGroup="id=notification-users-by-group";
		String admin_permissions_manageUserManageMethods="id=notification-manage-methods";
		String admin_permissions_manageMethodGroups="id=notification-manage-method-groups";
		String admin_permissions_refreshMethodsFromCode="id=notification-refresh-methods-from-code";
		String admin_permissions_manageCustomerProfiles="id=notification-manage-customer-profiles";
		String admin_permissions_manageCustomerAccess="id=notification-manage-customer-access";

		Verify(admin_permissions,admin_permissions_manageGroups ,admin_permissions_subMenu_headLine, "Manage Groups");
		Verify(admin_permissions,admin_permissions_manageUserGroups ,admin_permissions_subMenu_headLine, "User Group Assignment");
		Verify(admin_permissions,admin_permissions_manageUserByGroup ,admin_permissions_subMenu_headLine, "Users By Permissions Group");
		Verify(admin_permissions,admin_permissions_manageUserManageMethods ,admin_permissions_subMenu_headLine, "Manage Methods");        
		Verify(admin_permissions,admin_permissions_manageMethodGroups ,admin_permissions_subMenu_headLine, "Method Groups");
		Verify(admin_permissions,admin_permissions_refreshMethodsFromCode ,admin_permissions_subMenu_headLine, "Refresh Methods for Permissions");
		Verify(admin_permissions,admin_permissions_manageCustomerProfiles ,admin_permissions_subMenu_headLine, "Manage Customer Profile");
		Verify(admin_permissions,admin_permissions_manageCustomerAccess ,admin_permissions_subMenu_headLine, "Customer Access");

		Verify(sales_tools,sales_tools_circuitQuoteByCustomers ,engineering_subMenu_headLine, "Circuit Quote");
		VerifyClick(sales_tools,sales_tools_circuitQuoteByAddress);
		Verify(sales_tools,sales_tools_CreateExternalEicb ,engineering_subMenu_headLine, "External Engineering ICB");
		Verify(sales_tools,sales_tools_pcat ,engineering_subMenu_headLine, "Product Catalog (PCAT)");
		Verify(sales_tools,sales_tools_quota ,engineering_subMenu_headLine, "Search Team Quota");
		//Hidden Menu        
		Verify(sales_tools,sales_tools_quotaStage ,engineering_subMenu_headLine, "Quote Stage");
		Verify(sales_tools,sales_tools_salesOrderEdit ,engineering_subMenu_headLine, "Search");


		Verify(reconciliation,reconciliation_reconMacProductMapping ,engineering_subMenu_headLine, "MAC Product Mapping");


		//Service Delivery
		String admin_serviceDelivery="id=notification-service-delivery";
		String admin_serviceDelivery_dispatch="xpath=//a[@href='/dispatch/dispatchAdmin/']";
		String admin_serviceDelivery_editProjectCancelReason="id=notification-edit-project-cancel-reasons";
		String admin_serviceDelivery_editProjectJeopReasons="id=notification-edit-project-jeop-reasons";
		String admin_serviceDelivery_editProjectTemplates="id=notification-edit-project-templates";
		String admin_serviceDelivery_editSowTemplate="id=notification-edit-sow-template";
		String admin_serviceDelivery_editSystemTasks="id=notification-edit-system-tasks";
		String admin_serviceDelivery_ManageProjectTypes="id=notification-manage-project-types";
		String admin_serviceDelivery_manageC3Calanders="id=notification-manage-c3-calendars";
		String admin_serviceDelivery_manageC3CalandersTypes="id=notification-manage-c3-calendar-types";
		String admin_serviceDelivery_manageWorkQueues="id=notification-manage-work-queues";

		Verify(admin_serviceDelivery,admin_serviceDelivery_dispatch ,admin_permissions_subMenu_headLine, "Dispatch Admin");
		Verify(admin_serviceDelivery,admin_serviceDelivery_editProjectCancelReason ,admin_permissions_subMenu_headLine, " Project Cancel Reasons");
		Verify(admin_serviceDelivery,admin_serviceDelivery_editProjectJeopReasons ,admin_permissions_subMenu_headLine, "Edit Project Jeop Reasons");
		Verify(admin_serviceDelivery,admin_serviceDelivery_editProjectTemplates ,admin_permissions_subMenu_headLine, "Project Templates");
		Verify(admin_serviceDelivery,admin_serviceDelivery_editSowTemplate ,admin_permissions_subMenu_headLine, "Edit Scope of Work Template");
		Verify(admin_serviceDelivery,admin_serviceDelivery_editSystemTasks ,admin_permissions_subMenu_headLine, "System Tasks");
		Verify(admin_serviceDelivery,admin_serviceDelivery_ManageProjectTypes ,admin_permissions_subMenu_headLine, "Project Types");
		Verify(admin_serviceDelivery,admin_serviceDelivery_manageC3Calanders ,admin_permissions_subMenu_headLine, "C3 Calendar");
		Verify(admin_serviceDelivery,admin_serviceDelivery_manageC3CalandersTypes ,admin_permissions_subMenu_headLine, "Manage Calendar Types");
		Verify(admin_serviceDelivery,admin_serviceDelivery_manageWorkQueues ,admin_permissions_subMenu_headLine, "Manage Work Queues");




		Verify(user,user_addNewUser ,engineering_subMenu_headLine, "Add User");
		Verify(user,user_manageUsers ,engineering_subMenu_headLine, "Zeus Users");
		//Hidden Menu        
		Verify(user,user_manageUserLocations ,engineering_subMenu_headLine, "User Locations"); 



		Verify(zeus_admin,zeus_admin_CircuitQuoteProviders ,engineering_subMenu_headLine, "Circuit Quote Providers");
		// Hidden Menu      
		Verify(zeus_admin,zeus_admin_faxBack ,engineering_subMenu_headLine, "Faxback Configuration");
		Verify(zeus_admin,zeus_admin_hostedPayment ,engineering_subMenu_headLine, "HPP Page Configuration");
		Verify(zeus_admin,zeus_admin_platformConfiguration ,engineering_subMenu_headLine, "Platform Configuration");
		Verify(zeus_admin,zeus_admin_menuManagement ,engineering_subMenu_headLine, "Menu Management");



		//logOut(); */
	}

	private void VerifyClick(String menu,String submenu) throws Throwable {
		click(adminLInk,"Admin LInk");
		click(menu,menu);
		click(submenu,submenu);
	}

	private void Verify(String menu,String submenu, String textElement, String text) throws Throwable {
		setBrowserTo80Size();
		JSClick(adminLInk, "Admin LInk");
		actionsClick(menu);
		JSClick(submenu);
		waitForElementPresent(textElement, 200);
		verifyText(textElement,  text, "Verifying HeadLine text");
	}

	private void Verifyy(String menu,String submenu, String textElement, String text) throws Throwable {
		setBrowserTo80Size();
		click(adminLInk,"Admin LInk");
		click(menu,menu);
		JSClick(submenu);
		waitForElementPresent(textElement, 200);
		verifyText(textElement,  text, "Verifying HeadLine text");
	}




}

