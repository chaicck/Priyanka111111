package demo.objectrepository;

public interface OR_Data {

	String addDevice_SNMP_DD="id=device_snmp_id";
    String addDevice_Devision_DD="id=solar_winds_division";	 
    String addDevice_monitorType_DD="id=monitor_type";
    String addDevice_deviceType_DD="id=device_type_id";
    String addDevice_SmartWAN_Versions_DD="id=smartwan_version_chosen";
    String addDevice_SmartWAN_Versions_DD_options="xpath=//ul[@class='chosen-results']/li";
    String addDevice_Modify_SuccessMsg_OK_Btn="xpath=//button[@class='btn btn-default center-block']";
}
