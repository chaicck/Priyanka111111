package testCases;

import org.testng.annotations.Test;

import demo.businesslogic.MediatorClass;

public class TC_1_92_Task_Calendar extends MediatorClass{
	
	
	   @Test(alwaysRun=true,enabled=true, dataProvider = "Authentication")
    public void tc_1_92_Task_Calendar(String zUserName, String zPassword) throws Throwable {
    	
    	
        logger = extent.startTest("1.92 Test ID : 14982 - ZEUS-PM-4 Task Calendar").assignCategory("Projects");
      logInfo("Currently Running on -- "+getCurrentUrl());
	    logInfo("TestCase Description:Projects Tasks Calendar-Ensure that the week view and the list view also show the appropriate tasks");
        type(userNameTxt, zUserName, "User name");
		type(passTxt, zPassword, "Password");
        click(submitBtn, "Submit button");
        logInfo("Logged into Zeus successfully");
        waitForElementPresent(projectmenu, 300);
        JSClick(projectmenu,"Projects");
         //click(projectMenu,"project Link");
        click(Reports_tasks_Calander,"menu");
        waitForElementPresent(Reports_tasks_CalanderViews_DD, 200);        
        String dateDisplayedOnPage=getText(Reports_tasks_date);
        System.out.println(dateDisplayedOnPage);      
        String toDaysDate="date--"+dateAftersomeDays(0, "MMMM d, yyy");
        waitForElementPresent(Reports_tasks_date, 300);
        verifyText(Reports_tasks_date, dateAftersomeDays(0, "MMMM d, yyy"), "");
        verifyDropDownValue(Reports_tasks_CalanderViews_DD, "Voice Build");
        verifyDropDownValue(Reports_tasks_CalanderViews_DD, "Voice Install");
        selectDropDownByValue(Reports_tasks_CalanderViews_DD, "Voice Build");
        waitForElementPresent(Reports_tasks_CalanderWeek, 300);
        actionsClick(Reports_tasks_CalanderWeek,"Reports_tasks_CalanderWeek");
        Thread.sleep(5000);
        waitForElementPresent(Reports_tasks_CalanderDay, 300);
        actionsClick(Reports_tasks_CalanderDay,"Reports_tasks_CalanderDay");
        Thread.sleep(5000);
        waitForElementPresent(Reports_tasks_CalanderMonth, 300);
        actionsClick(Reports_tasks_CalanderMonth,"Reports_tasks_CalanderMonth");
        Thread.sleep(5000);
        
    }}

